# -*- coding: utf-8 -*-
"""
Plano de fundación de DESCONECTADOR TRIPOLAR (CPAT/SPAT): fundación híbrida con zapatas
PREFABRICADAS (una por polo, cada una con 2 pedestales) unidas por LOSA VACIADA IN SITU, con
JUNTAS FRÍAS, traslapos de armadura entre prefabricado e in situ y GANCHOS DE IZAJE dobles.

Se elige en el visor con «Tipo de plano». Usa el mismo motor que el plano de marcos (cotas que mandan
el dibujo, estribos uno por uno, rótulos HMV, tablas con fórmulas, CTB, exportación), con sus propias
vistas:
  PLANTA     -> Disposición de fundación (planta del conjunto)
  AA_FORMAS  -> Sección A-A formas (longitudinal: zapatas + losas in situ + juntas frías)
  BB_FORMAS  -> Sección B-B formas (transversal por una zapata, con ganchos de izaje)
  AA_ARM     -> Sección A-A armadura (longitudinal: barras con traslapos en las juntas)
  BB_ARM     -> Sección B-B armadura (transversal)
  CC         -> Sección E-E armadura pedestal
  ESQUEMA    -> Detalles típicos: gancho de izaje y junta fría
Unidades: cm en los parámetros; mm (×K) en el dibujo.
"""
from __future__ import annotations

import math

TIPO_MARCO = "Fundación marco (pedestales sobre zapata)"
TIPO_DT = "Fundación desconectador tripolar (prefabricada + losa in situ)"

# parámetros propios (se agregan a PARAM_DEF del generador)
PARAMS = {
    "dt_n":        (3,      "DT – Disposición", "N° de zapatas prefabricadas (una por polo)"),
    "dt_sep":      (400.0,  "DT – Disposición", "Distancia entre ejes de zapatas (cm)"),
    "dt_junta":    ("LOSA FUNDACIÓN e={e}cm\\PJUNTA FRÍA", "DT – Disposición",
                    "Rótulo de la losa in situ ({e} = espesor)"),
    "dt_traslapo": (70.0,   "DT – Armadura", "Traslapo prefabricado / losa in situ (cm)"),
    "dt_db_losa":  (12,     "DT – Armadura", "Ø barras losa in situ (mm)"),
    "dt_s_losa":   (15.0,   "DT – Armadura", "Separación barras losa in situ (cm)"),
    "g_x":         (85.0,   "DT – Ganchos de izaje", "Distancia del eje de la zapata a los ganchos, en X (cm)"),
    "g_doble":     ("Sí",   "DT – Ganchos de izaje", "Gancho doble"),
    "g_sep":       (8.0,    "DT – Ganchos de izaje", "Separación entre los 2 ganchos de un gancho doble (cm)"),
    "g_filas":     ("Pedestales y centro", "DT – Ganchos de izaje", "Filas de ganchos (en Y)"),
    "g_desc":      ("Ø16 A630-420H", "DT – Ganchos de izaje", "Gancho (descripción en la tabla N°4)"),
    "g_d":         (1.6,    "DT – Ganchos de izaje", "Ø gancho (cm)"),
    "g_L":         (110.0,  "DT – Ganchos de izaje", "L: largo desarrollado (cm)"),
    "g_Lgch":      (15.0,   "DT – Ganchos de izaje", "Lgch: patas horizontales (cm)"),
    "g_Lr":        (15.0,   "DT – Ganchos de izaje", "Lr: empotramiento bajo la cara superior (cm)"),
    "g_Lvg":       (35.0,   "DT – Ganchos de izaje", "Lvg: altura del gancho (cm)"),
    "g_Ldg":       (10.0,   "DT – Ganchos de izaje", "Ldg: ancho del ojo (cm)"),
    "q_moldaje":   (0.0,    "DT – Disposición", "Moldaje (m², 0 = calculado)"),
}
OPCIONES = {
    "g_doble": ["Sí", "No"],
    "g_filas": ["Pedestales y centro", "Sólo pedestales", "Sólo centro"],
}
NOMBRES = {
    "PLANTA": "Disposición de fundación", "AA_FORMAS": "Sección A-A formas (longitudinal)",
    "BB_FORMAS": "Sección B-B formas (transversal)", "AA_ARM": "Sección A-A armadura (longitudinal)",
    "BB_ARM": "Sección B-B armadura (transversal)", "CC": "Sección E-E armadura pedestal",
    "ESQUEMA": "Detalles: gancho de izaje y junta fría",
}
NOTAS_JUNTAS = [
    "NIVELAR Y POSICIONAR LAS FUNDACIONES PREFABRICADAS.",
    "VALIDAR LOS TRASLAPOS DISPUESTOS EN CADA UNA DE LAS FUNDACIONES Y AJUSTAR SEGÚN LO DISPUESTO EN LOS PLANOS.",
    "VALIDAR EL ESTADO DE LAS SUPERFICIES QUE ESTARÁN EN CONTACTO CON EL HORMIGÓN FRESCO, GARANTIZANDO UNA "
    "SUPERFICIE LIMPIA, ELIMINANDO LECHADA, PARTÍCULAS SUELTAS, POLVO, ACEITES Y CUALQUIER MATERIAL QUE AFECTE "
    "LA ADHERENCIA Y ESCARIFICAR EN CASO DE SER NECESARIO.",
    "APLICAR PUENTE DE ADHERENCIA TIPO SIKADUR 32 O EQUIVALENTE CONFORME A LAS RECOMENDACIONES DEL FABRICANTE.",
    "DISPONER EL NUEVO HORMIGÓN Y VIBRAR ADECUADAMENTE PARA ASEGURAR LA CONTINUIDAD Y ADHERENCIA ENTRE "
    "AMBOS VACIADOS.",
    "REALIZAR EL CURADO DE ACUERDO CON LAS ESPECIFICACIONES TÉCNICAS DEL PROYECTO.",
]


def es_dt(p):
    return str(p.get("tipo_plano", "")).startswith("Fundación desconectador")


# ---------------------------------------------------------------------------
# geometría
# ---------------------------------------------------------------------------
def geometria(p):
    n = max(int(p["dt_n"]), 1)
    bx, by = float(p["Lfx"]), float(p["Lfy"])
    gap = float(p["dt_sep"]) - bx
    total = n * bx + (n - 1) * gap
    ejes = [(-(n - 1) / 2.0 + i) * float(p["dt_sep"]) for i in range(n)]
    return {"n": n, "bx": bx, "by": by, "gap": gap, "total": total, "ejes": ejes,
            "losas": [(ejes[i] + bx / 2, ejes[i + 1] - bx / 2) for i in range(n - 1)]}


def filas_ganchos(p):
    dpy = (float(p["ped_y"]) + float(p["dist_ped"])) / 2.0
    f = str(p.get("g_filas", "Pedestales y centro"))
    if f.startswith("Sólo pedestales"):
        return [-dpy, dpy]
    if f.startswith("Sólo centro"):
        return [0.0]
    return [-dpy, 0.0, dpy]


def n_ganchos(p):
    g = geometria(p)
    return g["n"] * len(filas_ganchos(p)) * 2 * (2 if str(p.get("g_doble", "Sí")).startswith("S") else 1)


# ---------------------------------------------------------------------------
# cálculo: se parte del cálculo de UNA zapata (pedestales, estribos, trabas, barras de la zapata)
# y se arma la lista completa del conjunto (marcas E01…)
# ---------------------------------------------------------------------------
def calcular(p, c, pf):
    g = geometria(p)
    n = g["n"]
    by, bx, gap = g["by"], g["bx"], g["gap"]
    ri, rs = float(p["rec_inf"]), float(p["rec_sup"])
    rx, ry = pf.rec_x(p), pf.rec_y(p)
    hook = float(p["HLf"]) - ri - rs
    tr = float(p["dt_traslapo"])
    db_l, s_l = int(p["dt_db_losa"]), float(p["dt_s_losa"])
    por_rol = {b.get("rol"): b for b in c["barras"]}
    barras = []

    def nueva(marca, d, tipo, por, veces, a, b_=0.0, c_=0.0, L=None, rol=""):
        L = L if L is not None else (a + 2 * b_) / 100.0
        return dict(marca=marca, d=int(d), tipo=tipo, cant=int(por) * int(veces), por=int(por), veces=int(veces),
                    a=a, b=b_, c=c_, L=L, rol=rol)

    # pedestales (E01), estribos (E02), trabas (E03): por zapata × n zapatas
    for rol, marca in (("ped", "E01"), ("est", "E02"), ("tra", "E03")):
        b = por_rol.get(rol)
        if b:
            q = dict(b)
            q.update(marca=marca, veces=b["veces"] * n, cant=b["por"] * b["veces"] * n)
            barras.append(q)
    # zapata prefabricada, barras en Y (E04, tipo C con ganchos), ambas capas
    n_y = math.floor((bx - 2 * rx) / float(p["s_x"]) + 1e-6) + 1
    barras.append(nueva("E04", p["db_y"], "C", n_y, 2 * n, by - 2 * ry, hook, rol="pre_y"))
    # zapata prefabricada, barras en X (E05) que salen a la losa in situ con el traslapo
    n_x = math.floor((by - 2 * ry) / float(p["s_y"]) + 1e-6) + 1
    if n >= 2:
        a_ext = bx - rx + tr                                   # zapatas de los extremos: tipo L
        barras.append(nueva("E05", p["db_x"], "L", n_x, 2 * 2, a_ext, hook, L=(a_ext + hook) / 100.0,
                            rol="pre_x_ext"))
        if n > 2:                                              # zapatas centrales: tipo I, salen a ambos lados
            a_c = bx + 2 * tr
            barras.append(nueva("E05", p["db_x"], "I", n_x, 2 * (n - 2), a_c, L=a_c / 100.0, rol="pre_x_cen"))
    else:
        barras.append(nueva("E05", p["db_x"], "C", n_x, 2, bx - 2 * rx, hook, rol="pre_x_ext"))
    # losa in situ: barras en X (E06, rectas) y en Y (E07, tipo C), ambas capas
    if n >= 2:
        a6 = gap - 2 * rx
        barras.append(nueva("E06", db_l, "I", n_x, 2 * (n - 1), a6, L=a6 / 100.0, rol="sit_x"))
        n7 = math.floor((gap - 2 * rx) / s_l + 1e-6) + 1
        barras.append(nueva("E07", db_l, "C", n7, 2 * (n - 1), by - 2 * ry, hook, rol="sit_y"))
    # renumeración: dos E05 (L e I) -> E05 / E06…
    vistos = []
    for b in barras:
        if b["marca"] in vistos:
            pass
        vistos.append(b["marca"])
    marcas = {}
    k = 0
    for b in barras:
        clave = (b["marca"], b["tipo"])
        if clave not in marcas:
            k += 1
            marcas[clave] = f"E{k:02d}"
        b["marca"] = marcas[clave]
    tot = 0.0
    for b in barras:
        b["masa"] = pf.MASA.get(b["d"], 0.00617 * b["d"] ** 2)
        b["Lp"] = b["L"]
        b["Lt"] = b["Lp"] * b["cant"]
        b["peso"] = b["Lt"] * b["masa"]
        tot += b["peso"]
    c["barras"] = barras
    c["acero"] = tot
    m = {b["rol"]: b["marca"] for b in barras}
    c["m_ped"], c["m_est"], c["m_tra"] = m.get("ped", "E01"), m.get("est", "E02"), m.get("tra", "E03")
    c["m_y"], c["m_x"] = m.get("pre_y", "E04"), m.get("pre_x_ext", "E05")
    c["m_x_cen"], c["m_sx"], c["m_sy"] = m.get("pre_x_cen", c["m_x"]), m.get("sit_x", ""), m.get("sit_y", "")
    c["dt"] = g
    # cantidades de obra (toda la fundación)
    hp = c["HPd"]
    npd = int(p["n_ped"])
    A_tot = g["total"] * by / 1e4
    Ap = float(p["ped_x"]) * float(p["ped_y"]) / 1e4
    c["v_horm"] = A_tot * float(p["HLf"]) / 100 + n * npd * Ap * hp / 100
    c["v_emp"] = A_tot * float(p["e_emp"]) / 100
    c["v_exc"] = A_tot * (float(p["Df"]) + float(p["e_emp"]) + float(p["sobreexc"])) / 100
    c["v_rell"] = (A_tot - n * npd * Ap) * (float(p["Df"]) - float(p["HLf"])) / 100
    c["v_grout"] = n * npd * (float(p["placa"]) / 100) ** 2 * float(p["e_grout"]) / 100 * 1000
    c["pernos"] = n * npd * int(p["pernos_ped"])
    per_z = 2 * (bx + by) / 100.0
    per_p = 2 * (float(p["ped_x"]) + float(p["ped_y"])) / 100.0
    c["v_mold"] = n * (per_z * float(p["HLf"]) / 100 + npd * per_p * hp / 100)
    c["ganchos"] = n_ganchos(p)

    def mm(v):
        return f"{v / 100.0:g}"
    L_, B_, H_ = mm(g["total"]), mm(by), mm(p["HLf"])
    px_, py_, hp_ = mm(p["ped_x"]), mm(p["ped_y"]), mm(hp)
    c["f_horm"] = f"({L_}*{B_}*{H_}+{n * npd}*{px_}*{py_}*{hp_})"
    c["f_emp"] = f"({L_}*{B_}*{mm(p['e_emp'])})"
    c["f_exc"] = f"({L_}*{B_}*({mm(p['Df'])}+{mm(p['e_emp'])}+{mm(p['sobreexc'])}))"
    c["f_rell"] = f"(({L_}*{B_}-{n * npd}*{px_}*{py_})*({mm(p['Df'])}-{H_}))"
    c["f_grout"] = f"({n * npd}*{mm(p['placa'])}*{mm(p['placa'])}*{mm(p['e_grout'])}*1000)"
    c["f_pernos"] = f"({n * npd}*{int(p['pernos_ped'])})"
    c["f_mold"] = f"({n}*(2*({mm(bx)}+{B_})*{H_}+{npd}*2*({px_}+{py_})*{hp_}))"
    for clave, q in (("v_exc", "q_exc"), ("v_rell", "q_rell"), ("v_grout", "q_grout"), ("v_mold", "q_moldaje")):
        if p.get(q):
            c[clave] = float(p[q])
            c["f_" + clave[2:]] = None
    if gap <= 0:
        c["avisos"].append("Las zapatas se traslapan: aumente la distancia entre ejes.")
    if tr > gap / 2:
        c["avisos"].append("El traslapo es mayor que la mitad de la losa in situ.")
    return c


# ---------------------------------------------------------------------------
# tablas: N°1 y N°3 como en el plano de marcos; N°2 de toda la fundación (con moldaje); N°4 ganchos
# ---------------------------------------------------------------------------
def especificar_tablas(p, c, origenes, pf):
    # tabla N°3: los pernos totales son de TODOS los pedestales del conjunto
    q = dict(p, n_fund=1, n_ped=int(p["n_ped"]) * geometria(p)["n"])
    tablas = pf.especificar_tablas(q, c, origenes)
    t1 = next(t for t in tablas if t["id"] == "T1")
    t3 = next(t for t in tablas if t["id"] == "T3")
    # N°2: una sola columna de cantidades (toda la fundación) + moldaje
    fmt, M3 = pf.fmt, pf.M3
    filas = [("VOL. HORMIGÓN (G25)", M3, c["v_horm"], c["f_horm"]),
             ("VOL. EMPLANTILLADO (G10)", M3, c["v_emp"], c["f_emp"]),
             ("ACERO", "kg", c["acero"], "@T1"),
             ("VOL. EXCAVACIÓN", M3, c["v_exc"], c.get("f_exc")),
             ("VOL. RELLENO", M3, c["v_rell"], c.get("f_rell")),
             ("VOL. GROUTING", "lt", c["v_grout"], c.get("f_grout")),
             ("MOLDAJE", "m{\\H0.56x;\\S2^ ;}", c["v_mold"], c.get("f_mold")),
             ("PERNO DE ANCLAJE ASTM A193 GRADO B7", "UNIDAD", c["pernos"], c["f_pernos"])]
    cel = {(0, 0): dict(v="TABLA N°2\\PCANTIDADES DE OBRA", h=3.0), (1, 0): dict(v="TIPO"),
           (1, 1): dict(v="UNIDAD"), (1, 2): dict(v="CANTIDAD")}
    for i, (t, u, v, f) in enumerate(filas, start=2):
        cel[(i, 0)] = dict(v=t, h=2.2)
        cel[(i, 1)] = dict(v=u)
        d = dict(v=fmt(v, 2, True), n=v, fmt=pf.FMT2M)
        if f:
            d["f"] = f
        cel[(i, 2)] = d
    nf_ = len(filas) + 2
    cel[(nf_, 0)] = dict(v="* CANTIDADES DE OBRA CORRESPONDEN A TODA LA FUNDACIÓN.", h=2.2)
    t2 = dict(id="T2", tag=("dt_n", "placa", "sobreexc", "e_emp", "e_grout", "q_exc", "q_rell", "q_grout",
                            "q_moldaje"),
              origen=origenes.get("2", (647.2, 439.2)), anchos=[90.0, 35.0, 54.0],
              altos=[12.0, 8.0] + [7.6] * len(filas) + [8.0], celdas=cel,
              combinadas=[(0, 0, 0, 2), (nf_, 0, nf_, 2)], celda_total=None)
    # ubicación: N°1 arriba; N°2, N°3 y N°4 encadenadas hacia abajo según su alto real (sin traslapes)
    ox1, oy1 = t1["origen"]
    t2["origen"] = (t2["origen"][0], oy1 - sum(t1["altos"]) - 10.0)
    fin2 = t2["origen"][1] - sum(t2["altos"])
    ox3, oy3 = t3["origen"]
    oy3 = min(oy3, fin2 - 10.0)
    t3["origen"] = (ox3, oy3)
    # N°4: ganchos de izaje
    alto3 = sum(t3["altos"])
    cel4 = {(0, 0): dict(v="TABLA N°4\\PPARÁMETROS GEOMÉTRICOS GANCHOS DE IZAJE", h=3.0),
            (1, 0): dict(v="DESCRIPCIÓN"), (1, 1): dict(v="GANCHO")}
    nombres = ["Ø", "L", "Lgch", "Lr", "Lvg", "Ldg"]
    claves = ["g_d", "g_L", "g_Lgch", "g_Lr", "g_Lvg", "g_Ldg"]
    for k, (nm, cl) in enumerate(zip(nombres, claves)):
        cel4[(1, 2 + k)] = dict(v=nm)
        cel4[(2, 2 + k)] = dict(v="(cm)")
        val = float(p[cl])
        cel4[(3, 2 + k)] = dict(v=pf.fmt_cm(val), n=val)
    cel4[(1, 8)] = dict(v="CANTIDAD\\PTOTAL\\PGANCHOS")
    cel4[(3, 0)] = dict(v=str(p["estructura"]), h=2.0)
    cel4[(3, 1)] = dict(v=p["g_desc"], h=2.2)
    filas_g = len(filas_ganchos(p))
    doble = 2 if str(p.get("g_doble", "Sí")).startswith("S") else 1
    cel4[(3, 8)] = dict(v=str(c["ganchos"]), f=f"({geometria(p)['n']}*{filas_g}*2*{doble})")
    t4 = dict(id="T4", tag=tuple(claves) + ("g_desc", "g_doble", "g_filas"),
              origen=(ox3, oy3 - alto3 - 8.0), anchos=[38.0, 30.0] + [15.0] * 6 + [30.0],
              altos=[12.0, 7.0, 7.0, 13.0], celdas=cel4,
              combinadas=[(0, 0, 0, 8), (1, 0, 2, 0), (1, 1, 2, 1), (1, 8, 2, 8)], celda_total=None)
    t1["tag"] = ("@tabla1",)
    return [t1, t2, t3, t4]


def titulo(key, p, se):
    est = p["estructura"]
    t = {"PLANTA": ("DISPOSICIÓN DE FUNDACIÓN", est), "AA_FORMAS": ("SECCIÓN A-A", "FORMAS"),
         "BB_FORMAS": ("SECCIÓN B-B", "FORMAS"), "AA_ARM": ("SECCIÓN A-A", "ARMADURA"),
         "BB_ARM": ("SECCIÓN B-B", "ARMADURA"), "CC": ("SECCIÓN E-E", "ARMADURA PEDESTAL"),
         "ESQUEMA": ("DETALLES TÍPICOS", "GANCHO DE IZAJE Y JUNTA FRÍA")}[key]
    pie = "SIN ESCALA" if key == "ESQUEMA" else (("VER TABLA N°1\\P" if key == "CC" else "") + f"ESCALA 1:{se}")
    return f"\\pxsm1.2,qc;{{\\H1.4x;\\C4;{t[0]} \\P{t[1]}\\C256; }} \\P{{\\C7;{pie}}}"


# ---------------------------------------------------------------------------
# dibujo
# ---------------------------------------------------------------------------
def dibujar(g, vista, p, c, pf):
    {"PLANTA": _planta, "AA_FORMAS": _aa_formas, "BB_FORMAS": _bb_formas, "AA_ARM": _aa_arm,
     "BB_ARM": _bb_arm, "CC": _cc, "ESQUEMA": _detalles}[vista](g, p, c, pf)


def _gancho_planta(g, pf, x, y, p):
    """gancho de izaje visto en planta: 1 o 2 ojos (círculos) del ancho Ldg."""
    K = pf.K
    r = float(p["g_Ldg"]) * K / 2
    if str(p.get("g_doble", "Sí")).startswith("S"):
        s = float(p["g_sep"]) * K / 2
        for dy in (-s, s):
            g.circ(x, y + dy, r, pf.L_FIERRO, color=3)
    else:
        g.circ(x, y, r, pf.L_FIERRO, color=3)


def _gancho_alzado(g, pf, x, y_sup, p, color=3):
    """gancho de izaje en alzado: U invertida que sobresale de la cara superior de la zapata."""
    K = pf.K
    ld, lvg, lr, lg = float(p["g_Ldg"]) * K, float(p["g_Lvg"]) * K, float(p["g_Lr"]) * K, float(p["g_Lgch"]) * K
    y0 = y_sup - lr
    r = ld / 2
    pts = [(x - r - lg, y0), (x - r, y0), (x - r, y0 + lvg - r)]
    for k in range(9):
        a = math.pi - k * math.pi / 8
        pts.append((x + r * math.cos(a), y0 + lvg - r + r * math.sin(a)))
    pts += [(x + r, y0), (x + r + lg, y0)]
    g.pl(pts, pf.L_FIERRO, color=color)


def _planta(g, p, c, pf):
    g._empezar("PLANTA", p)
    K, S = pf.K, g._esc
    G = geometria(p)
    L, B = G["total"] * K, G["by"] * K
    bx = G["bx"] * K
    px, py = float(p["ped_x"]) * K, float(p["ped_y"]) * K
    dpy = (float(p["ped_y"]) + float(p["dist_ped"])) / 2.0 * K
    sp = float(p["perno_sep"]) * K / 2
    ejes = [e * K for e in G["ejes"]]
    g._t("Lfx", "Lfy", "dt_n", "dt_sep")
    g.rect(-L / 2, -B / 2, L / 2, B / 2, pf.L_FUND)
    for xe in ejes:
        g.rect(xe - bx / 2, -B / 2, xe + bx / 2, B / 2, pf.L_FUND)
        for fx in (-0.3, 0.3):                    # símbolos de hormigón (prefabricado)
            for fy in (-0.38, -0.12, 0.12, 0.38):
                g.simbolo_mat("s_horm", xe + fx * bx, fy * B, S / 35.0)
    # juntas frías
    g._t("dt_junta", "HLf")
    for (a, b) in G["losas"]:
        for xj in (a * K, b * K):
            g.ln((xj, -B / 2), (xj, B / 2), pf.L_FUND)
    # pedestales y pernos
    g._t("ped_x", "ped_y", "dist_ped", "perno_sep", "pernos_disp")
    for xe in ejes:
        for yc in (-dpy, dpy):
            g.rect(xe - px / 2, yc - py / 2, xe + px / 2, yc + py / 2, pf.L_FUND)
            for (u, v) in pf.pernos_xy(p, 0.0, yc / K):
                g.circ(xe + u * K, yc + v * K, 0.6 * S, pf.L_EST, color=1)
    # ganchos de izaje
    g._t("g_x", "g_doble", "g_sep", "g_filas", "g_Ldg")
    gx = float(p["g_x"]) * K
    for xe in ejes:
        for yf in filas_ganchos(p):
            for sx in (-1, 1):
                _gancho_planta(g, pf, xe + sx * gx, yf * K, p)
    # ejes
    g._t()
    for xe in ejes:
        g.ln((xe, -B / 2 - 8 * S), (xe, B / 2 + 14 * S), pf.L_EJE)
        g.eje(xe, B / 2 + 14 * S, "NUM", S)
    g.ln((-L / 2 - 14 * S, 0), (L / 2 + 8 * S, 0), pf.L_EJE)
    g.eje(-L / 2 - 14 * S, 0, "LETRA", S)
    # cortes
    ycorte = dpy
    g.simbolo("corte_izq", -L / 2 - 6 * S, ycorte, S / 35.0, attribs={"A": "A"})
    g.simbolo("corte_der", L / 2 + 6 * S, ycorte, S / 35.0, attribs={"A": "A"})
    x_b = ejes[0]
    g.simbolo("corte_b_sup", x_b, B / 2 + 5 * S, S / 35.0, attribs={"A": "B"})
    g.simbolo("corte_b_inf", x_b, -B / 2 - 5 * S, S / 35.0, attribs={"A": "B"})
    # cotas
    g._t("Lfx", "dt_sep")
    xs = []
    for xe in ejes:
        xs += [xe - bx / 2, xe + bx / 2]
    g.cadena_h(xs, -B / 2, -B / 2 - 8 * S)
    g._t("Lfx", "dt_n", "dt_sep")
    g.cota((-L / 2, -B / 2), (L / 2, -B / 2), (-L / 2, -B / 2 - 15 * S))
    g._t("dt_sep")
    if len(ejes) > 1:
        g.cadena_h(ejes, B / 2, B / 2 + 8 * S)
    g._t("ped_x")
    xs = [ejes[0] - bx / 2, ejes[0] - px / 2, ejes[0] + px / 2, ejes[0] + bx / 2]
    g.cadena_h(xs, -B / 2, -B / 2 - 4 * S)
    g._t("ped_y", "dist_ped", "Lfy")
    ys = [-B / 2, -dpy - py / 2, -dpy + py / 2, dpy - py / 2, dpy + py / 2, B / 2]
    g.cadena_v(ys, -L / 2, -L / 2 - 6 * S)
    g._t("Lfy")
    g.cota((-L / 2, -B / 2), (-L / 2, B / 2), (-L / 2 - 11 * S, -B / 2), 90)
    g._t("dist_ped", "ped_y")
    g.cadena_v([-B / 2, -dpy, dpy, B / 2], L / 2, L / 2 + 6 * S)
    # rótulos
    if G["losas"]:
        a, b = G["losas"][0]
        xm = (a + b) / 2 * K
        txt = str(p["dt_junta"]).replace("{e}", pf.fmt_cm(p["HLf"]))
        g._t("dt_junta")
        g.rotulo([(xm + 4 * S, 0.12 * B), (xm - 2 * S, -0.22 * B), (xm - 17 * S, -0.22 * B)], txt)
    g._t("g_x", "g_doble")
    xg, yg = ejes[0] - gx, dpy
    g.rotulo([(xg, yg), (xg - 6 * S, B / 2 + 24 * S), (xg - 2 * S, B / 2 + 24 * S)],
             "GANCHO DE IZAJE " + ("DOBLE " if str(p.get("g_doble")).startswith("S") else "") + "(TÍP.)")
    g._t("perno_desc")
    _u, _v = max(pf.pernos_xy(p, 0.0, dpy / K), key=lambda q: (q[0], q[1]))
    xp_, yp_ = ejes[-1] + _u * K, dpy + _v * K
    g.rotulo([(xp_, yp_), (xp_ - 4 * S, B / 2 + 25 * S), (xp_ - 8 * S, B / 2 + 25 * S)],
             "PERNO DE ANCLAJE (TÍP.)\\P(VER NOTA 5 Y DETALLE 1)", lado=-1)


def _aa_formas(g, p, c, pf):
    G = geometria(p)
    ejes = list(G["ejes"])
    g._seccion_formas(p, c, "AA_FORMAS", G["total"], ejes, float(p["ped_x"]), "NUM")
    K, S = pf.K, g._esc
    y_tz = -(float(p["Df"]) - float(p["HLf"])) * K
    y_s = -float(p["Df"]) * K
    L = G["total"] * K
    bx = G["bx"] * K
    # ejes de cada zapata
    y_tp = float(p["dPd"]) * K
    for xe in ejes[1:] if 0.0 in ejes else ejes:
        if abs(xe) < 1e-6:
            continue
        g.ln((xe * K, y_s - p["e_emp"] * K), (xe * K, y_tp + 28 * S), pf.L_EJE)
        g.eje(xe * K, y_tp + 28 * S, "NUM", S)
    # juntas frías en la losa
    g._t("dt_junta", "HLf")
    for (a, b) in G["losas"]:
        for xj in (a * K, b * K):
            g.ln((xj, y_s), (xj, y_tz), pf.L_FUND)
    # ganchos de izaje (fila de los pedestales: en el plano de corte)
    g._t("g_x", "g_Lvg", "g_Lr", "g_Ldg", "g_Lgch")
    gx = float(p["g_x"]) * K
    for xe in ejes:
        for sx in (-1, 1):
            _gancho_alzado(g, pf, xe * K + sx * gx, y_tz, p)
    # cota zapatas / losas in situ
    g._t("Lfx", "dt_sep")
    xs = []
    for xe in ejes:
        xs += [xe * K - bx / 2, xe * K + bx / 2]
    y_e = y_s - float(p["e_emp"]) * K
    g.cadena_h(xs, y_e, y_e - 9.5 * S)
    # rótulo de la losa in situ
    if G["losas"]:
        a, b = G["losas"][0]
        xm = (a + b) / 2 * K
        txt = str(p["dt_junta"]).replace("{e}", pf.fmt_cm(p["HLf"]))
        g._t("dt_junta")
        g.rotulo([(xm, (y_s + y_tz) / 2), (xm - 8 * S, y_tz + 10 * S), (xm - 12 * S, y_tz + 10 * S)], txt, lado=-1)
    g._t("g_x")
    xg = ejes[0] * K - gx
    g.rotulo([(xg, y_tz + 1.0 * S), (xg - 10 * S, y_s - 6 * S), (xg - 14 * S, y_s - 6 * S)],
             "GANCHO DE IZAJE " + ("DOBLE" if str(p.get("g_doble")).startswith("S") else ""), lado=-1)
    # cortes E-E en los pedestales
    for xe in ejes:
        xl, xr = xe * K - float(p["ped_x"]) * K / 2, xe * K + float(p["ped_x"]) * K / 2
        ym = (y_tp + y_tz) / 2
        g._marca_corte("corte_c_izq", xl - 4, ym, "E")
        g._marca_corte("corte_c_der", xr, ym, "E")
        break


def _bb_formas(g, p, c, pf):
    g._seccion_formas(p, c, "BB_FORMAS", float(p["Lfy"]), c["ped_pos"], float(p["ped_y"]), "LETRA")
    K, S = pf.K, g._esc
    y_tz = -(float(p["Df"]) - float(p["HLf"])) * K
    g._t("g_x", "g_filas", "g_Lvg", "g_Lr")
    for yf in filas_ganchos(p):
        _gancho_alzado(g, pf, yf * K, y_tz, p)
    yf = filas_ganchos(p)[len(filas_ganchos(p)) // 2] * K
    y_s = -float(p["Df"]) * K
    y_g = y_tz + (float(p["g_Lvg"]) - float(p["g_Lr"])) * K
    g.rotulo([(yf + float(p["g_Ldg"]) * K / 2, y_g - 0.6 * S), (yf + 9 * S, y_tz + 22 * S),
              (yf + 13 * S, y_tz + 22 * S)], "GANCHO DE IZAJE")


def _bb_arm(g, p, c, pf):
    g._seccion_armadura(p, c, "BB_ARM", float(p["Lfy"]), c["ped_pos"], float(p["ped_y"]), "LETRA",
                        p["db_y"], c["m_y"], p["n_x"], p["s_x"], p["db_x"], c["m_x"], float(p["Lfy"]), False)
    K, S = pf.K, g._esc
    y_tz = -(float(p["Df"]) - float(p["HLf"])) * K
    g._t("g_x", "g_filas", "g_Lvg", "g_Lr")
    for yf in filas_ganchos(p):
        _gancho_alzado(g, pf, yf * K, y_tz, p, color=6)


def _aa_arm(g, p, c, pf):
    """sección longitudinal de armadura: barras de las zapatas prefabricadas que salen a la losa in situ
    con el traslapo, barras de la losa in situ, juntas frías, pedestales con sus estribos."""
    vista = "AA_ARM"
    g._empezar(vista, p)
    K, S = pf.K, g._esc
    G = geometria(p)
    L = G["total"] * K
    bx = G["bx"] * K
    y_tp = float(p["dPd"]) * K
    y_tz = -(float(p["Df"]) - float(p["HLf"])) * K
    y_s = -float(p["Df"]) * K
    ri, rs, rx = float(p["rec_inf"]) * K, float(p["rec_sup"]) * K, pf.rec_x(p) * K
    db = float(p["db_x"])
    dbl = float(p["dt_db_losa"])
    tr = float(p["dt_traslapo"]) * K
    yb, yt = y_s + ri + db / 2, y_tz - rs - db / 2
    ejes = [e * K for e in G["ejes"]]
    wp = float(p["ped_x"]) * K
    # contorno
    g._t("Lfx", "HLf", "Df", "dPd", "ped_x")
    pts = [(-L / 2, y_s), (L / 2, y_s), (L / 2, y_tz)]
    for xc in reversed(ejes):
        pts += [(xc + wp / 2, y_tz), (xc + wp / 2, y_tp), (xc - wp / 2, y_tp), (xc - wp / 2, y_tz)]
    pts += [(-L / 2, y_tz)]
    g.pl(pts, pf.L_FUND, closed=True)
    g.rect(-L / 2, y_s - float(p["e_emp"]) * K, L / 2, y_s, pf.L_EMP)
    g._t("dt_junta")
    for (a, b) in G["losas"]:
        for xj in (a * K, b * K):
            g.pl([(xj, y_s), (xj, y_tz)], pf.L_FINA, lt="HIDDEN" if "HIDDEN" in g.doc.linetypes else None)
    # barras X de las zapatas prefabricadas (E05)
    n = G["n"]
    g._t("db_x", "s_y", "dt_traslapo", "rec_inf", "rec_sup", "rec_lat")
    for i, xc in enumerate(ejes):
        x0, x1 = xc - bx / 2, xc + bx / 2
        izq_ext = i == 0
        der_ext = i == n - 1
        xa = x0 + rx if izq_ext else x0 - tr
        xb_ = x1 - rx if der_ext else x1 + tr
        for y, sg in ((yb, 1), (yt, -1)):
            pts = []
            if izq_ext:
                pts.append((xa, y + sg * (yt - yb) * 0.85))
            pts += [(xa, y), (xb_, y)]
            if der_ext:
                pts.append((xb_, y + sg * (yt - yb) * 0.85))
            g.pl(pts, pf.L_FIERRO, color=3)
    # barras X de la losa in situ (E06), corridas para que se vea el traslapo
    g._t("dt_db_losa", "dt_s_losa", "rec_lat")
    off = max(db, dbl) * 1.2
    for (a, b) in G["losas"]:
        xa, xb_ = a * K + rx, b * K - rx
        g.ln((xa, yb + off), (xb_, yb + off), pf.L_FIERRO, color=5)
        g.ln((xa, yt - off), (xb_, yt - off), pf.L_FIERRO, color=5)
    # barras perpendiculares (puntos): zapatas (E04) y losas (E07)
    g._t("db_y", "s_x")
    puntos = []
    for xc in ejes:
        for xx in pf.posiciones_barras(G["bx"], math.floor((G["bx"] - 2 * pf.rec_x(p)) / float(p["s_x"]) + 1e-6) + 1,
                                       float(p["s_x"]), pf.rec_x(p)):
            puntos.append(xc + xx * K)
    g._t("dt_s_losa", "dt_db_losa")
    puntos_l = []
    for (a, b) in G["losas"]:
        gap = (b - a)
        nl = math.floor((gap - 2 * pf.rec_x(p)) / float(p["dt_s_losa"]) + 1e-6) + 1
        for xx in pf.posiciones_barras(gap, nl, float(p["dt_s_losa"]), pf.rec_x(p)):
            puntos_l.append((a + b) / 2 * K + xx * K)
    for xx in puntos:
        g.punto(xx, yb + db / 2 + float(p["db_y"]) / 2, float(p["db_y"]))
        g.punto(xx, yt - db / 2 - float(p["db_y"]) / 2, float(p["db_y"]))
    for xx in puntos_l:
        g.punto(xx, yb + off + dbl / 2 + dbl / 2, dbl)
        g.punto(xx, yt - off - dbl / 2 - dbl / 2, dbl)
    # pedestales: barras E01, estribos E02, pernos
    pos_est = pf.posiciones_estribos(p)
    g.estribos_ref.pop(vista, None)
    re_ = float(p["rec_ped"]) * K
    cp = c["c_ped"] * K
    yt_ped = y_tp - float(p["rec_ped_sup"]) * K
    yb_ped = y_s + ri + db + float(p["db_y"]) + float(p["db_ped"]) / 2
    gp = float(p["gancho_ped"]) * K
    sp = float(p["perno_sep"]) * K / 2
    for xc in ejes:
        x1_, x2_ = xc - wp / 2 + cp, xc + wp / 2 - cp
        g._t("db_ped", "n_cara", "gancho_ped", "rec_ped_sup")
        g.pl([(x1_ + gp, yt_ped), (x1_, yt_ped), (x1_, yb_ped), (x1_ + gp, yb_ped)], pf.L_FIERRO, color=3)
        g.pl([(x2_ - gp, yt_ped), (x2_, yt_ped), (x2_, yb_ped), (x2_ - gp, yb_ped)], pf.L_FIERRO, color=3)
        for k, pe in enumerate(pos_est):
            ye = y_tp - pe * K
            g._t("@estribo", str(k), "n_est", "s_est", "db_est", "est_reparto")
            g.ln((xc - wp / 2 + re_, ye), (xc + wp / 2 - re_, ye), pf.L_FIERRO, color=3)
        g._t()
        g.estribos_ref.setdefault(vista, {"y_tp": g._xy(0, y_tp)[1], "hpd": c["HPd"], "x": []})
        g.estribos_ref[vista]["x"].append((g._xy(xc - wp / 2, 0)[0], g._xy(xc + wp / 2, 0)[0]))
        g._t("perno_sep", "perno_desc", "L", "pernos_disp")
        dpy_ = (float(p["ped_y"]) + float(p["dist_ped"])) / 2.0
        for dx in pf.pernos_proy(p, "u", 0.0, dpy_):
            g.simbolo("perno", xc + dx * K, y_tp + 170, 1.0)
    g.elementos[vista] = {
        "barras": {"x": sorted(puntos + puntos_l), "y": y_s, "marca": c["m_y"], "eje": "x"},
        "estribos": {"y": [y_tp - pe * K for pe in pos_est], "x": ejes[0] - wp / 2, "marca": c["m_est"],
                     "eje": "y", "marca2": c["m_tra"], "n_trabas": pf.trabas_por_nivel(p)},
    }
    # ejes
    g._t()
    for xc in ejes:
        g.ln((xc, y_s - 3 * S), (xc, y_tp + 28 * S), pf.L_EJE)
        g.eje(xc, y_tp + 28 * S, "NUM", S)
    # cotas: estribos (pedestal izquierdo), recubrimientos, traslapos, repartos
    xl0 = ejes[0] - wp / 2
    g._cotas_estribos(p, c, vista, pos_est, xl0, xl0 - 8 * S, y_tp, y_tz, S)
    g._t("rec_sup", "rec_inf", "rec_lat", "rec_lat_x")
    g.cota((-L / 2, y_tz), (-L / 2 + rx, yt + db / 2), (-L / 2 - 4 * S, y_tz), 90, cid=f"{vista}:rec:superior")
    g._t("rec_inf", "rec_sup", "rec_lat", "rec_lat_x")
    g.cota((-L / 2, y_s), (-L / 2 + rx, yb - db / 2), (-L / 2 - 4 * S, y_s), 90, cid=f"{vista}:rec:inferior")
    g._t("rec_lat_x", "rec_lat")
    g.cota((-L / 2, y_s), (-L / 2 + rx, y_s), (-L / 2, y_s - 4 * S), cid=f"{vista}:rec:lateral_izq")
    g.cota((L / 2 - rx, y_s), (L / 2, y_s), (L / 2 - rx, y_s - 4 * S), cid=f"{vista}:rec:lateral_der")
    g._t("dt_traslapo")
    for (a, b) in G["losas"]:
        for xj, sg in ((a * K, 1), (b * K, -1)):
            xa_, xb2 = sorted((xj, xj + sg * tr))
            g.cota((xa_, yt), (xb2, yt), (xa_, y_tz + 6 * S), 0,
                   texto=f"<>\\PTRASL.")
    # reparto de barras perpendiculares por tramo («n+n@s=L A.C.»)
    g._t("s_x", "db_y")
    nz = math.floor((G["bx"] - 2 * pf.rec_x(p)) / float(p["s_x"]) + 1e-6) + 1
    for xc in ejes:
        xa_, xb2 = xc - bx / 2 + rx, xc + bx / 2 - rx
        g.cota((xa_, y_s), (xb2, y_s), (xa_, y_s - 9 * S), 0,
               texto=f"{nz}+{nz}@{pf.fmt_cm(p['s_x'])}\\PA.C. ({c['m_y']})")
    g._t("dt_s_losa")
    for (a, b) in G["losas"]:
        gap = b - a
        nl = math.floor((gap - 2 * pf.rec_x(p)) / float(p["dt_s_losa"]) + 1e-6) + 1
        xa_, xb2 = a * K + rx, b * K - rx
        g.cota((xa_, y_s), (xb2, y_s), (xa_, y_s - 9 * S), 0,
               texto=f"{nl}+{nl}@{pf.fmt_cm(p['dt_s_losa'])}\\PA.C. ({c['m_sy']})")
    # rótulos de marcas
    g._t("db_x")
    g.rotulo([(ejes[0] - bx / 4, yb), (ejes[0] - bx / 4 - 3 * S, y_tz + 9 * S),
              (ejes[0] - bx / 4 - 7 * S, y_tz + 9 * S)], c["m_x"], lado=-1)
    if G["n"] > 2:
        g.rotulo([(ejes[1] + bx / 4, yt), (ejes[1] + bx / 4 + 3 * S, y_tz + 9 * S),
                  (ejes[1] + bx / 4 + 7 * S, y_tz + 9 * S)], c["m_x_cen"])
    if G["losas"]:
        a, b = G["losas"][0]
        xm = (a + b) / 2 * K
        g._t("dt_db_losa")
        g.rotulo([(xm, yb + off), (xm + 3 * S, y_tz + 9 * S), (xm + 7 * S, y_tz + 9 * S)], c["m_sx"])
    g._t("db_ped", "n_cara")
    g.rotulo([(ejes[-1] + wp / 2 - cp, (y_tp + y_tz) / 2), (ejes[-1] + wp / 2 + 6 * S, (y_tp + y_tz) / 2 + 600),
              (ejes[-1] + wp / 2 + 10 * S, (y_tp + y_tz) / 2 + 600)], c["m_ped"])


def _cc(g, p, c, pf):
    g._v_cc(p, c)


def _detalles(g, p, c, pf):
    """detalles típicos (sin escala): gancho de izaje (con sus cotas de la tabla N°4) y junta fría."""
    g._empezar("ESQUEMA", p)
    K, S = pf.K, g._esc
    # --- gancho de izaje
    ld, lvg, lr, lg = (float(p[k]) * K for k in ("g_Ldg", "g_Lvg", "g_Lr", "g_Lgch"))
    x0, y_sup = 0.0, 0.0
    g._t("g_Ldg", "g_Lvg", "g_Lr", "g_Lgch")
    _gancho_alzado(g, pf, x0, y_sup, p, color=3)
    w = 3 * (ld + lg) + 6 * S
    g.pl([(x0 - w / 2, y_sup), (x0 + w / 2, y_sup)], pf.L_FUND)
    g.pl([(x0 - w / 2, y_sup - lr - 4 * S), (x0 + w / 2, y_sup - lr - 4 * S)], pf.L_FINA)
    y0 = y_sup - lr
    r = ld / 2
    g.cota((x0 - r, y0 + lvg), (x0 + r, y0 + lvg), (x0 - r, y0 + lvg + 4 * S), 0, texto="Ldg")
    g.cota((x0 - r - lg, y0), (x0 - r, y0), (x0 - r - lg, y0 - 4 * S), 0, texto="Lgch")
    g.cota((x0 - r, y0), (x0 - r, y0 + lvg), (x0 - r - lg - 3 * S, y0), 90, texto="Lvg")
    g.cota((x0 + r, y0), (x0 + r, y_sup), (x0 + r + lg + 3 * S, y0), 90, texto="Lr")
    g.rotulo([(x0 - w / 2 + 2 * S, y_sup), (x0 - w / 2 - 1 * S, y_sup + 8 * S), (x0 - w / 2 - 4 * S, y_sup + 8 * S)],
             "PROYECCIÓN\\PZAPATA", lado=-1)
    g.texto("DETALLE TÍPICO\\PGANCHO DE IZAJE\\PVER TABLA N°4", x0, y0 - 9 * S, 2.5, adj=2)
    # --- junta fría
    e = float(p["HLf"]) * K
    tr = float(p["dt_traslapo"]) * K
    ri, rs = float(p["rec_inf"]) * K, float(p["rec_sup"]) * K
    largo = tr + 8 * S
    xj = 1.5 * (ld + lg) + 14 * S + largo        # junta, a la derecha del detalle del gancho
    g._t("HLf", "dt_traslapo")
    yb, yt = y_sup - e, y_sup
    g.pl([(xj - largo, yb), (xj + largo, yb), (xj + largo, yt), (xj - largo, yt)], pf.L_FUND)
    g.pl([(xj, yb - 2 * S), (xj, yt + 2 * S)], pf.L_FUND)
    for fx in (0.25, 0.7):
        g.simbolo_mat("s_horm", xj - largo * fx, (yb + yt) / 2, S / 35.0)
    yb_b, yt_b = yb + ri, yt - rs
    off = 1.4 * float(p["dt_db_losa"]) * 2
    g.ln((xj - largo, yb_b), (xj + tr, yb_b), pf.L_FIERRO, color=3)
    g.ln((xj - largo, yt_b), (xj + tr, yt_b), pf.L_FIERRO, color=3)
    g.ln((xj + 0.5 * S, yb_b + off), (xj + largo, yb_b + off), pf.L_FIERRO, color=5)
    g.ln((xj + 0.5 * S, yt_b - off), (xj + largo, yt_b - off), pf.L_FIERRO, color=5)
    g.cota((xj, yt_b), (xj + tr, yt_b), (xj, yt + 5 * S), 0, texto=f"TRASLAPO={pf.fmt_cm(p['dt_traslapo'])}")
    g.cota((xj + largo, yb), (xj + largo, yt), (xj + largo + 4 * S, yb), 90)
    g.rotulo([(xj - largo / 2, (yb + yt) / 2), (xj - largo / 2 - 4 * S, yt + 9 * S),
              (xj - largo / 2 - 8 * S, yt + 9 * S)], "ZAPATA PREFABRICADA", lado=-1)
    g.rotulo([(xj + largo / 2, (yb + yt) / 2), (xj + largo / 2 + 4 * S, yt + 9 * S),
              (xj + largo / 2 + 8 * S, yt + 9 * S)], "LOSA VACIADA IN SITU")
    g.rotulo([(xj, yb + 0.3 * e), (xj + 5 * S, yb - 5 * S), (xj + 9 * S, yb - 5 * S)],
             "JUNTA FRÍA + PUENTE DE ADHERENCIA\\P(VER NOTAS JUNTAS FRÍAS)", color=3)
    g.texto("DETALLE TÍPICO\\PJUNTA FRÍA", xj - largo / 2, yb - 9 * S, 2.5, adj=2)
