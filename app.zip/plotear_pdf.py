# -*- coding: utf-8 -*-
"""
Ploteo de un DWG/DXF a PDF con el estilo de los PDF de HMV (CTB "GN-PLOT-HMV"):

  • hoja A0 horizontal (1189 × 841 mm), la lámina se ajusta a la hoja
  • todo en negro con línea fina (hairline), salvo los colores "tramados":
        ACI 253 → gris 73 %   (achurados, patrones)
        ACI 9   → gris 86 %   (ejes, emplantillado)
        ACI 8   → gris 50 %
  • los colores verdaderos (logos Transelec / HMV / POWERCHINA) se mantienen
  • textos SHX (romans, simplex…) con las fuentes LFF equivalentes de la carpeta "fuentes"
  • el PDF conserva las capas de AutoCAD (se pueden prender/apagar en el visor)

Uso:
    py plotear_pdf.py plano.dwg                     -> plano.pdf (A0)
    py plotear_pdf.py plano.dwg --hoja A1           -> en A1
    py plotear_pdf.py plano.dxf --layout F1 --salida mi.pdf
    py plotear_pdf.py plano.dwg --png               -> además una vista PNG
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

import ezdxf
from ezdxf import colors as ezcolors
from ezdxf.addons.drawing import Frontend, RenderContext, layout
from ezdxf.addons.drawing.config import (Configuration, BackgroundPolicy, ColorPolicy,
                                         LineweightPolicy)
from ezdxf.addons.drawing import pymupdf as pmb


class FaltaPyMuPDF(RuntimeError):
    pass


def hay_pymupdf():
    try:
        import pymupdf  # noqa: F401
        return True
    except ImportError:
        try:
            import fitz  # noqa: F401  (nombre antiguo de PyMuPDF)
            return True
        except ImportError:
            return False


def instalar_pymupdf():
    """instala PyMuPDF en el MISMO Python que ejecuta el programa y recarga el backend de ezdxf."""
    import importlib
    import subprocess
    r = subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pymupdf"],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("pip no pudo instalar PyMuPDF:\n" + (r.stderr or r.stdout)[-1500:])
    importlib.invalidate_caches()
    global pmb
    pmb = importlib.reload(pmb)
    if not hay_pymupdf():
        raise RuntimeError("PyMuPDF se instaló pero no se pudo cargar; reinicie el editor.")
    return r.stdout[-300:]

AQUI = os.path.dirname(os.path.abspath(__file__))
FUENTES = os.path.join(AQUI, "fuentes")

HOJAS = {"A0": (1189.0, 841.0), "A1": (841.0, 594.0), "A2": (594.0, 420.0),
         "A3": (420.0, 297.0), "A4": (297.0, 210.0)}

# estilo por defecto: deducido del PDF de referencia SNA3027-A-JDR-47-CI-PL-0007-L0001_B.pdf
ESTILO_DEF = {
    "grises_aci": {"253": 0.73, "9": 0.86, "8": 0.50, "250": 0.20, "251": 0.35, "252": 0.55, "254": 0.86, "255": 1.0},
    "resto": "#000000",
    "mantener_color_verdadero": True,
    "grosor_linea_mm": 0.10,
}


def cargar_estilo(ruta=None):
    est = json.loads(json.dumps(ESTILO_DEF))
    ruta = ruta or os.path.join(AQUI, "estilo_ploteo.json")
    if os.path.exists(ruta):
        with open(ruta, encoding="utf-8") as f:
            est.update(json.load(f))
    return est


def _hex_gris(g):
    v = max(0, min(255, int(round(g * 255))))
    return f"#{v:02x}{v:02x}{v:02x}"


def _aci_de_hex(hex_color, tabla={}):
    if not tabla:
        for i in range(1, 256):
            r, g, b = ezcolors.aci2rgb(i)
            tabla.setdefault(f"#{r:02x}{g:02x}{b:02x}", i)
    return tabla.get(hex_color[:7].lower())


SHX_EQUIV = {"txt": "standard", "simplex": "simplex", "romans": "romans", "romand": "romand",
             "romanc": "romanc", "romant": "romant", "isocp": "iso", "isoct": "iso", "iso": "iso",
             "italic": "italicc", "italicc": "italicc", "scripts": "scripts", "monotxt": "standard"}

_RE_COLOR = re.compile(r"\\[Cc]\d+;|\\c\d+;")


_SUP = {"1": "¹", "2": "²", "3": "³"}
# m{\H0.56x;\S3^ ;}  o  m\S3^;  (superíndice apilado de AutoCAD) -> m³ : ezdxf no dibuja bien esos apilados
_RE_SUP_G = re.compile(r"\{(?:\\H[0-9.]+x;)?\\S([123])\^ ?;\}")   # grupo propio {…}
_RE_SUP = re.compile(r"(?:\\H[0-9.]+x;)?\\S([123])\^ ?;")           # dentro de otro grupo


def _superindices(texto):
    texto = _RE_SUP_G.sub(lambda m: _SUP[m.group(1)], texto)
    return _RE_SUP.sub(lambda m: _SUP[m.group(1)], texto)


def _preparar_textos(doc):
    """1) quita los colores escritos dentro de los MTEXT (\\C4; …) para que el estilo de ploteo
       los pase a negro, como hace el CTB de AutoCAD; 2) precarga las fuentes SHX/LFF."""
    from ezdxf.fonts import fonts
    for lay in list(doc.layouts) + list(doc.blocks):
        for e in lay:
            t = e.dxftype()
            if t == "MTEXT":
                e.text = _superindices(_RE_COLOR.sub("", e.text))
            elif t == "MULTILEADER":
                try:
                    mt = e.context.mtext
                    if mt is not None:
                        mt.default_content = _RE_COLOR.sub("", mt.default_content)
                except Exception:
                    pass
    # fuentes SHX -> equivalentes LFF (LibreCAD) de la carpeta "fuentes"
    if os.path.isdir(FUENTES):
        try:
            import pathlib
            fonts.font_manager.scan_folder(pathlib.Path(FUENTES))
        except Exception:
            pass
        lff = {os.path.splitext(f)[0].lower(): f for f in os.listdir(FUENTES) if f.lower().endswith(".lff")}
        defecto = lff.get("romans") or next(iter(lff.values()), None)
        for st in doc.styles:
            nombre = (st.dxf.get("font") or "").strip()
            if nombre.lower().endswith((".shx", ".shp")) or (nombre and "." not in nombre):
                tallo = os.path.splitext(os.path.basename(nombre))[0].lower()
                nuevo = lff.get(tallo) or lff.get(SHX_EQUIV.get(tallo, ""), None) or defecto
                if nuevo:
                    st.dxf.font = nuevo
                    if st.dxf.hasattr("bigfont"):
                        st.dxf.discard("bigfont")
    # fuentes indicadas dentro de los MTEXT ({\\Fromans|c0;...}) -> se usa la del estilo
    re_f = re.compile(r"\\[Ff][^;\\]*;")
    for lay in list(doc.layouts) + list(doc.blocks):
        for e in lay:
            if e.dxftype() == "MTEXT":
                e.text = re_f.sub("", e.text)


def _aplicar_ctb(doc, est):
    """Equivalente al CTB: cada color ACI pasa a negro o a su gris; los colores verdaderos
    (logos) se mantienen. Se aplica sobre el documento cargado en memoria (no al archivo)."""
    grises = {int(k): float(v) for k, v in est["grises_aci"].items()}
    negro = est["resto"].lstrip("#")
    rgb_negro = (int(negro[0:2], 16), int(negro[2:4], 16), int(negro[4:6], 16))

    def destino(aci):
        if aci in grises:
            g = int(round(grises[aci] * 255))
            return (g, g, g)
        return rgb_negro

    for capa in doc.layers:
        if capa.rgb is not None and est.get("mantener_color_verdadero", True):
            continue
        capa.rgb = destino(abs(capa.color))
    for lay in list(doc.layouts) + list(doc.blocks):
        for e in lay:
            for sub in [e] + list(getattr(e, "attribs", []) or []):
                if not sub.dxf.hasattr("color"):
                    continue
                aci = sub.dxf.color
                if sub.dxf.hasattr("true_color"):
                    tc = ezcolors.int2rgb(sub.dxf.true_color)
                    if not (1 <= aci <= 255 and tuple(tc) == tuple(ezcolors.aci2rgb(aci))):
                        if est.get("mantener_color_verdadero", True):
                            continue
                if 1 <= aci <= 255:
                    sub.rgb = destino(aci)
    # estilos de cota: color de líneas y textos de cota
    for ds in doc.dimstyles:
        for k in ("dimclrd", "dimclre", "dimclrt"):
            v = ds.dxf.get(k, 0)
            if 1 <= v <= 255 and v not in grises:
                ds.dxf.set(k, 7)


def _abrir(ruta):
    if ruta.lower().endswith(".dwg"):
        sys.path.insert(0, AQUI)
        import plano_fundacion as pf
        tmp = os.path.splitext(ruta)[0] + "_tmp_ploteo.dxf"
        pf.convertir_a_dxf(ruta, tmp)
        try:
            return ezdxf.readfile(tmp)
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
    return ezdxf.readfile(ruta)


CTB_DIR = os.path.join(AQUI, "ctb")


def ruta_ctb(nombre):
    """ruta del CTB: tal cual, o buscado en la carpeta ctb/ del programa."""
    if not nombre:
        return None
    if os.path.exists(nombre):
        return nombre
    cand = os.path.join(CTB_DIR, os.path.basename(nombre))
    return cand if os.path.exists(cand) else None


def plotear(entrada, salida=None, hoja="A0", nombre_layout=None, estilo=None, png=False, ctb="auto",
            grosores=True, doc=None):
    """ctb: "auto" = el CTB asignado a la lámina (si está en ctb/), un nombre/ruta .ctb, o None (estilo interno)."""
    if os.path.isdir(FUENTES) and FUENTES not in ezdxf.options.support_dirs:
        ezdxf.options.support_dirs.append(FUENTES)
        try:
            from ezdxf.fonts import fonts
            fonts.build_font_manager_cache(fonts.font_manager_cache_file()) if False else None
        except Exception:
            pass
    est = estilo or cargar_estilo()
    if doc is None:
        doc = _abrir(entrada)
    else:   # se trabaja sobre una copia para no alterar el documento del editor
        import io
        flujo = io.StringIO()
        doc.write(flujo)
        doc = ezdxf.read(io.StringIO(flujo.getvalue()))
    _preparar_textos(doc)
    ezdxf.options.set("drawing-addon", "shx_resolve_order", "lst")   # SHX -> LFF antes que TrueType
    lays = [l for l in doc.layouts if l.name != "Model"]
    lay = next((l for l in lays if l.name == nombre_layout), None) if nombre_layout else None
    if lay is None:
        lay = max(lays, key=lambda l: len(l)) if lays else doc.modelspace()
    ctb_obj = None
    if ctb:
        nombre = lay.dxf_layout.dxf.get("current_style_sheet", "") if (ctb == "auto" and hasattr(lay, "dxf_layout")) else ctb
        ruta = ruta_ctb(nombre) or (ruta_ctb("GN-PLOT-HMV.ctb") if ctb == "auto" else None)
        if ruta:
            from ezdxf.addons import acadctb
            ctb_obj = acadctb.load(ruta)
        elif ctb != "auto":
            raise FileNotFoundError(f"No se encontró el CTB {ctb}")
    if ctb_obj is None:
        _aplicar_ctb(doc, est)          # estilo interno aproximado (sin CTB)

    grises = {int(k): _hex_gris(v) for k, v in est["grises_aci"].items()}
    negro = est["resto"]

    def mapear(entity, props):
        # color verdadero explícito (logos) -> se mantiene, salvo que sea idéntico a su color ACI
        if est.get("mantener_color_verdadero", True) and entity.dxf.hasattr("true_color"):
            tc = entity.dxf.true_color
            aci_e = entity.dxf.get("color", 256)
            if not (1 <= aci_e <= 255 and ezcolors.int2rgb(tc) == tuple(ezcolors.aci2rgb(aci_e))):
                return
        aci = _aci_de_hex(props.color)
        if aci is None:
            # color verdadero heredado (capa o bloque con RGB)
            if est.get("mantener_color_verdadero", True):
                return
            props.color = negro
            return
        props.color = grises.get(aci, negro)

    cfg = Configuration(background_policy=BackgroundPolicy.WHITE, color_policy=ColorPolicy.COLOR,
                        lineweight_policy=LineweightPolicy.ABSOLUTE,
                        lineweight_scaling=(1.0 if (grosores and ctb_obj is not None) else 0.0))
    ctx = RenderContext(doc, ctb=ctb_obj) if ctb_obj is not None else RenderContext(doc)
    if not hay_pymupdf():
        raise FaltaPyMuPDF("Falta la librería PyMuPDF (necesaria para escribir el PDF).\n"
                           f"Instálela con:  \"{sys.executable}\" -m pip install pymupdf")
    be = pmb.PyMuPdfBackend()
    from ezdxf import bbox as _bb
    fe = Frontend(ctx, be, config=cfg, bbox_cache=_bb.Cache())
    if ctb_obj is None:
        fe.push_property_override_function(mapear)
    fe.draw_layout(lay, finalize=True, **({"layout_properties": None} if False else {}))
    if ctb_obj is not None:
        ctx.plot_styles = ctb_obj
    W, H = HOJAS.get(hoja.upper(), HOJAS["A0"])
    # la lámina = límites del layout (marco completo)
    ldx = lay.dxf_layout.dxf if hasattr(lay, "dxf_layout") else None
    page = layout.Page(W, H, layout.Units.mm, margins=layout.Margins.all(0))
    settings = layout.Settings(fit_page=True, fixed_stroke_width=est["grosor_linea_mm"] / 1.0,
                               min_stroke_width=est["grosor_linea_mm"], max_stroke_width=0.001,
                               output_layers=True)
    rango = None
    if ldx is not None:
        lmin, lmax = ldx.get("limmin"), ldx.get("limmax")
        if lmin is not None and lmax is not None and (lmax[0] - lmin[0]) > 10:
            from ezdxf.math import BoundingBox2d
            rango = BoundingBox2d([(lmin[0], lmin[1]), (lmax[0], lmax[1])])
    datos = be.get_pdf_bytes(page, settings=settings, render_box=rango) if rango is not None \
        else be.get_pdf_bytes(page, settings=settings)
    salida = salida or os.path.splitext(entrada)[0] + ".pdf"
    with open(salida, "wb") as f:
        f.write(datos)
    if png:
        img = be.get_pixmap_bytes(page, fmt="png", settings=settings, dpi=72,
                                  **({"render_box": rango} if rango is not None else {}))
        with open(os.path.splitext(salida)[0] + "_vista.png", "wb") as f:
            f.write(img)
    return salida


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("entrada", help="archivo DWG o DXF")
    ap.add_argument("--salida", help="PDF de salida (por defecto, junto al archivo)")
    ap.add_argument("--hoja", default="A0", choices=list(HOJAS))
    ap.add_argument("--layout", help="nombre del layout (por defecto el de papel con más elementos)")
    ap.add_argument("--estilo", help="JSON de estilo de ploteo (grises por color ACI)")
    ap.add_argument("--png", action="store_true", help="guardar además una vista PNG")
    ap.add_argument("--ctb", default="auto", help="CTB a usar (GN-PLOT-HMV.ctb, GN-FIT-HMV.ctb, ruta) o 'ninguno'")
    ap.add_argument("--sin-grosores", action="store_true", help="todas las líneas finas (no usar grosores del CTB)")
    a = ap.parse_args(argv)
    est = cargar_estilo(a.estilo) if a.estilo else None
    r = plotear(a.entrada, a.salida, a.hoja, a.layout, est, a.png,
                ctb=None if a.ctb.lower() in ("ninguno", "none", "") else a.ctb, grosores=not a.sin_grosores)
    print("PDF:", r)


if __name__ == "__main__":
    main()
