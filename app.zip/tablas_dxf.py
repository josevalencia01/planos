# -*- coding: utf-8 -*-
"""
Tablas REALES con fórmulas dentro del DXF (ACAD_TABLE + campos FIELD «AcExpr»).

Se escriben en el formato de celdas clásico de ACAD_TABLE (grupos 171… por celda, 344 = campo de la
celda) y con objetos FIELD como los que guarda AutoCAD: un contenedor «_text» (%<\\_FldIdx 0>%) cuyo
hijo es la fórmula «\\AcExpr (C6*J6) \\f "%lu2%pr2%ds44"». Es el formato que leen AutoCAD y Open CAD
Studio (biblioteca acadrust), que recalculan las fórmulas al abrir o editar.

Flujo (Generador.guardar):
  1) preparar(gen): por cada tabla, su respaldo dibujado (líneas + textos con XDATA HMV_TABLA) pasa a un
     bloque anónimo *T (la «imagen» de la tabla, como en AutoCAD) y se deja un POINT marcador.
  2) ezdxf guarda el DXF.
  3) escribir(ruta, info): el POINT marcador se reemplaza por la entidad ACAD_TABLE (mismo handle) y se
     agregan los FIELD al final de la sección OBJECTS.
  4) restaurar(gen, info): el documento en memoria vuelve a como estaba (el editor sigue trabajando).
"""
from __future__ import annotations

import re

APPID = "HMV_TABLA"
_NUM = re.compile(r"^\s*-?\d{1,3}(?:\.\d{3})*(?:,\d+)?\s*$|^\s*-?\d+(?:[.,]\d+)?\s*$")
_LADOS = {"arriba": (279, 289, 0x400), "der": (275, 285, 0x800), "abajo": (276, 286, 0x1000),
          "izq": (278, 288, 0x2000)}
_OPUESTO = {"arriba": ("abajo", -1, 0), "abajo": ("arriba", 1, 0), "izq": ("der", 0, -1), "der": ("izq", 0, 1)}


def _numero(txt):
    """'1.429,84' -> 1429.84 ; '0,617' -> 0.617 ; '55' -> 55.0 ; otro -> None"""
    if txt is None or not _NUM.match(str(txt)):
        return None
    s = str(txt).strip()
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _col(c):
    s = ""
    c += 1
    while c:
        c, r = divmod(c - 1, 26)
        s = chr(65 + r) + s
    return s


# ---------------------------------------------------------------------------
def preparar(gen):
    """Pasa el respaldo de cada tabla a un bloque *T y deja un POINT marcador. Devuelve la info
    necesaria para escribir() y restaurar()."""
    doc, ps = gen.doc, gen.ps
    db = doc.entitydb
    estilo_tabla = None
    try:
        dic = doc.rootdict.get("ACAD_TABLESTYLE")
        if dic is not None:
            for nombre in ("HMV-TABLA", "HMV", "Standard"):
                if nombre in dic:
                    estilo_tabla = dic[nombre].dxf.handle
                    break
            if estilo_tabla is None and len(dic):
                estilo_tabla = next(iter(dic.values())).dxf.handle
    except Exception:
        estilo_tabla = None
    for nombre, cpp in (("ACAD_TABLE", "AcDbTable"), ("FIELD", "AcDbField"), ("FIELDLIST", "AcDbFieldList")):
        try:
            if not any(c.dxf.name == nombre for c in doc.classes):
                doc.classes.add_class(nombre, cpp, "ObjectDBX Classes", flags=1152 if nombre != "ACAD_TABLE"
                                      else 1025, was_a_proxy=False, is_an_entity=(nombre == "ACAD_TABLE"))
        except Exception:
            pass
    info = {"tablas": [], "estilo": estilo_tabla}
    for t in getattr(gen, "tablas_spec", []) or []:
        ents = []
        for e in list(ps):
            try:
                if e.has_xdata(APPID) and any(v == t["id"] for c, v in e.get_xdata(APPID)):
                    ents.append(e)
            except Exception:
                pass
        if not ents:
            continue
        ox, oy = t["origen"]
        blk = doc.blocks.new_anonymous_block(type_char="T")
        movidos = []
        for e in ents:
            try:
                ps.move_to_layout(e, blk)
                e.translate(-ox, -oy, 0)
                movidos.append(e)
            except Exception:
                pass
        capa = ents[0].dxf.get("layer", "0")
        marca = ps.add_point((ox, oy, 0), dxfattribs={"layer": capa})
        celdas_f = [k for k, v in t["celdas"].items() if v.get("f")]
        handles = {k: (db.next_handle(), db.next_handle()) for k in celdas_f}
        info["tablas"].append({"spec": t, "bloque": blk.name, "bloque_h": blk.block_record_handle,
                               "marca": marca, "marca_h": marca.dxf.handle, "capa": capa,
                               "movidos": movidos, "campos": handles})
    return info


def restaurar(gen, info):
    """deshace preparar() en el documento en memoria."""
    doc, ps = gen.doc, gen.ps
    for ti in info.get("tablas", []):
        ox, oy = ti["spec"]["origen"]
        blk = doc.blocks.get(ti["bloque"])
        for e in ti["movidos"]:
            try:
                e.translate(ox, oy, 0)
                blk.move_to_layout(e, ps)
            except Exception:
                pass
        try:
            ps.delete_entity(ti["marca"])
        except Exception:
            pass
        try:
            doc.blocks.delete_block(ti["bloque"], safe=False)
        except Exception:
            pass


# ---------------------------------------------------------------------------
def _txt(pares, code, valor):
    pares.append((code, str(valor)))


def _texto_largo(pares, texto, primero=1, resto=2):
    """cadenas de más de 250 caracteres: trozos en `resto` y el último en `primero` (como AutoCAD)."""
    s = str(texto)
    while len(s) > 250:
        pares.append((resto, s[:250]))
        s = s[250:]
    pares.append((primero, s))


def _valor_celda(pares, texto, numero=None, fmt=""):
    pares.append((301, "CELL_VALUE"))
    _txt(pares, 93, 0)
    if numero is not None:
        _txt(pares, 90, 2)
        _txt(pares, 140, repr(float(numero)))
    else:
        _txt(pares, 90, 4)
        _texto_largo(pares, texto)
    _txt(pares, 94, 0)
    pares.append((300, fmt or ""))
    pares.append((302, texto))
    pares.append((304, "ACVALUE_END"))


def _bordes_ocultos(t):
    """lados de celda sin borde, incluido el lado compartido de la celda vecina."""
    nf, nc = len(t["altos"]), len(t["anchos"])
    ocultos = set()
    for item in t.get("sin_borde", []) or []:
        r, c, lado = item
        ocultos.add((r, c, lado))
        op, dr, dc = _OPUESTO[lado]
        r2, c2 = r + dr, c + dc
        if 0 <= r2 < nf and 0 <= c2 < nc:
            ocultos.add((r2, c2, op))
    return ocultos


def _entidad_tabla(ti, owner, extra_marca, estilo_texto, info_t1):
    t = ti["spec"]
    nf, nc = len(t["altos"]), len(t["anchos"])
    ox, oy = t["origen"]
    p = []
    p.append((0, "ACAD_TABLE"))
    _txt(p, 5, ti["marca_h"])
    _txt(p, 330, owner)
    p.append((100, "AcDbEntity"))
    p += extra_marca                     # 67 (espacio papel) / 410 (layout), como venía el marcador
    p.append((8, ti["capa"]))
    p.append((100, "AcDbBlockReference"))
    p.append((2, ti["bloque"]))
    for c, v in ((10, ox), (20, oy), (30, 0.0)):
        _txt(p, c, repr(float(v)))
    p.append((100, "AcDbTable"))
    _txt(p, 280, 0)
    if t.get("_estilo_h"):
        _txt(p, 342, t["_estilo_h"])
    _txt(p, 343, ti["bloque_h"])
    for c, v in ((11, 1.0), (21, 0.0), (31, 0.0)):
        _txt(p, c, v)
    _txt(p, 90, 22)
    _txt(p, 91, nf)
    _txt(p, 92, nc)
    for c in (93, 94, 95, 96):
        _txt(p, c, 0)
    for h in t["altos"]:
        _txt(p, 141, repr(float(h)))
    for w in t["anchos"]:
        _txt(p, 142, repr(float(w)))
    region = {}
    anclas = {}
    for (r0, c0, r1, c1) in t["combinadas"]:
        anclas[(r0, c0)] = (r1 - r0 + 1, c1 - c0 + 1)
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                if (r, c) != (r0, c0):
                    region[(r, c)] = (r0, c0)
    ocultos = _bordes_ocultos(t)
    for r in range(nf):
        for c in range(nc):
            cel = t["celdas"].get((r, c), {})
            cubierta = (r, c) in region
            _txt(p, 171, 1)
            _txt(p, 172, 0)
            _txt(p, 173, 1 if cubierta else 0)
            _txt(p, 174, 0)
            alto, ancho = anclas.get((r, c), (1, 1))
            _txt(p, 175, 0 if cubierta else ancho)
            _txt(p, 176, 0 if cubierta else alto)
            lados = [l for l in _LADOS if (r, c, l) in ocultos]
            bits = 0x01 | 0x10 | 0x20
            for l in lados:
                bits |= _LADOS[l][2]
            _txt(p, 91, bits)
            _txt(p, 92, 0)
            _txt(p, 178, 0)
            _txt(p, 145, 0.0)
            texto = "" if cubierta else str(cel.get("v", "") or "")
            if not cubierta and (r, c) in ti["campos"]:
                _txt(p, 344, ti["campos"][(r, c)][0])
            elif not cubierta and texto:
                num = cel.get("n")
                if num is None:
                    num = _numero(texto)
                _texto_largo(p, texto)
                _valor_celda(p, texto, num, cel.get("fmt", ""))
            p.append((7, t.get("estilo_texto") or estilo_texto))
            _txt(p, 140, repr(float(cel.get("h", 2.5))))
            _txt(p, 170, 5)
            for l in lados:
                lw, vis, _ = _LADOS[l]
                _txt(p, lw, -2)
                _txt(p, vis, 0)
    p += [(1001, APPID), (1000, t["id"])]
    return p


def _campos(ti, mapa_tablas):
    """objetos FIELD de las celdas con fórmula de una tabla."""
    t = ti["spec"]
    tabla_h = ti["marca_h"]
    p = []
    for (r, c), (h_cont, h_form) in ti["campos"].items():
        cel = t["celdas"][(r, c)]
        f = str(cel["f"]).strip()
        objetos = []
        if f.startswith("@"):            # referencia a otra tabla: @T1 -> su celda total
            otra = mapa_tablas.get(f[1:])
            if otra is None:
                continue
            objetos = [otra["marca_h"]]
            f = f"(Table(%<\\_ObjIdx 0>%).{otra['spec'].get('celda_total') or 'A1'})"
        fmt = cel.get("fmt", "")
        codigo = "\\AcExpr " + f + (f' \\f "{fmt}"' if fmt else "")
        texto = str(cel.get("v", ""))
        num = cel.get("n")
        if num is None:
            num = _numero(texto)
        # contenedor «_text» (dueño: la tabla)
        p += [(0, "FIELD"), (5, h_cont), (330, tabla_h), (100, "AcDbField"), (1, "_text")]
        _texto_largo(p, "%<\\_FldIdx 0>%", 2, 3)
        p += [(90, "1"), (360, h_form), (97, "0"), (91, "63"), (92, "0"), (94, "9"), (95, "2"), (96, "0"),
              (300, ""), (93, "0"), (7, "ACFD_FIELD_VALUE"),
              (93, "3"), (90, "0"), (94, "0"), (300, ""), (302, ""), (304, "ACVALUE_END"),
              (301, texto), (98, str(len(texto)))]
        # fórmula «AcExpr» (dueño: el contenedor)
        p += [(0, "FIELD"), (5, h_form), (330, h_cont), (100, "AcDbField"), (1, "AcExpr")]
        _texto_largo(p, codigo, 2, 3)
        p += [(90, "0"), (97, str(len(objetos)))]
        p += [(331, h) for h in objetos]
        p += [(91, "63"), (92, "0"), (94, "9"), (95, "2"), (96, "0"), (300, ""), (93, "0"),
              (7, "ACFD_FIELD_VALUE"), (93, "0")]
        if num is not None:
            p += [(90, "2"), (140, repr(float(num)))]
        else:
            p += [(90, "4"), (1, texto)]
        p += [(94, "0"), (300, fmt), (302, texto), (304, "ACVALUE_END"), (301, texto), (98, str(len(texto)))]
    return p


# ---------------------------------------------------------------------------
def _leer_pares(lineas):
    pares = []
    for i in range(0, len(lineas) - 1, 2):
        pares.append((lineas[i].strip(), lineas[i + 1]))
    return pares


def escribir(ruta_dxf, info, estilo_texto="TRANSELEC"):
    """reemplaza los POINT marcadores por ACAD_TABLE y agrega los FIELD en OBJECTS."""
    if not info.get("tablas"):
        return 0
    with open(ruta_dxf, encoding="utf-8", errors="surrogateescape") as fh:
        lineas = fh.read().split("\n")
    if lineas and lineas[-1] == "":
        lineas.pop()
    pares = _leer_pares(lineas)
    por_h = {ti["marca_h"].upper(): ti for ti in info["tablas"]}
    mapa = {ti["spec"]["id"]: ti for ti in info["tablas"]}
    for ti in info["tablas"]:
        ti["spec"]["_estilo_h"] = info.get("estilo")
    salida = []
    i, n = 0, len(pares)
    hechas = 0
    while i < n:
        c, v = pares[i]
        if c == "0" and v.strip() == "POINT" and i + 1 < n and pares[i + 1][0] == "5" \
                and pares[i + 1][1].strip().upper() in por_h:
            j = i + 1
            while j < n and pares[j][0] != "0":
                j += 1
            bloque = pares[i:j]
            owner = next((v2.strip() for c2, v2 in bloque if c2 == "330"), "0")
            extra = [(int(c2), v2.strip()) for c2, v2 in bloque if c2 in ("67", "410")]
            ti = por_h[pares[i + 1][1].strip().upper()]
            salida += [(str(cc), vv) for cc, vv in _entidad_tabla(ti, owner, extra, estilo_texto, None)]
            hechas += 1
            i = j
            continue
        salida.append((c, v))
        i += 1
    # FIELD al final de OBJECTS
    campos = []
    for ti in info["tablas"]:
        campos += [(str(cc), vv) for cc, vv in _campos(ti, mapa)]
    k = None
    en_objects = False
    for idx, (c, v) in enumerate(salida):
        if c == "2" and v.strip() == "OBJECTS" and idx > 0 and salida[idx - 1] == ("0", salida[idx - 1][1]) \
                and salida[idx - 1][1].strip() == "SECTION":
            en_objects = True
        elif en_objects and c == "0" and v.strip() == "ENDSEC":
            k = idx
            break
    if k is not None:
        salida = salida[:k] + campos + salida[k:]
    with open(ruta_dxf, "w", encoding="utf-8", errors="surrogateescape", newline="\n") as fh:
        for c, v in salida:
            fh.write(f"{int(c):>3}\n{v}\n")
    return hechas
