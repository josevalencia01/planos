# -*- coding: utf-8 -*-
"""
Generador paramétrico del plano de fundación
Marco de Línea Doble Viga 220 kV  (SNA3027-A-JDR-47-CI-PL-0007-L0001)

Toma como plantilla el plano SNA3030-A-JDR-47-CI-PL-0004-L0001 (Marco de Barra,
convertido a DXF 2018) y redibuja por completo las vistas de fundación,
las tablas N°1, N°2 y N°3, la viñeta y las referencias a partir de los
parámetros (por defecto, los de la planilla "01_Procedimiento_E").

Unidades de los parámetros: cm (salvo indicación). Unidades del dibujo: mm.

Uso por línea de comandos:
    python plano_fundacion.py                      -> genera salida/<codigo>.dxf (+ .dwg si hay conversor)
    python plano_fundacion.py --params mis.json    -> usa parámetros de un JSON
    python plano_fundacion.py --dump-params        -> escribe parametros_por_defecto.json
"""
from __future__ import annotations

import copy
import json
import math
import os
import re
import shutil
import subprocess
import sys

import desconectador as DT
from decimal import Decimal, ROUND_HALF_UP

import ezdxf
from ezdxf import bbox
from ezdxf.math import Matrix44, Vec3

AQUI = os.path.dirname(os.path.abspath(__file__))
PLANTILLA = os.path.join(AQUI, "plantilla", "plantilla_base.dxf")

# --------------------------------------------------------------------------
# PARÁMETROS POR DEFECTO  (planilla 01_Procedimiento_E · Marco Línea Doble Viga)
# --------------------------------------------------------------------------
# Cada entrada: clave -> (valor, grupo, etiqueta)
PARAM_DEF = {
    # --- Zapata y pedestales (hoja Fund / GralFund) ---
    "Lfx":        (170.0, "Zapata y pedestales", "Longitud zapata en X, Lfx (cm)  [vertical en planta]"),
    "Lfy":        (420.0, "Zapata y pedestales", "Longitud zapata en Y, Lfy (cm)  [horizontal en planta]"),
    "HLf":        (45.0,  "Zapata y pedestales", "Espesor losa zapata, HLf (cm)"),
    "ped_x":      (70.0,  "Zapata y pedestales", "Ancho pedestal en X, PedX (cm)"),
    "ped_y":      (70.0,  "Zapata y pedestales", "Ancho pedestal en Y, PedY (cm)"),
    "n_ped":      (2,     "Zapata y pedestales", "Cantidad de pedestales en Y (columnas, horizontal en planta)"),
    "dist_ped":   (130.0, "Zapata y pedestales", "Distancia libre entre pedestales, DistY (cm)"),
    "n_ped_x":    (1,     "Zapata y pedestales", "Cantidad de pedestales en X (filas, vertical en planta)"),
    "dist_ped_x": (130.0, "Zapata y pedestales", "Distancia libre entre pedestales en X, DistX (cm)"),
    "dPd":        (35.0,  "Zapata y pedestales", "Altura pedestal sobre nivel de patio, dPd (cm)"),
    "Df":         (160.0, "Zapata y pedestales", "Profundidad sello de fundación, Df (cm)"),
    "e_grava":    (20.0,  "Zapata y pedestales", "Espesor acabado de patio grava (cm)"),
    "e_emp":      (5.0,   "Zapata y pedestales", "Espesor emplantillado, eEmp (cm)"),
    "e_grout":    (5.0,   "Zapata y pedestales", "Espesor vaciado secundario / grout (cm)"),
    "placa":      (60.0,  "Zapata y pedestales", "Lado placa base para volumen de grout (cm)"),
    "sobreexc":   (45.0,  "Zapata y pedestales", "Profundidad adicional excavación máx. (cm)"),
    "q_exc":      (0.0,   "Zapata y pedestales", "Vol. excavación por fundación (m³, 0 = calculado)"),
    "q_rell":     (0.0,   "Zapata y pedestales", "Vol. relleno por fundación (m³, 0 = calculado)"),
    "q_grout":    (0.0,   "Zapata y pedestales", "Vol. grouting por fundación (lt, 0 = calculado)"),
    # --- Recubrimientos ---
    "rec_inf":    (7.5, "Recubrimientos", "ZAPATA – recubrimiento inferior (cm)"),
    "rec_sup":    (7.5, "Recubrimientos", "ZAPATA – recubrimiento superior (cm)"),
    "rec_lat":    (7.5, "Recubrimientos", "ZAPATA – recubrimiento lateral, ambas direcciones (cm)"),
    "rec_lat_x":  (0.0, "Recubrimientos", "ZAPATA – lateral en las caras perpendiculares a X (cm; 0 = el lateral)"),
    "rec_lat_y":  (0.0, "Recubrimientos", "ZAPATA – lateral en las caras perpendiculares a Y (cm; 0 = el lateral)"),
    "rec_ped":    (7.5, "Recubrimientos", "PEDESTAL – recubrimiento lateral libre a estribos (cm)"),
    "rec_ped_sup": (5.0, "Recubrimientos", "PEDESTAL – recubrimiento superior de las barras (cm)"),
    # --- Armadura losa (hoja Detallado) ---
    "db_x":       (12,   "Armadura zapata", "Ø barras dirección X (mm)  [barras paralelas a Lfx]"),
    "n_x":        (29,   "Armadura zapata", "N° barras dir. X por capa (2 esquina + repartidas)"),
    "s_x":        (15.0, "Armadura zapata", "Separación barras dir. X (cm)"),
    "esq_x":      (0.0,  "Armadura zapata", "Dist. barra de esquina a 1ª repartida, dir. X (cm; 0 = repartidas centradas @s)"),
    "db_y":       (12,   "Armadura zapata", "Ø barras dirección Y (mm)  [barras paralelas a Lfy]"),
    "n_y":        (12,   "Armadura zapata", "N° barras dir. Y por capa (2 esquina + repartidas)"),
    "s_y":        (15.0, "Armadura zapata", "Separación barras dir. Y (cm)"),
    "esq_y":      (0.0,  "Armadura zapata", "Dist. barra de esquina a 1ª repartida, dir. Y (cm; 0 = repartidas centradas @s)"),
    # --- Armadura pedestal ---
    "db_ped":     (22,   "Armadura pedestal", "Ø barras longitudinales pedestal (mm)"),
    "n_cara":     (3,    "Armadura pedestal", "Barras por cara del pedestal"),
    "n_cara_b":   (0,    "Armadura pedestal", "Barras por cara en el otro sentido del pedestal (0 = igual que n_cara)"),
    "gancho_ped": (40.0, "Armadura pedestal", "Gancho barras pedestal, b (cm)"),
    "db_est":     (10,   "Armadura pedestal", "Ø estribos y trabas (mm)"),
    "est_reparto": ("Automático entre recubrimientos", "Armadura pedestal", "Reparto de estribos"),
    "cc_cota_rec": ("Recubrimiento libre (7,5 a cara del estribo)", "Armadura pedestal", "Cotas de borde en sección C-C"),
    "n_est":      (9,    "Armadura pedestal", "Cantidad de estribos por pedestal (reparto fijo; desde la losa: 0 = hasta el tope)"),
    "est_ini":    (5.0,  "Armadura pedestal", "Desde la losa: distancia de la cara superior de la losa al 1er estribo (cm)"),
    "est_extra":  ("",   "Armadura pedestal", "Estribos adicionales: alturas en cm sobre la losa, separadas por ';' (ej. 160;172)"),
    "s_est":      (16.0, "Armadura pedestal", "Separación estribos (cm; máxima en reparto automático)"),
    "est_top":    (7.5,  "Armadura pedestal", "Distancia tope pedestal a 1er estribo (cm)"),
    "est_bot":    (7.5,  "Armadura pedestal", "Distancia último estribo a cara sup. losa (cm, reparto automático)"),
    "est_ajuste": ("Sobrante abajo", "Armadura pedestal", "Reparto automático: dónde queda lo que sobra al redondear la separación"),
    "gancho_est": (10.0, "Armadura pedestal", "Gancho estribos/trabas, c (cm)"),
    "n_trabas":   (1,    "Armadura pedestal", "Trabas (1002) por nivel, en un sentido (paralelas a ped_x)"),
    "n_trabas_b": (-1,   "Armadura pedestal", "Trabas por nivel en el otro sentido (paralelas a ped_y; -1 = igual)"),
    "a_ped":      (0.0,  "Armadura pedestal", "Largo recto barra pedestal a (cm, 0 = automático)"),
    "gancho_losa": (0.0, "Armadura zapata", "Gancho barras de losa b (cm, 0 = HLf − rec. inf − rec. sup)"),
    "marca_x":    ("",   "Armadura zapata", "Marca barras dir. X (vacío = automática)"),
    "marca_y":    ("",   "Armadura zapata", "Marca barras dir. Y (vacío = automática)"),
    "marca_ped":  ("",   "Armadura pedestal", "Marca barras pedestal (vacío = automática)"),
    # --- Pernos de anclaje (tabla N°3) ---
    "perno_txt":  ('7/8"', "Pernos de anclaje", "Diámetro nominal perno (texto)"),
    "perno_d":    (22.23, "Pernos de anclaje", "Ø perno (mm)"),
    "perno_desc": ("A7.900", "Pernos de anclaje", "Designación perno"),
    "perno_sep":  (30.0, "Pernos de anclaje", "Separación entre pernos (cm)"),
    "pernos_ped": (4,    "Pernos de anclaje", "Pernos por pedestal (disposición estándar; en rejilla o manual se cuentan solos)"),
    "pernos_disp": ("Estándar (según tipo de plano, @ perno_sep)", "Pernos de anclaje", "Disposición de los pernos en el pedestal"),
    "pernos_nx":  (2,    "Pernos de anclaje", "Rejilla: columnas de pernos (horizontal en planta)"),
    "pernos_ny":  (2,    "Pernos de anclaje", "Rejilla: filas de pernos (vertical en planta)"),
    "pernos_sx":  (30.0, "Pernos de anclaje", "Rejilla: separación entre columnas (cm)"),
    "pernos_sy":  (30.0, "Pernos de anclaje", "Rejilla: separación entre filas (cm)"),
    "pernos_dx":  (0.0,  "Pernos de anclaje", "Rejilla: corrimiento del grupo respecto del centro del pedestal, horizontal (cm)"),
    "pernos_dy":  (0.0,  "Pernos de anclaje", "Rejilla: corrimiento del grupo respecto del centro del pedestal, vertical (cm)"),
    "pernos_espejo": ("No (igual en todos los pedestales)", "Pernos de anclaje", "Pernos de los otros pedestales"),
    "P":   (105, "Pernos de anclaje", "P (mm)"),
    "G":   (50,  "Pernos de anclaje", "G (mm)"),
    "Lr":  (160, "Pernos de anclaje", "Lr (mm)"),
    "C":   (35,  "Pernos de anclaje", "C (mm)"),
    "Ldh": (710, "Pernos de anclaje", "Ldh (mm)"),
    "L":   (900, "Pernos de anclaje", "L (mm)"),
    "Lg":  (100, "Pernos de anclaje", "Lg (mm)"),
    "Eg":  (20.0, "Pernos de anclaje", "Eg (mm)"),
    "PERF": (28.0, "Pernos de anclaje", "PERF (mm)"),
    "tabla3_estilo": ("Completa (descripción + por pedestal + total)", "Pernos de anclaje", "Formato de la tabla N°3"),
    # --- Esquema de distribución (imagen) ---
    "sep_ejes":   (1720.0, "Esquema", "Distancia entre ejes de marcos (cm)"),
    "seps_ejes":  ("",     "Esquema", "Distancias entre ejes, una por tramo (cm, separadas por ';'; ej. 2800;3100 · vacío = todas iguales)"),
    "sep_patas":  (200.0,  "Esquema", "Separación entre filas de patas / zapatas (cm, vertical en esquema)"),
    "n_filas":    (2,      "Esquema", "Cantidad de filas de fundaciones por eje"),
    "seps_filas": ("",     "Esquema", "Separaciones entre filas, una por tramo (cm, separadas por ';' · vacío = todas iguales)"),
    "nodos_izq":  ("1XY,1Y,1X,1P", "Esquema", "Nodos extremo izq. (sup-izq, sup-der, inf-izq, inf-der)"),
    "nodos_der":  ("1XYE0.0P,1YE0.0P,1XE0.0P,1E0.0P", "Esquema", "Nodos extremo der. (sup-izq, sup-der, inf-izq, inf-der)"),
    "n_ejes":     (2, "Esquema", "Cantidad de ejes de marco (pórticos)"),
    "nodos_ejes": ("", "Esquema", "Nodos por eje, separados por ';' (vacío = usar izq./der.)"),
    "n_fund":     (4,      "Esquema", "Cantidad total de fundaciones (tabla N°2; 0 = las dibujadas en el esquema)"),
    # --- Ejes (círculos de eje de todas las vistas) ---
    "eje_txt_sup":   ("EJE",   "Ejes y textos", "Texto superior de los círculos de eje"),
    "eje_txt_num":   ("NUM",   "Ejes y textos", "Nombre de los ejes numéricos (p. ej. 1, 2, 3)"),
    "eje_txt_letra": ("LETRA", "Ejes y textos", "Nombre de los ejes con letra (p. ej. A, B, C)"),
    # --- Escalas de vistas ---
    "esc_planta": (35,  "Escalas", "Escala planta 1:"),
    "esc_aaf":    (35,  "Escalas", "Escala sección A-A formas 1:"),
    "esc_bbf":    (35,  "Escalas", "Escala sección B-B formas 1:"),
    "esc_aaa":    (35,  "Escalas", "Escala sección A-A armaduras 1:"),
    "esc_bba":    (35,  "Escalas", "Escala sección B-B armaduras 1:"),
    "esc_cc":     (10,  "Escalas", "Escala sección C-C 1:"),
    "esc_esq":    (100, "Escalas", "Escala esquema 1:"),
    "escala_auto": ("Sí", "Escalas", "Si una vista no cabe en su ventana, subir su escala sola"),
    # --- Formato de hoja ---
    "plantilla":  ("", "Formato", "Plantilla DWG/DXF base (vacío = plantilla incluida)"),
    "hoja":       ("A1", "Formato", "Tamaño de hoja"),
    "formato":    ("Original (Transelec/HMV)", "Formato", "Formato / viñeta"),
    "formato_archivo": ("", "Formato", "Archivo de formato del cliente (DXF/DWG)"),
    "ctb":        ("GN-PLOT-HMV.ctb", "Formato", "Estilo de ploteo CTB asignado a la lámina"),
    "papel_plot": ("Según plantilla", "Formato", "Papel de ploteo de la lámina (configuración de página)"),
    "tablas_dxf": ("Sí", "Formato", "Tablas con fórmulas dentro del DXF (AutoCAD y Open CAD Studio)"),
    "cota_flechas": ("Flechas rellenas (afuera en tramos cortos)", "Formato", "Terminación de las cotas"),
    # --- Viñeta y textos ---
    "codigo":     ("SNA3027-A-JDR-47-CI-PL-0007-L0001", "Viñeta", "Código del plano"),
    "titulo1":    ("PLANO DE DISEÑO DE FUNDACIÓN", "Viñeta", "Descripción línea 1"),
    "titulo2":    ("MARCO DE LÍNEA DOBLE VIGA", "Viñeta", "Descripción línea 2"),
    "titulo3":    ("220 kV", "Viñeta", "Descripción línea 3"),
    "titulo4":    ("", "Viñeta", "Descripción línea 4"),
    "estructura": ("MARCO DE LÍNEA DOBLE VIGA 220 kV", "Viñeta", "Nombre estructura (títulos de vistas)"),
    "cliente":    ("TRANSELEC", "Viñeta", "Cliente / mandante"),
    "instalacion": ("SUBESTACIÓN JADRESIC (EX PARINAS) 500/220/66 kV", "Viñeta", "Instalación / proyecto"),
    "area":       ("ESTRUCTURAS ALTAS SUBESTACIÓN", "Viñeta", "Área / especialidad"),
    "proyecto":   ("J.V.G.", "Viñeta", "Proyectó"),
    "dibujo":     ("J.V.G.", "Viñeta", "Dibujó"),
    "reviso":     ("O.A.C.", "Viñeta", "Revisó"),
    "aprobo":     ("J.O.R.", "Viñeta", "Aprobó"),
    "reviso_cliente": ("", "Viñeta", "Revisó (viñeta del cliente)"),
    "aprobo_cliente": ("", "Viñeta", "Aprobó (viñeta del cliente)"),
    "fecha_txt":  ("NOVIEMBRE 2026", "Viñeta", "Fecha (texto de viñeta)"),
}

# opciones de los parámetros que se eligen de una lista
OPCIONES = {
    "hoja": ["A0", "A1", "A2", "A3", "A4"],
    "formato": ["Original (Transelec/HMV)", "Genérico (editable)", "Personalizado (archivo del cliente)"],
    "tabla3_estilo": ["Completa (descripción + por pedestal + total)", "Compacta (cantidad por fundación)"],
    "ctb": ["GN-PLOT-HMV.ctb", "GN-FIT-HMV.ctb"],
    "papel_plot": ["Según plantilla", "A0", "A1", "A2", "A3", "A4"],
    "tablas_dxf": ["Sí", "No (sólo dibujadas)"],
    "escala_auto": ["Sí", "No (respetar las escalas indicadas)"],
    "cota_flechas": ["Flechas rellenas (afuera en tramos cortos)", "Trazo oblicuo (estilo TRANSELEC)"],
    "est_reparto": ["Automático entre recubrimientos", "Cantidad fija (n_est @ s_est)", "Manual (posiciones)",
                    "Desde la losa (1° a est_ini, luego @ s_est)"],
    "tipo_plano": [DT.TIPO_MARCO, DT.TIPO_DT],
    **DT.OPCIONES,
    "est_ajuste": ["Sobrante abajo", "Sobrante arriba", "Separación exacta (sin redondear)"],
    "cc_cota_rec": ["Recubrimiento libre (7,5 a cara del estribo)", "Al eje de las barras"],
    "pernos_disp": ["Estándar (según tipo de plano, @ perno_sep)", "Rejilla (filas × columnas)", "Manual (coordenadas)"],
    "pernos_espejo": ["No (igual en todos los pedestales)", "Simétricos respecto de los ejes de la fundación (espejo)"],
}
HOJAS = {"A0": (1189.0, 841.0), "A1": (841.0, 594.0), "A2": (594.0, 420.0),
         "A3": (420.0, 297.0), "A4": (297.0, 210.0)}
ESCALAS_STD = [1, 2, 5, 10, 15, 20, 25, 30, 35, 40, 50, 60, 75, 100, 125, 150, 200, 250, 300, 400, 500]

PARAM_DEF = {"tipo_plano": (DT.TIPO_MARCO, "Formato", "Tipo de plano"), **PARAM_DEF, **DT.PARAMS}
DEFAULTS = {k: v[0] for k, v in PARAM_DEF.items()}

# ---- datos estructurados (listas editables tipo tabla) ----
NOTAS_DEF = [
    "DIMENSIONES EN cm Y DIÁMETRO DE BARRAS Y PERNOS EN mm, EXCEPTO DONDE SE INDIQUE OTRA UNIDAD.",
    "EL MORTERO DE NIVELACIÓN O GROUTING DEBERÁ TENER 50 mm DE ESPESOR, Y DEBERÁ SER DE CALIDAD IGUAL O SUPERIOR AL "
    "HORMIGÓN ESTRUCTURAL. ESTE SERÁ VACIADO UNA VEZ NIVELADA Y POSICIONADA LA ESTRUCTURA PARA LA REALIZACIÓN DE LAS "
    "PRUEBAS DE CARGA.",
    "LOS PERNOS DE ANCLAJE SERÁN INSTALADOS ORTOGONAL Y VERTICALMENTE UTILIZANDO PLANTILLA DE FIJACIÓN.",
    "EL RECUBRIMIENTO MÍNIMO DE LA ARMADURA PARA EL HORMIGÓN DE TODA LA FUNDACIÓN SERÁ COMO MÍNIMO 7,5 cm.",
    "TODA LA ARMADURA SERÁ AMARRADA, NO SE USARÁ SOLDADURA.",
    "PARA LA COLOCACIÓN DEL MORTERO DE NIVELACIÓN O GROUTING SE UTILIZARÁ UN IMPRIMANTE TIPO SIKADUR 32 PRIMER O "
    "EQUIVALENTE COMO PUENTE DE ADHERENCIA.",
    "ESPECIFICACIONES DE MATERIALES:\n"
    "- HORMIGÓN ESTRUCTURAL f'c=35 MPa (G35) CONFORME CON LAS NORMAS CHILENAS NCH 170 OF 16.\n"
    "- EMPLANTILLADO f'c=10 MPa (G10) CONFORME CON LAS NORMAS CHILENAS NCH 170 OF 16.\n"
    "- ACERO DE ARMADURA fy=420 MPa CALIDAD A630-420H CONFORME CON LAS NORMAS CHILENAS NCH 204 OF 2006, NCH 211 OF 70 Y NCH 434 OF 70.\n"
    "- PERNOS DE ANCLAJE ACERO ASTM A193 GRADO B7, CON RESISTENCIA MÍNIMA fy=720 MPa Y fu=860 MPa Y RESILIENCIA "
    "GARANTIZADA DE 27 J A -10%%DC SEGÚN ENSAYOS DE IMPACTO CHARPY V-NOTCH.\n"
    "- TUERCAS: ACERO ASTM A194.\n"
    "- GOLILLAS: ACERO ASTM F436.",
    "PARA HORMIGÓN ESTRUCTURAL SE DEBE CONSIDERAR LO INDICADO EN CAPÍTULO 11 DE MECÁNICA DE SUELOS USO DE CEMENTOS "
    "PUZOLÁNICOS CON UN CONTENIDO DE ALUMINATOS TRICÁLCICOS INFERIOR A 3%. II. UTILIZAR HORMIGONES DENSOS CON LA MENOR "
    "RELACIÓN AGUA-CEMENTO POSIBLE QUE PERMITA OBTENER UNA BUENA TRABAJABILIDAD Y RESISTENCIA.",
    "LOS PERNOS DE ANCLAJE DEBEN LLEVAR CINCO TUERCAS, UNA GOLILLA DE PRESIÓN, UNA GOLILLA PLANA Y LOS ACCESORIOS "
    "MOSTRADOS EN EL ESQUEMA DEL PERNO. DURANTE LA INSTALACIÓN, SE DEBE GARANTIZAR QUE LA LONGITUD PARA LA FIJACIÓN DEL "
    "EQUIPO CONSIDERANDO EL ESPESOR DE GROUTING, QUEDE LIBRE CUANDO SE REALICE EL VACIADO DEL CONCRETO EN SU NIVEL TERMINADO.",
    "TODOS LOS ELEMENTOS DEL PERNO DE ANCLAJE DEBEN SER GALVANIZADOS POR EL MÉTODO DE INMERSIÓN EN CALIENTE, DESPUÉS DE "
    "HABER SIDO CORTADOS Y MAQUINADOS. EL GALVANIZADO DEBE CUMPLIR CON LAS NORMAS ASTM A143, ASTM A153 Y ASTM A123.",
    "SE DEBERÁ EFECTUAR EL CURADO DEL HORMIGÓN DE ACUERDO A LAS ESPECIFICACIONES TÉCNICAS Y A LAS NORMAS VIGENTES, "
    "ASEGURANDO LA HUMECTACIÓN PERMANENTE DURANTE EL PERÍODO INDICADO PARA GARANTIZAR EL DESARROLLO ADECUADO DE LA RESISTENCIA.",
    "LA EJECUCIÓN DE LA CONSTRUCCIÓN DE LAS FUNDACIONES DEBERÁ AJUSTARSE A LAS RECOMENDACIONES CONSTRUCTIVAS PRESENTADAS "
    "EN LA MECÁNICA DE SUELOS SNA3030-A-JDR-02-CI-INFO-0002 Y ESPECIFICACIONES TÉCNICAS GENERALES DEL MANDANTE.",
    "LA DISTANCIA ENTRE PERNOS CORRESPONDE A LA DISTANCIA DE LAS PERFORACIONES DE LA PLACA BASE DE LA ESTRUCTURA. SE DEBE "
    "VERIFICAR LA DISTANCIA PARA ASEGURAR EL CORRECTO CALCE.",
    "LAS ARISTAS A LA VISTA DEBEN TENER UN ACABADO DE BISEL DE 2x2 cm.",
    "EN CASO DE ENCONTRAR RESTOS DE FUNDACIONES ANTIGUAS O ELEMENTOS ESTRUCTURALES ENTERRADOS, ESTOS DEBERÁN SER "
    "EXTRAÍDOS Y LAS SOBREEXCAVACIONES PRODUCIDAS RELLENADAS CON SUELO DE RELLENO ESPECIFICADO O CON HORMIGÓN POBRE Y "
    "BOLÓN DESPLAZADOR, POR RECOMENDACIÓN DEL ESTUDIO DE MECÁNICA DE SUELO.",
    "LAS ZAPATAS DEBERÁN SER HORMIGONADAS DIRECTAMENTE CONTRA EL TERRENO NATURAL O MATERIAL DE REEMPLAZO COMPACTADO "
    "(FUNDACIÓN IN SITU), SIN USO DE FORMALETA LATERAL NI ESPACIOS ENTRE EL HORMIGÓN Y EL SUELO CIRCUNDANTE.",
]
REFERENCIAS_DEF = [
    ["SNA3030-A-JDR-02-CI-INFO-0002", "ESTUDIO DE MECÁNICA DE SUELOS"],
    ["SNA3027-A-JDR-63-ES-MCAL-XXXX", "MEMORIA DE CÁLCULO FUNDACIÓN MARCO DE LÍNEA DOBLE VIGA 220 kV"],
    ["SNA3027-A-JDR-47-CI-PL-XXXX", "PLANO DE FABRICACIÓN ESTRUCTURA MARCO DE LÍNEA DOBLE VIGA 220 kV"],
]
COLS_REV = ["Rev.", "Fecha", "Descripción", "Ejecutó", "Revisó", "Aprobó"]
REVISIONES_DEF = [["A", "03-11-2026", "EMITIDO PARA REVISIÓN", "J.V.G.", "O.A.C.", "J.O.R."]]
# campos de la viñeta genérica: {clave} se reemplaza por el parámetro del mismo nombre
CAMPOS_DEF = [
    ["CLIENTE", "{cliente}"], ["INSTALACIÓN", "{instalacion}"], ["ÁREA", "{area}"],
    ["TÍTULO", "{titulo1} {titulo2} {titulo3} {titulo4}"], ["N° PLANO", "{codigo}"], ["REVISIÓN", "{rev}"],
    ["ESCALA", "INDICADAS"], ["FORMATO", "{hoja}"], ["PROYECTÓ", "{proyecto}"], ["DIBUJÓ", "{dibujo}"],
    ["REVISÓ", "{reviso}"], ["APROBÓ", "{aprobo}"], ["FECHA", "{fecha_txt}"], ["EMPRESA", "HMV INGENIEROS"],
]
DEFAULTS_LISTAS = {
    "notas": NOTAS_DEF,
    "referencias": REFERENCIAS_DEF,
    "revisiones": REVISIONES_DEF,
    "vineta_campos": CAMPOS_DEF,      # viñeta genérica
    "vineta_extra": [],               # datos adicionales sobre viñeta original / del cliente
    "vineta_attr": {},                # valores editados a mano en atributos/textos del formato
    "capas_off": None,                # None = estado de la plantilla
    "cotas_mod": {},                  # cotas editadas: id -> {"texto", "oculta", "desp"}
    "cotas_extra": [],                # cotas agregadas: [vista, x1, y1, x2, y2, xb, yb, tipo, texto]
    "est_pos": [],                    # estribos en reparto manual: cm desde el tope del pedestal
    "notas_juntas": [],               # notas de juntas frías (plano de desconectador)
    "cotas_grupo": [],                # [vista, elemento, desde n°, hasta n°, distancia (mm papel), texto]
    "rotulos_extra": [],              # [vista, x punta, y punta, x texto, y texto, texto, color]
    "pernos_pos": [],                 # pernos en disposición manual: [x, y] cm desde el centro del pedestal
    "esq_fund": [],                   # fundaciones del esquema: [eje n°, fila n°, nodos (uno por pedestal), dibujar]
    "textos_mod": {},                 # textos del dibujo editados: id -> {"texto", "oculto", "dx", "dy", "attr"}
    "titulos_mod": {},                # títulos de vistas escritos a mano: vista -> texto
    "celdas_mod": {},                 # celdas de tablas escritas a mano: "T1:fila:col" -> texto
}
DEFAULTS.update(copy.deepcopy(DEFAULTS_LISTAS))


def normalizar_params(p: dict) -> dict:
    """Completa con valores por defecto y convierte parámetros antiguos (ref1..ref3, rev, fecha, motivo)."""
    q = copy.deepcopy(DEFAULTS)
    q.update(p or {})
    if any(k in (p or {}) for k in ("ref1", "ref2", "ref3")) and "referencias" not in (p or {}):
        q["referencias"] = [list((p[k].split("\t") + [""])[:2]) for k in ("ref1", "ref2", "ref3") if p.get(k)]
    if "rev" in (p or {}) and "revisiones" not in (p or {}):
        q["revisiones"] = [[p.get("rev", "A"), p.get("fecha", ""), p.get("motivo", ""),
                            p.get("dibujo", ""), p.get("reviso", ""), p.get("aprobo", "")]]
    for k in ("ref1", "ref2", "ref3", "rev", "fecha", "motivo"):
        q.pop(k, None)
    if not str(q.get("pernos_disp", "")).startswith("Estándar"):
        q["pernos_ped"] = len(pernos_base(q))
    revs = q.get("revisiones") or [["", "", "", "", "", ""]]
    q["rev"] = revs[-1][0] if revs else ""
    q["fecha"] = revs[-1][1] if revs else ""
    return q


# --------------------------------------------------------------------------
# PERNOS DE ANCLAJE: disposición libre
# --------------------------------------------------------------------------
# Coordenadas (cm) desde el centro del pedestal: u = horizontal en la planta, v = vertical en la planta.
def _num(v):
    return float(str(v).strip().replace(",", "."))


def pernos_base(p):
    """disposición de los pernos de un pedestal (sin espejo), lista de (u, v) en cm."""
    disp = str(p.get("pernos_disp") or "")
    if disp.startswith("Manual"):
        pts = []
        for f in p.get("pernos_pos") or []:
            try:
                pts.append((_num(f[0]), _num(f[1])))
            except (ValueError, TypeError, IndexError):
                continue
        if pts:
            return pts
    if disp.startswith("Rejilla"):
        nx, ny = max(int(p.get("pernos_nx") or 1), 1), max(int(p.get("pernos_ny") or 1), 1)
        sx, sy = float(p.get("pernos_sx") or 0.0), float(p.get("pernos_sy") or 0.0)
        dx, dy = float(p.get("pernos_dx") or 0.0), float(p.get("pernos_dy") or 0.0)
        return [(round(dx + (i - (nx - 1) / 2.0) * sx, 4), round(dy + ((ny - 1) / 2.0 - j) * sy, 4))
                for j in range(ny) for i in range(nx)]
    s = float(p.get("perno_sep") or 0.0) / 2.0
    if DT.es_dt(p):
        return [(-s, 0.0), (s, 0.0)]
    return [(-s, s), (s, s), (-s, -s), (s, -s)]


def pernos_espejo(p, cx=0.0, cy=0.0):
    """signos (su, sv) del pedestal cuyo centro está en (cx, cy) cm respecto de los ejes de la fundación."""
    if not str(p.get("pernos_espejo", "")).startswith("Simétricos"):
        return 1, 1
    return (-1 if cx > 1e-6 else 1), (-1 if cy < -1e-6 else 1)


def pernos_xy(p, cx=0.0, cy=0.0):
    su, sv = pernos_espejo(p, cx, cy)
    return [(su * u, sv * v) for (u, v) in pernos_base(p)]


def pernos_proy(p, eje, cx=0.0, cy=0.0):
    """coordenadas distintas (cm) de los pernos proyectados sobre el eje 'u' o 'v' (lo que se ve en un corte)."""
    i = 0 if eje == "u" else 1
    return sorted({round(q[i], 4) for q in pernos_xy(p, cx, cy)})


PLANTILLAS_PERNOS = {
    "4 en cuadro (30 × 30)": [[-15, 15], [15, 15], [-15, -15], [15, -15]],
    "2 en línea (horizontal)": [[-15, 0], [15, 0]],
    "6 en L (esquina, @16)": [[-16, 16], [-16, 0], [0, 0], [-16, -16], [0, -16], [16, -16]],
    "8 en marco (3 × 3 sin centro, @16)": [[-16, 16], [0, 16], [16, 16], [-16, 0], [16, 0],
                                           [-16, -16], [0, -16], [16, -16]],
    "9 en rejilla 3 × 3 (@16)": [[x, y] for y in (16, 0, -16) for x in (-16, 0, 16)],
}


# --------------------------------------------------------------------------
# ESQUEMA: fundaciones, nodos y distancias independientes
# --------------------------------------------------------------------------
def _lista_cm(txt, n, defecto):
    """'2800;3100' -> n valores (el último se repite; vacío = defecto)."""
    vals = []
    for t in str(txt or "").replace("\n", ";").split(";"):
        try:
            if t.strip():
                vals.append(_num(t))
        except ValueError:
            pass
    if not vals:
        vals = [float(defecto)]
    while len(vals) < n:
        vals.append(vals[-1])
    return vals[:n]


def esquema_grilla(p):
    """(x de cada eje, y de cada fila) en cm, centrados; distancias independientes entre ejes/filas."""
    ne = max(int(p.get("n_ejes", 2) or 1), 1)
    nf = max(int(p.get("n_filas", 2) or 1), 1)
    dx = _lista_cm(p.get("seps_ejes"), ne - 1, p.get("sep_ejes", 1720.0))
    dy = _lista_cm(p.get("seps_filas"), nf - 1, p.get("sep_patas", 200.0))
    xs = [0.0]
    for d in dx:
        xs.append(xs[-1] + d)
    ys = [0.0]
    for d in dy:
        ys.append(ys[-1] - d)
    mx, my = (xs[0] + xs[-1]) / 2, (ys[0] + ys[-1]) / 2
    return [x - mx for x in xs], [y - my for y in ys]


def esquema_fundaciones(p):
    """filas [eje, fila, [nodos por pedestal], dibujar] (eje y fila desde 1). Si la tabla está vacía se arma
    con los nodos antiguos (nodos_izq / nodos_der / nodos_ejes: 4 por eje = 2 filas × 2 pedestales)."""
    ne = max(int(p.get("n_ejes", 2) or 1), 1)
    nf = max(int(p.get("n_filas", 2) or 1), 1)
    npd = max(int(p.get("n_ped", 2) or 1), 1) * (1 if DT.es_dt(p) else max(int(p.get("n_ped_x", 1) or 1), 1))
    filas = []
    tabla = p.get("esq_fund") or []
    if tabla:
        for f in tabla:
            f = list(f) + ["", "", "", ""]
            try:
                e, r = int(_num(f[0])), int(_num(f[1]))
            except ValueError:
                continue
            if not (1 <= e <= ne and 1 <= r <= nf):
                continue
            nodos = [t.strip() for t in str(f[2] or "").split(",")]
            dib = not str(f[3]).strip().lower().startswith("n")
            filas.append([e, r, nodos, dib])
        return filas
    if str(p.get("nodos_ejes", "")).strip():
        grupos = [grp.split(",") for grp in str(p["nodos_ejes"]).split(";")]
    else:
        grupos = [str(p.get("nodos_izq", "")).split(",")] + [str(p.get("nodos_der", "")).split(",")] * (ne - 1)
    for e in range(ne):
        nn = [t.strip() for t in (grupos[e] if e < len(grupos) else [])]
        for r in range(nf):
            nodos = nn[r * npd:(r + 1) * npd] if r < 2 and npd == 2 else []
            filas.append([e + 1, r + 1, nodos, True])
    return filas


def esquema_tabla_inicial(p):
    """tabla editable (texto) con todas las fundaciones de la grilla y sus nodos actuales."""
    q = dict(p)
    actuales = {(e, r): (n, d) for e, r, n, d in esquema_fundaciones(q)}
    out = []
    for e in range(1, max(int(p.get("n_ejes", 2) or 1), 1) + 1):
        for r in range(1, max(int(p.get("n_filas", 2) or 1), 1) + 1):
            n, d = actuales.get((e, r), ([], True))
            out.append([str(e), str(r), ",".join(n), "Sí" if d else "No"])
    return out


# --------------------------------------------------------------------------
# TEXTOS EDITABLES: títulos de vistas en texto simple <-> formato del plano
# --------------------------------------------------------------------------
_PIE = ("ESCALA", "SIN ESCALA", "VER ", "(VER")


def texto_plano(t):
    """MTEXT con códigos de formato -> texto simple, una línea por renglón."""
    try:
        from ezdxf.tools.text import plain_mtext
        return "\n".join(l.strip() for l in plain_mtext(str(t or ""), split=True) if l.strip())
    except Exception:
        return str(t or "")


def titulo_formateado(txt):
    """título escrito como texto simple (renglones) -> formato de los títulos del plano: renglones del
    título grandes en color 4 y los del pie (ESCALA…, VER…, SIN ESCALA) chicos en color 7.
    Si ya trae códigos de formato (\\H, \\C…) se usa tal cual."""
    txt = str(txt or "")
    if re.search(r"\\[HCpfFAQWT]", txt):
        return txt
    lineas = [l.strip() for l in txt.replace("\\P", "\n").split("\n") if l.strip()]
    if not lineas:
        return ""
    i = len(lineas)
    while i > 1 and lineas[i - 1].upper().startswith(_PIE):
        i -= 1
    sup, pie = lineas[:i], lineas[i:]
    t = "\\pxsm1.2,qc;{\\H1.4x;\\C4;" + " \\P".join(sup) + "\\C256; }"
    if pie:
        t += " \\P{\\C7;" + "\\P".join(pie) + "}"
    return t


def escala_efectiva(esc, f):
    """escala normalizada al reducir/ampliar la hoja (f = ancho hoja / 841)."""
    if abs(f - 1.0) < 1e-6:
        return float(esc)
    obj = esc / f
    for e in ESCALAS_STD:
        if e >= obj * 0.99:
            return float(e)
    return float(round(obj))

# masa lineal de barras (kg/m) – hoja Armaduras
MASA = {6: 0.222, 8: 0.395, 10: 0.617, 12: 0.888, 16: 1.58, 18: 2.0,
        22: 2.98, 25: 3.85, 28: 4.83, 32: 6.31, 36: 7.99}

K = 10.0  # cm -> mm


# --------------------------------------------------------------------------
# utilidades de formato
# --------------------------------------------------------------------------
def r2(x, n=2):
    q = Decimal(1).scaleb(-n)
    return float(Decimal(str(x)).quantize(q, rounding=ROUND_HALF_UP))


def fmt(x, dec=2, miles=False):
    """Formato chileno: coma decimal, punto de miles."""
    v = r2(x, dec)
    s = f"{v:,.{dec}f}" if miles else f"{v:.{dec}f}"
    return s.replace(",", "_").replace(".", ",").replace("_", ".")


def fmt_cm(x):
    """Dimensión en cm: entero si es exacto, si no 1 decimal."""
    v = r2(x, 1)
    if abs(v - round(v)) < 1e-9:
        return str(int(round(v)))
    return fmt(v, 1)


# --------------------------------------------------------------------------
# CÁLCULOS: geometría derivada, lista de barras y cantidades de obra
# --------------------------------------------------------------------------
def _sep_dominante(pos):
    """separación más repetida entre estribos consecutivos (para rótulos), redondeada a 0,1 cm."""
    import collections
    d = [round(b - a, 1) for a, b in zip(pos, pos[1:])]
    if not d:
        return 0.0
    return collections.Counter(d).most_common(1)[0][0]


def posiciones_estribos(p: dict) -> list:
    """posiciones de los estribos, en cm desde el tope del pedestal (tras ajustar_estribos)."""
    if p.get("_est_final") is not None:
        return [float(v) for v in p["_est_final"]]
    if str(p.get("est_reparto", "")).startswith("Manual") and p.get("est_pos"):
        return [float(v) for v in p["est_pos"]]
    return [p["est_top"] + i * p["s_est"] for i in range(int(p["n_est"]))]


def _alturas_extra(p):
    out = []
    for t in str(p.get("est_extra") or "").replace(",", ".").split(";"):
        try:
            if t.strip():
                out.append(float(t))
        except ValueError:
            pass
    return out


def ajustar_estribos(p: dict) -> dict:
    """reparto de estribos + estribos adicionales (est_extra, alturas sobre la losa) para cualquier reparto."""
    q = _ajustar_estribos_base(p)
    hpd = p["dPd"] + p["Df"] - p["HLf"]
    base = [float(v) for v in posiciones_estribos(dict(q, _est_final=None))]
    extra = [round(hpd - h, 2) for h in _alturas_extra(p) if 0 < h < hpd]
    if extra:
        todos = sorted(set(round(v, 2) for v in base + extra))
        q = dict(q)
        q["_est_final"] = todos
        q["n_est"] = len(todos)
    return q


def _ajustar_estribos_base(p: dict) -> dict:
    """Reparto automático: estribos entre est_top (bajo el tope del pedestal) y est_bot (sobre la losa),
    con separación ≤ s_est.  n = ceil(L/s) + 1 ;  s real = L/(n−1) redondeado hacia abajo a 0,5 cm.
    Reparto manual: cada estribo donde el usuario lo puso (est_pos); no se reacomoda nada."""
    if str(p.get("est_reparto", "")).startswith("Manual"):
        hpd = p["dPd"] + p["Df"] - p["HLf"]
        pos = sorted(round(float(v), 2) for v in (p.get("est_pos") or []) if 0 < float(v) < hpd)
        if not pos:            # primera vez: se parte del reparto automático
            pos = posiciones_estribos(ajustar_estribos(dict(p, est_reparto="Automático entre recubrimientos")))
        q = dict(p)
        q["est_pos"] = pos
        q["n_est"] = len(pos)
        q["s_est"] = _sep_dominante(pos) or p["s_est"]
        q["est_top"] = pos[0]
        q["est_bot"] = round(hpd - pos[-1], 2)
        return q
    if str(p.get("est_reparto", "")).startswith("Desde la losa"):
        # 1er estribo a est_ini sobre la losa y luego cada s_est hacia arriba: n_est estribos, o (n_est = 0)
        # todos los que quepan dejando al menos est_top bajo el tope del pedestal
        hpd = p["dPd"] + p["Df"] - p["HLf"]
        s = float(p.get("s_est") or 0)
        h0 = float(p.get("est_ini") or 0)
        n = int(p.get("n_est") or 0)
        alturas = []
        k = 0
        while s > 0 and k < 500:
            h = h0 + k * s
            if (n > 0 and k >= n) or (n <= 0 and h > hpd - float(p.get("est_top") or 0) + 1e-6) or h >= hpd:
                break
            alturas.append(h)
            k += 1
        pos = sorted(round(hpd - h, 2) for h in alturas)
        q = dict(p)
        q["_est_final"] = pos
        q["n_est"] = len(pos)
        if pos:
            q["est_top"] = pos[0]
            q["est_bot"] = round(hpd - pos[-1], 2)
        return q
    if not str(p.get("est_reparto", "")).startswith("Autom"):
        return p
    import math
    hpd = p["dPd"] + p["Df"] - p["HLf"]
    L = hpd - p["est_top"] - p["est_bot"]
    smax = float(p["s_est"])
    if L <= 0 or smax <= 0:
        return p
    n = int(math.ceil(L / smax - 1e-9)) + 1
    ajuste = str(p.get("est_ajuste", "Sobrante abajo"))
    if ajuste.startswith("Separación exacta"):
        s = L / (n - 1)
    else:
        s = math.floor(L / (n - 1) * 2 + 1e-9) / 2.0
    q = dict(p)
    q["n_est"], q["s_est"], q["s_est_max"] = n, s, smax
    if ajuste.startswith("Sobrante arriba"):
        # se respeta est_bot exacto y el sobrante pasa al tramo superior
        q["est_top"] = round(hpd - p["est_bot"] - (n - 1) * s, 2)
    return q


def deducir_reparto(pos, hpd, tol=0.06):
    """posiciones (cm desde el tope) -> {est_reparto «Desde la losa», est_ini, s_est, n_est, est_extra} si son
    una serie regular desde la losa más algunos sueltos; None si no hay serie clara."""
    import collections
    h = sorted(round(hpd - v, 2) for v in pos)
    if len(h) < 3:
        return None
    s = collections.Counter(round(b - a, 1) for a, b in zip(h, h[1:])).most_common(1)[0][0]
    if s <= 0:
        return None
    mejor = None
    for i0 in range(len(h)):
        serie = [h[i0]]
        for v in h[i0 + 1:]:
            if abs(v - (serie[-1] + s)) < tol:
                serie.append(v)
        if mejor is None or len(serie) > len(mejor):
            mejor = serie
    if len(mejor) < max(3, len(h) // 2):
        return None
    sueltos = [v for v in h if all(abs(v - x) > tol for x in mejor)]
    return {"est_reparto": OPCIONES["est_reparto"][3], "est_ini": round(mejor[0], 2), "s_est": s,
            "n_est": len(mejor), "est_extra": ";".join(fmt_cm(v).replace(",", ".") for v in sueltos)}


def editar_estribos(p: dict, accion: str, valor=None, indice=None, cid=None, sep=None, espacios=None,
                    kw_grupo=None) -> dict:
    """Edita los estribos uno por uno (pasa el reparto a «Manual»; ningún otro estribo se reacomoda).
    accion: "agregar" (valor = cm desde el tope), "quitar" (indice, o el más cercano a valor),
            "mover" (indice -> valor), "cota" (cid de la cadena de cotas de estribos -> valor en cm),
            "tramo" (cid de un tramo: nueva separación y/o n° de espacios, manteniendo su 1er estribo),
            "grupo" (kw_grupo = {n, sep, desde: "tope"|"losa", hacia: "abajo"|"arriba", reemplazar}).
    Devuelve los parámetros que cambian: {"est_reparto", "est_pos"}."""
    q = ajustar_estribos(normalizar_params(p))
    hpd = q["dPd"] + q["Df"] - q["HLf"]
    pos = list(posiciones_estribos(q))
    if str(q.get("est_reparto", "")).startswith("Desde la losa") and accion in ("agregar", "quitar"):
        # reparto desde la losa: un estribo suelto se agrega/quita como «estribo adicional» (la serie no cambia)
        extra = _alturas_extra(q)
        if accion == "agregar" and valor is not None:
            h = round(hpd - float(valor), 2)
            return {"est_extra": ";".join(fmt_cm(v).replace(",", ".") for v in sorted(set(extra + [h])))}
        if accion == "quitar":
            v = pos[indice] if indice is not None and 0 <= indice < len(pos) else (float(valor) if valor is not None else None)
            if v is not None:
                h = round(hpd - v, 2)
                resto = [e for e in extra if abs(e - h) > 0.05]
                if len(resto) < len(extra):
                    return {"est_extra": ";".join(fmt_cm(x).replace(",", ".") for x in resto)}
    lim = lambda v: min(max(float(v), 0.5), hpd - 0.5)
    if accion == "agregar":
        v = lim(valor)
        if all(abs(v - x) >= 1.0 for x in pos):
            pos.append(v)
    elif accion == "quitar" and pos:
        i = indice if indice is not None else min(range(len(pos)), key=lambda k: abs(pos[k] - float(valor)))
        if 0 <= i < len(pos) and len(pos) > 1:
            del pos[i]
    elif accion == "grupo":
        # grupo de estribos: valor = punto de partida (cm), desde "tope" o "losa"; n @ sep; hacia "abajo"/"arriba"
        ref = (kw_grupo or {}).get("desde", "tope")
        hacia = (kw_grupo or {}).get("hacia", "abajo")
        n = int((kw_grupo or {}).get("n", 1))
        s1 = float(sep or (kw_grupo or {}).get("sep", 15.0))
        ini = float(valor) if ref == "tope" else hpd - float(valor)
        paso = s1 if hacia == "abajo" else -s1
        nuevos = [lim(ini + j * paso) for j in range(max(n, 1))]
        if (kw_grupo or {}).get("reemplazar", True):
            m = abs(s1) / 2.0 - 0.01        # tampoco quedan estribos pegados a los extremos del grupo
            a, b = min(nuevos) - m, max(nuevos) + m
            pos = [x for x in pos if not (a <= x <= b)]
        pos += nuevos
    elif accion == "mover" and indice is not None and 0 <= indice < len(pos):
        pos[indice] = lim(valor)
    elif accion in ("cota", "tramo") and cid and pos:
        tipo = cid.split(":")[-1]
        if tipo == "arriba":
            pos[0] = lim(valor)
        elif tipo == "abajo":
            pos[-1] = lim(hpd - float(valor))
        elif tipo.startswith("tramo"):
            tramos = Generador.tramos_estribos(pos)
            k = int(tipo[5:]) - 1
            if 0 <= k < len(tramos):
                a, b, s0 = tramos[k]
                m = int(espacios) if espacios else (b - a)
                if sep:
                    s1 = float(sep)
                elif valor is not None:
                    s1 = float(valor) / m
                else:
                    s1 = s0
                nuevos = [pos[a] + j * s1 for j in range(m + 1)]
                pos = pos[:a] + nuevos + pos[b + 1:]
    pos = sorted(round(lim(v), 2) for v in pos)
    # sin duplicados (estribos a menos de 0,5 cm se funden)
    limpio = []
    for v in pos:
        if not limpio or v - limpio[-1] >= 0.5:
            limpio.append(v)
    # los estribos adicionales ya quedaron dentro de la lista manual
    return {"est_reparto": "Manual (posiciones)", "est_pos": limpio, "est_extra": ""}


def rec_x(p):
    """recubrimiento lateral de la zapata en las caras perpendiculares a X."""
    return float(p.get("rec_lat_x") or 0) or float(p["rec_lat"])


def rec_y(p):
    """recubrimiento lateral de la zapata en las caras perpendiculares a Y."""
    return float(p.get("rec_lat_y") or 0) or float(p["rec_lat"])


# parámetros cuyo 0 significa «igual a otro»: su valor efectivo
_EFECTIVO = {"rec_lat_x": rec_x, "rec_lat_y": rec_y}


def valor_efectivo(p, k):
    f = _EFECTIVO.get(k)
    return float(f(p)) if f else float(p[k])


def trabas_por_nivel(p):
    """trabas (1002) por nivel de estribos, sumando ambos sentidos."""
    nta = int(p["n_trabas"])
    ntb = nta if int(p.get("n_trabas_b", -1)) < 0 else int(p["n_trabas_b"])
    return nta + ntb


def calcular(p: dict) -> dict:
    c = {}
    ny_ = int(p["n_ped"])
    nx_ = 1 if DT.es_dt(p) else max(int(p.get("n_ped_x", 1) or 1), 1)
    n = ny_ * nx_                                             # pedestales por fundación (grilla X × Y)
    c["n_ped_tot"], c["n_ped_x"] = n, nx_
    c["cc"] = p["ped_y"] + p["dist_ped"]                      # distancia entre ejes pedestales
    c["HPd"] = p["dPd"] + p["Df"] - p["HLf"]                  # altura pedestal sobre la losa
    c["Htot"] = c["HPd"] + p["HLf"]
    c["bordY"] = (p["Lfy"] - (ny_ - 1) * c["cc"] - p["ped_y"]) / 2.0
    c["ccx"] = p["ped_x"] + float(p.get("dist_ped_x", 0) or 0)
    c["bordX"] = (p["Lfx"] - (nx_ - 1) * c["ccx"] - p["ped_x"]) / 2.0
    c["ped_pos"] = [(i - (ny_ - 1) / 2.0) * c["cc"] for i in range(ny_)]   # cm, eje Y (horizontal en planta)
    c["ped_pos_x"] = [(i - (nx_ - 1) / 2.0) * c["ccx"] for i in range(nx_)]  # cm, eje X (vertical en planta)
    # recubrimiento al eje de barras longitudinales del pedestal
    c["c_ped"] = p["rec_ped"] + p["db_est"] / 10.0 + p["db_ped"] / 20.0
    c["ue_ped_x"] = p["ped_x"] - 2 * c["c_ped"]
    c["ue_ped_y"] = p["ped_y"] - 2 * c["c_ped"]
    gancho_losa = p["HLf"] - p["rec_inf"] - p["rec_sup"]

    # marcas: Ø + correlativo; la barra larga de la losa es la 01 y la corta la 02 (convención HMV)
    largo_x = p["Lfx"] - 2 * rec_x(p)
    largo_y = p["Lfy"] - 2 * rec_y(p)
    usadas = set()

    def marca(d, pref=None):
        if pref:
            usadas.add(pref)
            return pref
        k = 1
        while f"{int(d)}{k:02d}" in usadas:
            k += 1
        m = f"{int(d)}{k:02d}"
        usadas.add(m)
        return m
    m_est = marca(p["db_est"])
    m_tra = marca(p["db_est"])
    if largo_y >= largo_x:
        m_y = marca(p["db_y"], p.get("marca_y") or None)
        m_x = marca(p["db_x"], p.get("marca_x") or None)
    else:
        m_x = marca(p["db_x"], p.get("marca_x") or None)
        m_y = marca(p["db_y"], p.get("marca_y") or None)
    m_ped = marca(p["db_ped"], p.get("marca_ped") or None)
    c.update(m_est=m_est, m_tra=m_tra, m_x=m_x, m_y=m_y, m_ped=m_ped)
    if p.get("gancho_losa"):
        gancho_losa = float(p["gancho_losa"])

    ncb = int(p.get("n_cara_b") or 0) or int(p["n_cara"])
    barras_ped = 2 * (int(p["n_cara"]) + ncb) - 4
    nta = int(p["n_trabas"])
    ntb = nta if int(p.get("n_trabas_b", -1)) < 0 else int(p["n_trabas_b"])
    a_est = p["ped_x"] - 2 * p["rec_ped"]
    b_est = p["ped_y"] - 2 * p["rec_ped"]
    a_ped = float(p.get("a_ped") or 0) or (c["Htot"] - p["rec_ped_sup"] - p["rec_inf"])
    barra_x = dict(marca=m_x, d=int(p["db_x"]), tipo="C", cant=2 * int(p["n_x"]), por=int(p["n_x"]), veces=2,
                   a=largo_x, b=gancho_losa, c=0, L=(largo_x + 2 * gancho_losa) / 100.0, rol="x")
    barra_y = dict(marca=m_y, d=int(p["db_y"]), tipo="C", cant=2 * int(p["n_y"]), por=int(p["n_y"]), veces=2,
                   a=largo_y, b=gancho_losa, c=0, L=(largo_y + 2 * gancho_losa) / 100.0, rol="y")
    losa = [barra_y, barra_x] if largo_y >= largo_x else [barra_x, barra_y]
    lista = [
        # marca, Ø, tipo, cant = por × veces, a, b, c, largo parcial (m)
        dict(marca=m_est, d=int(p["db_est"]), tipo="O", cant=n * int(p["n_est"]), por=int(p["n_est"]), veces=n,
             a=a_est, b=b_est, c=p["gancho_est"],
             L=(2 * (a_est + b_est) + 2 * p["gancho_est"]) / 100.0, rol="est"),
        dict(marca=m_tra, d=int(p["db_est"]), tipo="IG",
             cant=n * int(p["n_est"]) * (nta + ntb), por=int(p["n_est"]) * (nta + ntb), veces=n,
             a=(a_est if nta else b_est), b=p["gancho_est"], c=p["gancho_est"],
             L=((a_est if nta else b_est) + 2 * p["gancho_est"]) / 100.0, rol="tra"),
    ] + losa + [
        dict(marca=m_ped, d=int(p["db_ped"]), tipo="C", cant=n * barras_ped, por=barras_ped, veces=n,
             a=a_ped, b=p["gancho_ped"], c=0,
             L=(a_ped + 2 * p["gancho_ped"]) / 100.0, rol="ped"),
    ]
    lista = [b_ for b_ in lista if b_["cant"] > 0]
    tot = 0.0
    for b in lista:
        b["masa"] = MASA.get(b["d"], 0.00617 * b["d"] ** 2 * 1.0)
        # misma cadena que las fórmulas de la tabla de AutoCAD: I=(a+2b)/100, J=E*I, K=C*J
        b["Lp"] = b["L"]
        b["Lt"] = b["Lp"] * b["cant"]
        b["peso"] = b["Lt"] * b["masa"]
        tot += b["peso"]
    c["barras"] = lista
    c["acero"] = tot

    # cantidades de obra (por fundación) – mismo criterio que el plano original
    A = p["Lfx"] * p["Lfy"] / 1e4
    Ap = p["ped_x"] * p["ped_y"] / 1e4
    c["v_horm"] = A * p["HLf"] / 100 + n * Ap * c["HPd"] / 100
    c["v_emp"] = A * p["e_emp"] / 100
    c["v_exc"] = A * (p["Df"] + p["e_emp"] + p["sobreexc"]) / 100
    c["v_rell"] = (A - n * Ap) * (p["Df"] - p["HLf"]) / 100
    c["v_grout"] = n * (p["placa"] / 100) ** 2 * p["e_grout"] / 100 * 1000  # litros
    c["pernos"] = n * int(p["pernos_ped"])
    c["n_fund_esq"] = sum(1 for f in esquema_fundaciones(p) if f[3])
    # fórmulas (en m) que quedan escritas en la tabla N°2 de AutoCAD
    def m(v):
        return f"{v / 100.0:g}"
    lx, ly, hl, px_, py_, hp = m(p["Lfx"]), m(p["Lfy"]), m(p["HLf"]), m(p["ped_x"]), m(p["ped_y"]), m(c["HPd"])
    c["f_horm"] = f"({lx}*{ly}*{hl}+{n}*{px_}*{py_}*{hp})"
    c["f_emp"] = f"({lx}*{ly}*{m(p['e_emp'])})"
    c["f_exc"] = f"({lx}*{ly}*({m(p['Df'])}+{m(p['e_emp'])}+{m(p['sobreexc'])}))"
    c["f_rell"] = f"(({lx}*{ly}-{n}*{px_}*{py_})*({m(p['Df'])}-{hl}))"
    c["f_grout"] = f"({n}*{m(p['placa'])}*{m(p['placa'])}*{m(p['e_grout'])}*1000)"
    c["f_pernos"] = f"({n}*{int(p['pernos_ped'])})"
    for clave, q in (("v_exc", "q_exc"), ("v_rell", "q_rell"), ("v_grout", "q_grout")):
        if p.get(q):
            c[clave] = float(p[q])
            c["f_" + clave[2:]] = None          # valor ingresado a mano: sin fórmula
    # verificaciones
    avisos = []
    if c["bordY"] < 0 or c["bordX"] < 0:
        avisos.append("Los pedestales no caben en la zapata.")
    if c["HPd"] <= 0:
        avisos.append("Altura de pedestal ≤ 0 (revisar dPd, Df, HLf).")
    reparto_x = (int(p["n_x"]) - 3) * p["s_x"]
    if reparto_x > p["Lfy"] - 2 * rec_y(p):
        avisos.append("Barras dir. X no caben con la separación indicada.")
    reparto_y = (int(p["n_y"]) - 3) * p["s_y"]
    if reparto_y > p["Lfx"] - 2 * rec_x(p):
        avisos.append("Barras dir. Y no caben con la separación indicada.")
    if max(posiciones_estribos(p) or [0.0]) > c["HPd"]:
        avisos.append("Los estribos exceden la altura del pedestal.")
    hw, vw = (p["ped_x"], p["ped_y"]) if DT.es_dt(p) else (p["ped_y"], p["ped_x"])
    if any(abs(u) + 5 > hw / 2 or abs(v) + 5 > vw / 2 for (u, v) in pernos_base(p)):
        avisos.append("Pernos demasiado cerca del borde del pedestal (o fuera de él).")
    c["avisos"] = avisos
    if DT.es_dt(p):
        c = DT.calcular(p, c, sys.modules[__name__])
    return c


def posiciones_barras(L_cm, n_tot, s_cm, rec_cm, esq_cm=0.0):
    """2 barras de esquina a rec del borde + (n-2) repartidas.
    esq_cm = 0: repartidas centradas a separación s (lo que sobra queda junto a las esquinas);
    esq_cm > 0: la 1ª y la última repartida a esq_cm de su barra de esquina, el resto a separación igual."""
    n_rep = max(int(n_tot) - 2, 0)
    a = L_cm / 2 - rec_cm
    pos = [-a, a]
    if n_rep:
        if esq_cm and esq_cm > 0 and n_rep >= 2:
            ini, fin = -a + esq_cm, a - esq_cm
            sr = (fin - ini) / (n_rep - 1)
            pos += [ini + i * sr for i in range(n_rep)]
        elif esq_cm and esq_cm > 0:
            pos += [0.0]
        else:
            span = (n_rep - 1) * s_cm
            pos += [-span / 2 + i * s_cm for i in range(n_rep)]
    return sorted(pos)


def separacion_real(L_cm, n_tot, s_cm, rec_cm, esq_cm=0.0):
    """separación de las barras repartidas tal como quedan dibujadas."""
    n_rep = max(int(n_tot) - 2, 0)
    if esq_cm and esq_cm > 0 and n_rep >= 2:
        return (L_cm - 2 * rec_cm - 2 * esq_cm) / (n_rep - 1)
    return s_cm


# --------------------------------------------------------------------------
# GENERADOR
# --------------------------------------------------------------------------
# ventanas de las vistas en espacio modelo (de la plantilla) – centro y escala
VISTAS = {
    # clave: (centro papel aprox. del viewport, handle MTEXT título, parámetro escala)
    "AA_FORMAS": ((160.2, 333.4), "14B7F9", "esc_aaf"),
    "PLANTA":    ((147.4, 506.4), "14B8BD", "esc_planta"),
    "BB_FORMAS": ((368.9, 345.2), "17E796", "esc_bbf"),
    "AA_ARM":    ((137.5, 186.7), "17E96D", "esc_aaa"),
    "BB_ARM":    ((351.9, 188.8), "141CBB", "esc_bba"),
    "CC":        ((514.6, 210.9), "18E3BB", "esc_cc"),
    "ESQUEMA":   ((237.4, 59.8),  "190FC1", "esc_esq"),
}
NOMBRE_VISTA_MARCO = {
    "PLANTA": "Planta de fundación", "AA_FORMAS": "Sección A-A formas",
    "BB_FORMAS": "Sección B-B formas", "AA_ARM": "Sección A-A armaduras",
    "BB_ARM": "Sección B-B armaduras", "CC": "Sección C-C pedestal",
    "ESQUEMA": "Esquema distancia entre fundaciones",
}
NOMBRE_VISTA = dict(NOMBRE_VISTA_MARCO)

L_FUND = "CI-FUNDACIONES"
L_EJE = "EJES"
L_FIERRO = "CI_FIERROS"
L_DIM = "GN-ANNO-DIMS"
L_TXT = "GN-ANNO-TEXT-H2.5"
L_FINA = "LÍNEAS FINAS"
L_ACH = "ACHURADO"
L_EMP = "EMPLANTILLADO"
L_EST = "ES-ESTRUCTURAS"
L_PLET = "PLETINAS"
L_MONT = "MONTERO DE NIVELACIÓN"
L_TABLA = "GN-ANNO-LEGN"
ESTILO = "TRANSELEC"          # estilo de texto de altura libre (romans.shx) para MTEXT del modelo
ESTILO_COTA = "TRANSELEC"
COTA_OVERRIDES = {"dimlfac": 0.1, "dimdec": 1, "dimzin": 8}

# ezdxf interpreta DIMRND = 0 como "quitar decimales"; en AutoCAD 0 significa "sin redondeo"
try:
    from ezdxf.render import dim_base as _dim_base
    _fmt_orig = _dim_base.format_text

    def _format_text(value, dimrnd=None, dimdec=2, dimzin=0, dimdsep="."):
        return _fmt_orig(value, None if not dimrnd else dimrnd, dimdec, dimzin, dimdsep)
    _dim_base.format_text = _format_text
except Exception:   # pragma: no cover
    pass
APPID_TABLA = "HMV_TABLA"

NORMAS_ARCHIVO = os.path.join(AQUI, "normas_hmv.json")
_ROL_CAPA = {"fundacion": "L_FUND", "ejes": "L_EJE", "fierros": "L_FIERRO", "cotas": "L_DIM",
             "textos": "L_TXT", "lineas_finas": "L_FINA", "achurado": "L_ACH", "emplantillado": "L_EMP",
             "estructuras": "L_EST", "pletinas": "L_PLET", "montero": "L_MONT", "tablas": "L_TABLA"}


def cargar_normas(ruta=None):
    ruta = ruta or NORMAS_ARCHIVO
    try:
        with open(ruta, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def aplicar_normas(normas):
    """Fija las capas y estilos que usa el generador según normas_hmv.json."""
    g = globals()
    for rol, var in _ROL_CAPA.items():
        nombre = (normas.get("capas") or {}).get(rol)
        if nombre:
            g[var] = nombre
    if normas.get("estilo_texto_altura_libre"):
        g["ESTILO"] = normas["estilo_texto_altura_libre"]
    if normas.get("estilo_cota"):
        g["ESTILO_COTA"] = normas["estilo_cota"]
    if normas.get("cota_overrides"):
        g["COTA_OVERRIDES"] = dict(normas["cota_overrides"])


aplicar_normas(cargar_normas())


def factor_lamina(doc):
    """tamaño de la lámina de una plantilla respecto de la A1 original (ancho del marco T-F-… / 839,15)."""
    try:
        ps = next(l for l in doc.layouts if l.name != "Model")
        marcos = [e for e in ps.query("INSERT") if e.dxf.name.upper().startswith("T-F-")]
        if not marcos:
            return 1.0
        b = bbox.extents(marcos[:1], fast=True)
        if not b.has_data or b.size.x < 100:
            return 1.0
        return b.size.x / 839.15
    except Exception:
        return 1.0


class Generador:
    def __init__(self, plantilla=PLANTILLA):
        plantilla = plantilla or PLANTILLA
        self.plantilla = plantilla
        if plantilla.lower().endswith(".dwg"):
            tmp = os.path.splitext(plantilla)[0] + "_plantilla_tmp.dxf"
            convertir_a_dxf(plantilla, tmp)
            self.doc = ezdxf.readfile(tmp)
            try:
                os.remove(tmp)
            except OSError:
                pass
        else:
            self.doc = ezdxf.readfile(plantilla)
        self.msp = self.doc.modelspace()
        self.ps = self._paperspace()
        self.creados = {}          # vista -> [entidades]
        self.creados_ps = []       # entidades de papel generadas (se escalan con la hoja)
        self.creados_post = []     # entidades de papel a tamaño real (formato del cliente)
        self.tags = {}             # handle -> parámetros asociados (edición con doble clic)
        self.cotas_info = {}       # id de cota -> datos (vista, medida, texto, oculta, desp, handle)
        self.cotas_ids = {}        # handle de la cota -> id
        self.estribos_ref = {}     # vista -> {"y_tp": y modelo del tope, "hpd": cm, "x": [(x1, x2) por pedestal]}
        self.elementos = {}        # vista -> posiciones locales de barras/estribos (para acotar grupos)
        self.pernos_cadena = {}    # id de cota de una cadena de pernos -> (extremo a, extremo b)
        self.textos_info = {}      # id de texto -> datos (vista, tipo, texto automático, editado, handle)
        self.textos_ids = {}       # handle -> id de texto
        self.titulos_auto = {}     # vista -> título automático
        self.celdas_info = {}      # "T1:fila:col" -> texto automático de la celda
        self._titulo_orig = {}     # texto original de cada título de vista (plantilla)
        self._papel_orig = {}      # posición/altura originales de textos de papel que se reacomodan
        self._tag = ()
        self._f = 1.0              # factor de escala actual del papel respecto de A1
        self.esc_eff = {}
        self._fmt_bloques = {}     # archivo de formato -> nombre de bloque importado
        # plantilla con la lámina ampliada/reducida (p. ej. un plano ya exportado en A0): se lleva a A1 antes
        # de ubicar las vistas, que se reconocen por su posición en la lámina A1
        f_t = factor_lamina(self.doc)
        if abs(f_t - 1.0) > 0.02:
            self._escalar_papel(1.0 / f_t)
        self._preparar()

    # ------------------------------------------------------------------ setup
    def _paperspace(self):
        for lay in self.doc.layouts:
            if lay.name != "Model":
                return lay
        raise RuntimeError("La plantilla no tiene layout de papel")

    def _preparar(self):
        doc = self.doc
        if ESTILO not in doc.styles:                       # solo si la plantilla no lo trae
            doc.styles.add(ESTILO, font="romans.shx")
        if APPID_TABLA not in doc.appids:
            doc.appids.add(APPID_TABLA)
        for nm in (L_FUND, L_EJE, L_FIERRO, L_DIM, L_TXT, L_FINA, L_ACH, L_EMP,
                   L_EST, L_PLET, L_MONT, L_TABLA):
            if nm not in doc.layers:
                doc.layers.add(nm)
        # viewports de vistas
        vps = [v for v in self.ps.query("VIEWPORT")]
        self.vp = {}
        for key, (pc, _h, _e) in VISTAS.items():
            best = min(vps, key=lambda v: (v.dxf.center.x - pc[0]) ** 2 + (v.dxf.center.y - pc[1]) ** 2)
            self.vp[key] = best
        # ventanas originales en espacio modelo
        self.win = {}
        for key, v in self.vp.items():
            s = v.dxf.view_height / v.dxf.height
            t = v.dxf.view_target_point
            cx = v.dxf.view_center_point.x + t.x
            cy = v.dxf.view_center_point.y + t.y
            w = v.dxf.width * s / 2
            h = v.dxf.view_height / 2
            self.win[key] = (cx, cy, w, h)
        # prototipos (símbolos de la plantilla) antes de limpiar
        db = doc.entitydb
        def proto(handle, fallback=None):
            e = db.get(handle)
            if e is None and fallback:
                e = fallback()
            if e is None:
                return None
            c = e.copy()
            # sin diccionarios de extensión (datos de bloque dinámico/anotativo):
            # evita objetos compartidos entre copias al regenerar
            c.extension_dict = None
            for a in getattr(c, "attribs", []):
                a.extension_dict = None
            return c

        def por_nombre(nombre):
            def f():
                for e in self.msp.query("INSERT"):
                    if e.dxf.name == nombre:
                        return e
            return f

        def por_corte(rot, signo_x):
            """símbolo de corte (bloque con atributo 'A') por orientación, si cambió el handle."""
            def f():
                cands = []
                for e in self.msp.query("INSERT"):
                    if not any(a.dxf.tag == "A" for a in e.attribs):
                        continue
                    dr = abs(((e.dxf.rotation - rot) + 180) % 360 - 180)
                    if dr < 5 and (e.dxf.xscale > 0) == (signo_x > 0):
                        cands.append(e)
                return cands[0] if cands else None
            return f

        def por_quiebre():
            def f():
                for e in self.msp.query("INSERT"):
                    b = self.doc.blocks.get(e.dxf.name)
                    if b is not None and len(b) == 1 and b[0].dxftype() == "LWPOLYLINE" \
                            and abs(abs(e.dxf.xscale) - 75.19) < 1:
                        return e
            return f

        def por_attrib(tag, valor):
            def f():
                for e in self.msp.query("INSERT"):
                    for a in e.attribs:
                        if a.dxf.tag == tag and a.dxf.text == valor:
                            return e
            return f
        self.P = {
            "eje_num": proto("16A389", por_attrib("ESPC", "NUM")),
            "eje_letra": proto("166CB5", por_attrib("ESPC", "LETRA")),
            "nth": proto("__", por_attrib("NIVEL_CORTE", "N.T.H.")),
            "nap": proto("__", por_attrib("NIVEL_CORTE", "N.A.P.")),
            "corte_izq": proto("166B54", por_corte(90, -1)), "corte_der": proto("166B73", por_corte(270, 1)),
            "corte_b_inf": proto("166BAA", por_corte(0, -1)), "corte_b_sup": proto("1AA995", por_corte(180, 1)),
            "corte_c_izq": proto("171477", por_corte(90, -1)), "corte_c_der": proto("171496", por_corte(270, 1)),
            "quiebre": proto("__", por_nombre("*U5")) or proto("__", por_quiebre()),
            "s_relleno": proto("__", por_nombre("*U13")),
            "s_horm": proto("__", por_nombre("*U11")),
            "s_emp": proto("__", por_nombre("*U12")),
            "perno": proto("__", por_nombre("A$C9a7bfaab")),
        }
        cortes = [k for k in self.P if k.startswith("corte")]
        if any(self.P[k] is None for k in cortes):      # uniformidad: todas dibujadas
            for k in cortes:
                self.P[k] = None
        # prototipos de achurados (definición de patrón original)
        self.PH = {}
        for e in self.msp.query("HATCH"):
            nm = e.dxf.pattern_name.upper()
            if nm in ("GRAVEL", "EARTH", "ANSI31") and nm not in self.PH and not e.dxf.solid_fill:
                if e.dxf.layer == L_ACH:
                    self.PH[nm] = e.copy()
        # limpiar contenido antiguo de las ventanas
        borrar = []
        cache = bbox.Cache()
        for e in self.msp:
            if e.dxftype() in ("IMAGE",):
                continue
            if e.dxftype() == "MULTILEADER":           # sin extensión calculable: punta y texto
                puntos = []
                try:
                    ctx = e.context
                    if ctx.mtext is not None:
                        puntos.append(ctx.mtext.insert)
                    for ld in ctx.leaders:
                        for ln in ld.lines:
                            puntos += list(ln.vertices[:1])
                except Exception:
                    pass
                for (cx, cy, w, h) in self.win.values():
                    if any(cx - w <= m.x <= cx + w and cy - h <= m.y <= cy + h for m in puntos):
                        borrar.append(e)
                        break
                continue
            try:
                b = bbox.extents([e], cache=cache)
            except Exception:
                continue
            if not b.has_data:
                continue
            puntos = [b.center]
            if e.dxftype() == "INSERT":
                puntos.append(e.dxf.insert)
            hecho = False
            for (cx, cy, w, h) in self.win.values():
                for m in puntos:
                    if cx - w <= m.x <= cx + w and cy - h <= m.y <= cy + h:
                        borrar.append(e)
                        hecho = True
                        break
                if hecho:
                    break
        for e in borrar:
            self._borrar(self.msp, e)
        # sello "APROBADO CON COMENTARIOS" del plano original (dentro de la hoja)
        for e in list(self.ps.query("INSERT")):
            if e.dxf.name.lower().startswith("sello"):
                self.ps.delete_entity(e)
        # estilos de cota (cm, texto verde) por escala
        self._dimstyles = {}
        # elementos del formato original (marco Transelec + viñeta HMV)
        self.formato_orig = [e for e in self.ps.query("INSERT")
                             if e.dxf.name.upper() in ("T-F-A0",) or e.dxf.name.upper().startswith("VI")]
        self.h_notas = self._buscar_mtext(lambda t: t.lstrip().upper().startswith("NOTAS"), "15A349")
        self.h_refs = self._buscar_mtext(lambda t: t.lstrip().upper().startswith("REFERENCIAS"), "1760C2")
        claves = {"PLANTA": ("PLANTA DE FUNDACI",), "AA_FORMAS": ("A-A", "FORMAS"), "BB_FORMAS": ("B-B", "FORMAS"),
                  "AA_ARM": ("A-A", "ARMADURA"), "BB_ARM": ("B-B", "ARMADURA"), "CC": ("C-C",),
                  "ESQUEMA": ("ESQUEMA",)}
        self.h_titulos = {}
        for key, (_pc, h, _e) in VISTAS.items():
            pal = claves[key]
            self.h_titulos[key] = self._buscar_mtext(
                lambda t, pal=pal: all(x in t.upper().replace("–", "-") for x in pal) and len(t) < 160, h)
        # tablas existentes de la plantilla (ACAD_TABLE convertidas a bloque *T): se reemplazan
        self.orig_tablas = {}
        for e in list(self.ps.query("INSERT")):
            if e.dxf.name.startswith("*T") and e.dxf.name in doc.blocks:
                txt = " ".join(m.plain_text() for m in doc.blocks[e.dxf.name].query("MTEXT"))[:300].upper()
                for n in ("1", "2", "3"):
                    if f"TABLA N°{n}" in txt or f"TABLA Nº{n}" in txt or f"TABLA N° {n}" in txt:
                        self.orig_tablas[n] = (e.dxf.insert.x, e.dxf.insert.y)
                        # bloques dentro de las celdas (dibujos «TIPO C / IG / O» de una tabla de AutoCAD):
                        # se dejan en la lámina en su lugar, la tabla nueva queda debajo con sus textos
                        try:
                            m44 = e.matrix44()
                            for sub in doc.blocks[e.dxf.name].query("INSERT"):
                                c = sub.copy()
                                c.transform(m44)
                                self.ps.add_entity(c)
                        except Exception:
                            pass
                        self.ps.delete_entity(e)
                        break
        vps_all = list(self.ps.query("VIEWPORT"))
        self.vp_papel = [v for v in vps_all if v not in self.vp.values()]
        self.capas_off_plantilla = sorted(l.dxf.name for l in doc.layers if l.is_off())
        lay = self.ps.dxf_layout.dxf
        # rosas de los vientos de la lámina (capa Titulos: círculos + «N»); el plano de desconectador las oculta
        self.norte = []
        try:
            from ezdxf import bbox as _bbn
            for e in self.ps:
                if e.dxf.get("layer", "") == "Titulos" and e.dxftype() in ("LWPOLYLINE", "ATTDEF"):
                    bb = _bbn.extents([e], fast=True)
                    if bb.has_data and bb.size.x < 25 and bb.size.y < 25:
                        self.norte.append(e)
        except Exception:
            self.norte = []
        self._lay0 = {k: lay.get(k) for k in ("paper_width", "paper_height", "limmin", "limmax", "extmin",
                                                "extmax", "plot_window_x2", "plot_window_y2", "paper_size")}

    def _buscar_mtext(self, cond, handle_def=None):
        e = self.doc.entitydb.get(handle_def) if handle_def else None
        if e is not None and e.dxftype() == "MTEXT":
            return handle_def
        for m in self.ps.query("MTEXT"):
            try:
                if cond(m.plain_text()):
                    return m.dxf.handle
            except Exception:
                continue
        return None

    def _dimstyle(self, esc):
        nombre = f"JVG_1-{int(esc)}"
        if nombre in self._dimstyles:
            return nombre
        if nombre not in self.doc.dimstyles:
            ds = self.doc.dimstyles.new(nombre)
        else:
            ds = self.doc.dimstyles.get(nombre)
        ds.dxf.dimscale = float(esc)
        ds.dxf.dimlfac = 0.1
        ds.dxf.dimtxt = 2.0
        ds.dxf.dimasz = 1.6
        ds.dxf.dimexo = 1.0
        ds.dxf.dimexe = 1.25
        ds.dxf.dimgap = 0.6
        ds.dxf.dimtad = 1
        ds.dxf.dimjust = 0
        ds.dxf.dimtih = 0
        ds.dxf.dimtoh = 0
        ds.dxf.dimdec = 1
        ds.dxf.dimzin = 8
        ds.dxf.dimdsep = ord(",")
        ds.dxf.dimclrt = 3
        ds.dxf.dimclrd = 7
        ds.dxf.dimclre = 7
        ds.dxf.dimtxsty = ESTILO
        ds.dxf.dimtmove = 0
        ds.dxf.dimatfit = 3
        ds.dxf.dimtofl = 1
        self._dimstyles[nombre] = True
        return nombre

    # --------------------------------------------------------------- borrado
    def _borrar(self, layout, e):
        if not e.is_alive:
            return
        geom = e.dxf.get("geometry") if e.dxftype() == "DIMENSION" else None
        layout.delete_entity(e)
        if geom and geom in self.doc.blocks:
            try:
                self.doc.blocks.delete_block(geom, safe=False)
            except Exception:
                pass

    def limpiar_vista(self, vista):
        """borra sólo lo dibujado en el espacio modelo de una vista (para redibujarla)."""
        for e in self.creados.pop(vista, []):
            self.tags.pop(e.dxf.handle, None)
            self.cotas_ids.pop(e.dxf.handle, None)
            self.textos_ids.pop(e.dxf.handle, None)
            try:
                self._borrar(self.msp, e)
            except Exception:
                pass

    def limpiar(self, vistas=None):
        for key in list(self.creados.keys()):
            if vistas is not None and key not in vistas:
                continue
            for e in self.creados[key]:
                self.tags.pop(e.dxf.handle, None)
                self.cotas_ids.pop(e.dxf.handle, None)
                try:
                    self._borrar(self.msp, e)
                except Exception:
                    pass
            del self.creados[key]
        for e in self.creados_ps + self.creados_post:
            self.tags.pop(e.dxf.handle, None)
            try:
                self._borrar(self.ps, e)
            except Exception:
                pass
        self.creados_ps = []
        self.creados_post = []

    # ------------------------------------------------------- primitivas
    def _reg(self, e):
        self.creados.setdefault(self._vista, []).append(e)
        if self._tag:
            self.tags[e.dxf.handle] = self._tag
        return e

    def _t(self, *claves):
        """parámetros asociados a las entidades que se dibujen a continuación."""
        self._tag = tuple(claves)

    def _xy(self, x, y):
        return (self._ox + x, self._oy + y)

    def pl(self, pts, layer, closed=False, color=None, lt=None):
        at = {"layer": layer}
        if color is not None:
            at["color"] = color
        if lt:
            at["linetype"] = lt
        return self._reg(self.msp.add_lwpolyline([self._xy(*p) for p in pts], close=closed, dxfattribs=at))

    def ln(self, p1, p2, layer, color=None):
        at = {"layer": layer}
        if color is not None:
            at["color"] = color
        return self._reg(self.msp.add_line(self._xy(*p1), self._xy(*p2), dxfattribs=at))

    def rect(self, x0, y0, x1, y1, layer, color=None):
        return self.pl([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], layer, closed=True, color=color)

    def circ(self, x, y, r, layer, color=None):
        at = {"layer": layer}
        if color is not None:
            at["color"] = color
        return self._reg(self.msp.add_circle(self._xy(x, y), r, dxfattribs=at))

    def _arco(self, x, y, r, a0, a1, layer=L_FIERRO, color=3):
        return self._reg(self.msp.add_arc(self._xy(x, y), r, a0, a1, dxfattribs={"layer": layer, "color": color}))

    def punto(self, x, y, d, layer=L_FIERRO):
        """barra en corte: círculo relleno."""
        r = max(d, 0.9 * self._esc) / 2.0
        h = self.msp.add_hatch(color=7, dxfattribs={"layer": layer})
        cx, cy = self._xy(x, y)
        h.paths.add_polyline_path([(cx - r, cy, 1.0), (cx + r, cy, 1.0)], is_closed=True)
        self._reg(h)
        self.circ(x, y, r, layer, color=7)

    def hatch(self, pts, patron, escala_rel=1.0, layer=L_ACH):
        """achurado copiando la definición de patrón del plano original;
        escala_rel = factor respecto del achurado original (1:35)."""
        proto = self.PH.get(patron.upper())
        if proto is not None:
            h = proto.copy()
            h.paths.clear()
            h.dxf.layer = layer
            if abs(escala_rel - 1.0) > 1e-9:
                h.set_pattern_scale(h.dxf.pattern_scale * escala_rel)
            self.msp.add_entity(h)
        else:
            h = self.msp.add_hatch(dxfattribs={"layer": layer})
            h.set_pattern_fill(patron, scale=escala_rel)
        h.paths.add_polyline_path([self._xy(*p) for p in pts], is_closed=True)
        return self._reg(h)

    # ---- textos editables: cada texto del dibujo tiene un id estable (vista:tipo:parámetros:n°) y se puede
    # reescribir, ocultar o mover desde p["textos_mod"] sin tocar el CAD
    def _texto_id(self, tipo):
        tags = "+".join(t for t in self._tag if not str(t).startswith("@")) or "-"
        clave = (self._vista, tipo, tags)
        k = self._cota_k.get(clave, 0) + 1
        self._cota_k[clave] = k
        return f"{self._vista}:{tipo}:{tags}:{k}"

    def _texto_mod(self, tid):
        return ((getattr(self, "p", None) or {}).get("textos_mod") or {}).get(tid) or {}

    def _registrar_texto(self, tid, e, tipo, auto, mod):
        self.textos_info[tid] = {"vista": self._vista, "tipo": tipo, "auto": auto, "tags": tuple(self._tag),
                                 "texto": mod.get("texto"), "attr": mod.get("attr"),
                                 "oculto": bool(mod.get("oculto")), "handle": e.dxf.handle if e is not None else None}
        if e is not None:
            self.textos_ids[e.dxf.handle] = tid
            self.tags[e.dxf.handle] = ("@texto", tid) + tuple(t for t in self._tag if not str(t).startswith("@"))

    def _desp(self, mod, x, y):
        return x + float(mod.get("dx") or 0.0) * self._esc, y + float(mod.get("dy") or 0.0) * self._esc

    def texto(self, txt, x, y, h_papel, layer=L_TXT, color=None, adj=7, ancho=None, rot=0.0):
        tid = self._texto_id("txt")
        mod = self._texto_mod(tid)
        auto = txt
        if mod.get("oculto"):
            self._registrar_texto(tid, None, "txt", auto, mod)
            return None
        if str(mod.get("texto") or "").strip():
            txt = str(mod["texto"])
        x, y = self._desp(mod, x, y)
        at = {"layer": layer, "char_height": h_papel * self._esc, "style": ESTILO}
        if color is not None:
            at["color"] = color
        if ancho:
            at["width"] = ancho
        if rot:
            at["rotation"] = rot
        m = self.msp.add_mtext(txt, dxfattribs=at)
        m.set_location(insert=self._xy(x, y), attachment_point=adj)
        self._reg(m)
        self._registrar_texto(tid, m, "txt", auto, mod)
        return m

    def flecha(self, tip, desde, layer=L_TXT, color=None, largo_papel=2.5):
        L = largo_papel * self._esc
        ang = math.atan2(tip[1] - desde[1], tip[0] - desde[0])
        w = L / 6.0
        bx, by = tip[0] - L * math.cos(ang), tip[1] - L * math.sin(ang)
        px, py = -math.sin(ang) * w, math.cos(ang) * w
        at = {"layer": layer}
        if color is not None:
            at["color"] = color
        s = self.msp.add_solid([self._xy(*tip), self._xy(bx + px, by + py), self._xy(bx - px, by - py)],
                               dxfattribs=at)
        return self._reg(s)

    # rótulos como MULTILEADER, con las mismas propiedades que los del plano original:
    # estilo de directriz "Standard", letra romans (estilo de texto TRANSELEC = romans.shx, factor 1,
    # lo mismo que el \\Fromans en línea del original), texto 2,0 mm, flecha 2,0 mm, rellano 1,8 mm,
    # separación 0,45 mm y texto subrayado sobre la línea (unión «bottom of top line, underline»)
    ROT = {"h": 2.0, "flecha": 2.0, "rellano": 1.8, "separacion": 0.45, "estilo": "Standard"}
    _rot_desfase = {}

    @classmethod
    def _desfase_rotulo(cls, lado):
        """desplazamiento (a escala 1) entre el punto de inicio del rellano y el punto de inserción del texto."""
        if lado not in cls._rot_desfase:
            from ezdxf.render import mleader
            from ezdxf.math import Vec2
            d = ezdxf.new("R2018")
            ml = cls._constructor_rotulo(d.modelspace(), "{X}", lado, 1.0, None)
            ml.add_leader_line(mleader.ConnectionSide.left if lado > 0 else mleader.ConnectionSide.right,
                               [Vec2(-50 * lado, -50)])
            ml.build(insert=Vec2(0, 0))
            ll = ml.multileader.context.leaders[0].last_leader_point
            cls._rot_desfase[lado] = (-ll.x, -ll.y)
        return cls._rot_desfase[lado]

    @classmethod
    def _constructor_rotulo(cls, msp, contenido, lado, esc, dxfattribs):
        from ezdxf.render import mleader
        estilo = cls.ROT["estilo"] if cls.ROT["estilo"] in msp.doc.mleader_styles else "Standard"
        ml = msp.add_multileader_mtext(estilo, dxfattribs=dxfattribs)
        st = ESTILO if ESTILO in msp.doc.styles else ""
        ml.set_content(contenido, char_height=cls.ROT["h"], style=st,
                       alignment=mleader.TextAlignment.left if lado > 0 else mleader.TextAlignment.right)
        ml.set_arrow_properties(size=cls.ROT["flecha"])
        ml.set_connection_properties(landing_gap=cls.ROT["separacion"], dogleg_length=cls.ROT["rellano"])
        union = mleader.HorizontalConnection.bottom_of_top_line_underline
        ml.set_connection_types(left=union, right=union)
        ml.set_overall_scaling(esc)
        return ml

    def rotulo(self, pts, txt, h_papel=None, color=None, layer=L_TXT, lado=1, italic=False):
        """rótulo (MULTILEADER): pts[0] = punta de flecha, último punto = inicio del rellano del texto."""
        from ezdxf.render import mleader
        from ezdxf.math import Vec2
        lado = 1 if lado >= 0 else -1
        propio = bool(self._tag) and self._tag[0] == "@rotulo_extra"
        tid = mod = None
        if not propio:                                  # rótulo del programa: editable por id
            tid = self._texto_id("rot")
            mod = self._texto_mod(tid)
            auto = txt
            if mod.get("oculto"):
                self._registrar_texto(tid, None, "rot", auto, mod)
                return None
            if str(mod.get("texto") or "").strip():
                txt = str(mod["texto"])
            if mod.get("dx") or mod.get("dy"):          # texto (y codo) movidos a mano
                pts = [pts[0]] + [self._desp(mod, *q) for q in pts[1:]]
            if mod.get("px") or mod.get("py"):          # punta de la flecha movida a mano
                pts = [(pts[0][0] + float(mod.get("px") or 0) * self._esc,
                        pts[0][1] + float(mod.get("py") or 0) * self._esc)] + list(pts[1:])
        col = f"\\C{int(color)};" if color is not None else "\\C256;"
        contenido = "{" + col + txt + "}"
        ml = self._constructor_rotulo(self.msp, contenido, lado, float(self._esc), {"layer": layer})
        verts = [Vec2(self._xy(*q)) for q in pts[:-1]] or [Vec2(self._xy(*pts[0]))]
        ml.add_leader_line(mleader.ConnectionSide.left if lado > 0 else mleader.ConnectionSide.right, verts)
        dx, dy = self._desfase_rotulo(lado)
        X, Y = self._xy(*pts[-1])
        ml.build(insert=Vec2(X + dx * self._esc, Y + dy * self._esc))
        self._reg(ml.multileader)
        if tid is not None:
            self._registrar_texto(tid, ml.multileader, "rot", auto, mod)
        return ml.multileader

    def _cota_txt(self):
        """altura del texto y separación a la línea de cota (mm en papel) del estilo de cota."""
        ds = self.doc.dimstyles.get(ESTILO_COTA) if ESTILO_COTA in self.doc.dimstyles else None
        if ds is None:
            return 2.5, 0.625
        return float(ds.dxf.get("dimtxt", 2.5) or 2.5), abs(float(ds.dxf.get("dimgap", 0.625) or 0.625))

    def _ancho_txt(self, t):
        """ancho aproximado (mm en papel) de un texto de cota en romans."""
        h, _g = self._cota_txt()
        lineas = str(t or "").replace("\\P", "\n").split("\n")
        return max(sum(0.55 if ch in ".,:;'|" else (0.65 if ch == " " else 1.0) for ch in l) for l in lineas) * h

    def _repartir_textos(self, segs, textos):
        """posición (a lo largo de la cadena) del texto de cada tramo, para que ninguno se monte sobre otro:
        se corren lo justo hacia los tramos con espacio. None = el texto queda en el centro de su tramo."""
        S = self._esc
        mids = [(a + b) / 2 for a, b in segs]
        anch = [(self._ancho_txt(t) + 2.5) * S for t in textos]
        n = len(segs)
        if n < 2:
            return [None] * n
        orden = sorted(range(n), key=lambda i: mids[i])
        m = [mids[i] for i in orden]
        w = [anch[i] for i in orden]
        ida = list(m)
        for i in range(1, n):
            ida[i] = max(ida[i], ida[i - 1] + (w[i - 1] + w[i]) / 2)
        vuelta = list(m)
        for i in range(n - 2, -1, -1):
            vuelta[i] = min(vuelta[i], vuelta[i + 1] + 0 - (w[i] + w[i + 1]) / 2)
        c = [(a + b) / 2 for a, b in zip(ida, vuelta)]
        for i in range(1, n):                          # sin choques después de promediar
            c[i] = max(c[i], c[i - 1] + (w[i - 1] + w[i]) / 2)
        out = [None] * n
        for k, i in enumerate(orden):
            largo = abs(segs[i][1] - segs[i][0])
            # se fija la posición si se corrió o si el texto no cabe en su tramo (si no, el CAD lo sube)
            if abs(c[k] - mids[i]) > 0.05 * S or anch[i] > largo:
                out[i] = c[k]
        return out

    def cota(self, p1, p2, base, angulo=0, texto=None, cid=None, pos_txt=None, col_txt=0.0, opuesto=False):
        """cota lineal. Cada cota tiene un identificador estable (vista:parámetros:n°) con el que se
        puede editar individualmente desde p["cotas_mod"]: texto, oculta, desp (mm en papel)."""
        if cid is None:
            clave = (self._vista, "+".join(self._tag) or "-")
            k = self._cota_k.get(clave, 0) + 1
            self._cota_k[clave] = k
            cid = f"{clave[0]}:{clave[1]}:{k}"
        mod = (self.p.get("cotas_mod") or {}).get(cid) or {}
        medida = abs((p2[1] - p1[1]) if angulo == 90 else (p2[0] - p1[0])) / K
        info = {"vista": self._vista, "tags": tuple(self._tag), "medida": medida,
                "texto_auto": texto, "texto": mod.get("texto") or None, "oculta": bool(mod.get("oculta")),
                "desp": float(mod.get("desp") or 0.0), "handle": None}
        self.cotas_info[cid] = info
        if info["oculta"]:
            return None
        if mod.get("texto"):
            texto = mod["texto"]
        if info["desp"]:
            d = info["desp"] * self._esc
            base = (base[0] + d, base[1]) if angulo == 90 else (base[0], base[1] + d)
        # estilo de cota de la norma (p. ej. TRANSELEC) con reemplazos: escala de la vista y cm
        if ESTILO_COTA in self.doc.dimstyles:
            ds = ESTILO_COTA
            ov = dict(COTA_OVERRIDES)
            ov["dimscale"] = float(self._esc)
        else:
            ds = self._dimstyle(self._esc)
            ov = {}
        if str((self.p or {}).get("cota_flechas", "Flechas")).startswith("Flechas"):
            # flechas rellenas; en tramos más cortos que las dos flechas se dibujan por fuera (como en CAD)
            ov.update({"dimblk": "", "dimblk1": "", "dimblk2": "", "dimsah": 0, "dimtsz": 0.0})
        kw = dict(base=self._xy(*base), p1=self._xy(*p1), p2=self._xy(*p2), angle=angulo,
                  dimstyle=ds, dxfattribs={"layer": L_DIM}, override=ov or None)
        if texto is not None:
            kw["text"] = texto
        tx_, ty_ = float(mod.get("tx") or 0.0), float(mod.get("ty") or 0.0)
        if (tx_ or ty_) and pos_txt is None:            # texto movido a mano: parte del centro del tramo
            pos_txt = ((p1[1] + p2[1]) / 2) if angulo == 90 else ((p1[0] + p2[0]) / 2)
        if pos_txt is not None:                         # texto corrido para no chocar con el vecino
            h, g = self._cota_txt()
            S = self._esc
            nl = str(texto or "").count("\\P") + 1
            alto = h * (1 + 1.4 * (nl - 1))              # alto del bloque de texto (renglones)
            # lado del texto como lo pone el CAD: «sobre» la línea según el sentido de la cota (si se mide hacia
            # abajo o hacia la izquierda, el texto se da vuelta para leerse y queda del otro lado)
            if angulo == 90:
                lado = -1.0 if p2[1] >= p1[1] else 1.0
                lado = -lado if opuesto else lado
                loc = (base[0] + lado * (g + alto / 2 + col_txt) * S + tx_ * S, pos_txt + ty_ * S)
            else:
                lado = 1.0 if p2[0] >= p1[0] else -1.0
                lado = -lado if opuesto else lado
                loc = (pos_txt + tx_ * S, base[1] + lado * (g + alto / 2 + col_txt) * S + ty_ * S)
            kw["location"] = self._xy(*loc)
            ov["dimtmove"] = 2
            kw["override"] = ov
        d = self.msp.add_linear_dim(**kw)
        d.render()
        info["handle"] = d.dimension.dxf.handle
        self.cotas_ids[d.dimension.dxf.handle] = cid
        return self._reg(d.dimension)

    def resolver_cota(self, p: dict, cid: str, valor: float):
        """Hace que la cota `cid` mida `valor` (cm) CAMBIANDO EL DIBUJO, sin reacomodar el resto:
        - cadena de estribos: mueve sólo el estribo de esa cota (reparto manual);
        - cotas agregadas a mano: mueve su 2º punto;
        - demás cotas: busca, entre los parámetros que la definen, el que la cambia alterando
          la menor cantidad de otras cotas de la vista, y lo ajusta (método de la secante).
        Devuelve {parámetro: valor nuevo} o None si la cota no depende de ningún parámetro."""
        info = self.cotas_info.get(cid)
        if info is None:
            return None
        valor = float(valor)
        if ":est:" in cid:
            return editar_estribos(p, "cota", valor=valor, cid=cid)
        if ":pernos:" in cid:
            r = self.resolver_pernos(p, cid, valor)
            if r is not None:
                return r
        if cid.startswith("ESQUEMA:ejes:") or cid.startswith("ESQUEMA:filas:"):
            return self.resolver_esquema(p, cid, valor)
        if ":extra:" in cid:
            filas = [list(f) for f in (p.get("cotas_extra") or [])]
            i = int(cid.split(":")[-1]) - 1
            if not (0 <= i < len(filas)):
                return None
            f = filas[i]
            x1, y1, x2, y2 = map(float, f[1:5])
            if str(f[7]).upper().startswith("V"):
                f[4] = round(y1 + (1 if y2 >= y1 else -1) * valor * K, 3)
            else:
                f[3] = round(x1 + (1 if x2 >= x1 else -1) * valor * K, 3)
            filas[i] = f
            return {"cotas_extra": filas}
        vista = info["vista"]
        m0 = info["medida"]
        if abs(m0 - valor) < 1e-6:
            return {}
        cands = [k for k in info["tags"] if k in PARAM_DEF and isinstance(DEFAULTS.get(k), float)
                 and not isinstance(DEFAULTS.get(k), bool)]
        base = {k_: v["medida"] for k_, v in self.cotas_info.items() if v["vista"] == vista}
        mejor = None
        p0 = dict(p)
        try:
            for k in cands:
                d = 1.0
                self.generar(dict(p0, **{k: valor_efectivo(p0, k) + d}), vistas=[vista])
                nueva = self.cotas_info.get(cid, {}).get("medida")
                if nueva is None:
                    continue
                pend = (nueva - m0) / d
                if abs(pend) < 1e-6:
                    continue
                otras = sum(1 for k_, v in self.cotas_info.items()
                            if v["vista"] == vista and k_ != cid and k_ in base
                            and abs(v["medida"] - base[k_]) > 1e-6)
                clave = (otras, -abs(pend))
                if mejor is None or clave < mejor[0]:
                    mejor = (clave, k, pend)
            if mejor is None:
                return None
            _, k, pend = mejor
            x0, f0 = valor_efectivo(p0, k), m0 - valor
            x1 = x0 - f0 / pend
            for _ in range(6):
                self.generar(dict(p0, **{k: x1}), vistas=[vista])
                f1 = self.cotas_info.get(cid, {}).get("medida", valor) - valor
                if abs(f1) < 0.005 or abs(f1 - f0) < 1e-9:
                    break
                x0, f0, x1 = x1, f1, x1 - f1 * (x1 - x0) / (f1 - f0)
            return {k: round(x1, 3)}
        finally:
            self.generar(p0, vistas=[vista])

    ELEMENTOS = {"estribos": "Estribos del pedestal", "barras": "Barras (puntos) de la sección",
                 "barras_v": "Barras del pedestal, cara vertical (C-C)"}

    def _cotas_grupo(self, vista, p):
        """cotas de un grupo de elementos: del n° i al n° j (1 = primero), con rótulo automático
        «n-marca@s» (o el texto que el usuario escriba)."""
        bak = self._tag
        S = self._esc
        for idx, f in enumerate(p.get("cotas_grupo") or []):
            try:
                v, elem, i, j = f[0], f[1], int(f[2]), int(f[3])
                dist = float(f[4]) if len(f) > 4 and str(f[4]).strip() else 12.0
            except (ValueError, TypeError, IndexError):
                continue
            if v != vista:
                continue
            e = (self.elementos.get(vista) or {}).get(elem)
            if not e:
                continue
            coords = e["x"] if e["eje"] == "x" else e["y"]
            n = len(coords)
            if n < 2:
                continue
            i, j = max(1, min(i, n)), max(1, min(j, n))
            if i > j:
                i, j = j, i
            a_, b_ = coords[i - 1], coords[j - 1]
            cant = j - i + 1
            sep = abs(b_ - a_) / K / (cant - 1) if cant > 1 else 0.0
            texto = (str(f[5]).strip() if len(f) > 5 else "") or None
            if texto is None and cant > 1:
                texto = f"{cant}-{e['marca']}@{self._num_cota(sep)}"
                if elem == "estribos":
                    texto += f"\\P{cant * e.get('n_trabas', 2)}-{e['marca2']}@{self._num_cota(sep)}"
            self._tag = ("@cota_grupo", str(idx))
            cid = f"{vista}:grupo:{idx + 1}"
            if e["eje"] == "x":
                y0 = e["y"]
                self.cota((a_, y0), (b_, y0), (a_, y0 - dist * S), 0, texto=texto, cid=cid)
            else:
                x0 = e["x"]
                self.cota((x0, a_), (x0, b_), (x0 - dist * S, a_), 90, texto=texto, cid=cid)
        self._tag = bak

    def _rotulos_extra(self, vista, p):
        """rótulos (MULTILEADER, estilo del plano) agregados por el usuario."""
        bak = self._tag
        for idx, f in enumerate(p.get("rotulos_extra") or []):
            try:
                v, xp, yp, xt, yt = f[0], *map(float, f[1:5])
            except (ValueError, TypeError, IndexError):
                continue
            if v != vista:
                continue
            texto = str(f[5]) if len(f) > 5 else ""
            if not texto.strip():
                continue
            col = f[6] if len(f) > 6 and str(f[6]).strip() not in ("", "None") else None
            try:
                col = int(col) if col is not None else None
            except ValueError:
                col = None
            self._tag = ("@rotulo_extra", str(idx))
            self.rotulo([(xp, yp), (xt, yt)], texto, color=col, lado=1 if xt >= xp else -1)
        self._tag = bak

    def _cotas_extra(self, vista, p):
        """cotas agregadas a mano por el usuario (coordenadas locales de la vista, mm)."""
        bak = self._tag
        for i, f in enumerate(p.get("cotas_extra") or []):
            try:
                v, x1, y1, x2, y2, xb, yb = f[0], *map(float, f[1:7])
            except (ValueError, TypeError, IndexError):
                continue
            if v != vista:
                continue
            tipo = (str(f[7]) if len(f) > 7 else "H").upper()[:1]
            texto = (str(f[8]) if len(f) > 8 else "").strip() or None
            self._tag = ("@cota_extra", str(i))
            if tipo == "A":
                dist = ((xb - x1) * (y2 - y1) - (yb - y1) * (x2 - x1)) / max(math.hypot(x2 - x1, y2 - y1), 1e-9)
                ds = ESTILO_COTA if ESTILO_COTA in self.doc.dimstyles else self._dimstyle(self._esc)
                ov = dict(COTA_OVERRIDES, dimscale=float(self._esc)) if ESTILO_COTA in self.doc.dimstyles else None
                kw = dict(p1=self._xy(x1, y1), p2=self._xy(x2, y2), distance=-dist, dimstyle=ds,
                          dxfattribs={"layer": L_DIM}, override=ov)
                if texto:
                    kw["text"] = texto
                d = self.msp.add_aligned_dim(**kw)
                d.render()
                self._reg(d.dimension)
            else:
                self.cota((x1, y1), (x2, y2), (xb, yb), 90 if tipo == "V" else 0, texto=texto,
                          cid=f"{vista}:extra:{i + 1}")
        self._tag = bak

    def _num_cota(self, x):
        """número en cm con el separador decimal del estilo de cota (como las cotas del plano)."""
        sep = "."
        if ESTILO_COTA in self.doc.dimstyles and self.doc.dimstyles.get(ESTILO_COTA).dxf.get("dimdsep", 46) == 44:
            sep = ","
        return fmt_cm(x).replace(",", sep)

    def cadena_pernos(self, puntos, ref, base, vertical=False):
        """cadena de cotas que pasa por pernos: puntos = [(posición mm, dato)], dato = None (borde, eje) o
        {"eje": "u"|"v", "c": cm, "cx": cm, "cy": cm} de un perno. Cada tramo queda con id propio
        (vista:pernos:n) para que al editar su valor se muevan los pernos (disposición manual)."""
        pts = []
        for x, d in sorted(puntos, key=lambda t: t[0]):
            if pts and abs(x - pts[-1][0]) < 0.5:
                if d is not None:
                    pts[-1] = (pts[-1][0], d)
                continue
            pts.append((x, d))
        pos = self._repartir_textos([(a[0], b[0]) for a, b in zip(pts, pts[1:])],
                                    [self._num_cota(abs(b[0] - a[0]) / K) for a, b in zip(pts, pts[1:])])
        for k, ((xa, da), (xb, db)) in enumerate(zip(pts, pts[1:])):
            n = self._cota_k.get(("@pernos",), 0) + 1
            self._cota_k[("@pernos",)] = n
            cid = f"{self._vista}:pernos:{n}"
            self.pernos_cadena[cid] = (da, db)
            if vertical:
                self.cota((ref, xa), (ref, xb), (base, xa), 90, cid=cid, pos_txt=pos[k])
            else:
                self.cota((xa, ref), (xb, ref), (xa, base), 0, cid=cid, pos_txt=pos[k])

    def resolver_pernos(self, p, cid, valor):
        """tramo de una cadena de pernos: mueve los pernos del lado del tramo para que mida `valor` (cm)."""
        da, db = self.pernos_cadena.get(cid, (None, None))
        m0 = self.cotas_info[cid]["medida"]
        delta = float(valor) - m0
        if db is not None:
            ref, lado, d = db, 1, delta
        elif da is not None:
            ref, lado, d = da, -1, -delta
        else:
            return None
        i = 0 if ref["eje"] == "u" else 1
        s_ = pernos_espejo(p, ref.get("cx", 0.0), ref.get("cy", 0.0))[i]
        nuevos = []
        for q in pernos_base(p):
            q = list(q)
            vis = q[i] * s_
            if (vis >= ref["c"] - 1e-3) if lado > 0 else (vis <= ref["c"] + 1e-3):
                q[i] = round((vis + d) * s_, 3)
            nuevos.append([fmt_cm(q[0]).replace(",", "."), fmt_cm(q[1]).replace(",", ".")])
        return {"pernos_disp": OPCIONES["pernos_disp"][2], "pernos_pos": nuevos}

    def _posiciones_cadena(self, vals, textos):
        idx = [i for i in range(len(vals) - 1) if abs(vals[i + 1] - vals[i]) >= 1e-6]
        segs = [(vals[i], vals[i + 1]) for i in idx]
        txts = [(textos[i] if textos and textos[i] else self._num_cota(abs(vals[i + 1] - vals[i]) / K)) for i in idx]
        pos = self._repartir_textos(segs, txts)
        return dict(zip(idx, pos))

    def cadena_h(self, xs, y_ref, y_base, textos=None):
        pos = self._posiciones_cadena(xs, textos)
        for i in range(len(xs) - 1):
            if abs(xs[i + 1] - xs[i]) < 1e-6:
                continue
            t = textos[i] if textos else None
            self.cota((xs[i], y_ref), (xs[i + 1], y_ref), (xs[i], y_base), 0, t, pos_txt=pos.get(i))

    def cadena_v(self, ys, x_ref, x_base, textos=None):
        pos = self._posiciones_cadena(ys, textos)
        for i in range(len(ys) - 1):
            if abs(ys[i + 1] - ys[i]) < 1e-6:
                continue
            t = textos[i] if textos else None
            self.cota((x_ref, ys[i]), (x_ref, ys[i + 1]), (x_base, ys[i]), 90, t, pos_txt=pos.get(i))

    def simbolo(self, clave, x, y, escala_rel=1.0, rot=None, attribs=None, espejo=False):
        p = self.P.get(clave)
        if p is None:
            if clave.startswith("corte"):
                return self._marca_corte(clave, x, y, (attribs or {}).get("A", ""))
            return None
        e = p.copy()
        self.msp.add_entity(e)
        x0, y0 = e.dxf.insert.x, e.dxf.insert.y
        X, Y = self._xy(x, y)
        mats = [Matrix44.translate(-x0, -y0, 0)]
        if rot is not None:
            mats.append(Matrix44.z_rotate(math.radians(rot - e.dxf.rotation)))
        if escala_rel != 1.0:
            mats.append(Matrix44.scale(escala_rel, escala_rel, escala_rel))
        if espejo:
            mats.append(Matrix44.scale(-1, 1, 1))
        mats.append(Matrix44.translate(X, Y, 0))
        e.transform(Matrix44.chain(*mats))
        if attribs:
            for a in e.attribs:
                if a.dxf.tag in attribs:
                    a.dxf.text = attribs[a.dxf.tag]
        self._reg(e)
        if e.attribs:
            self._atributos_editables(e, clave)
        return e

    def _atributos_editables(self, e, clave):
        """símbolo con atributos (círculo de eje, corte, nivel): sus textos se editan por id."""
        tid = self._texto_id("sim-" + clave)
        mod = self._texto_mod(tid)
        auto = {a.dxf.tag: a.dxf.text for a in e.attribs}
        if mod.get("oculto"):
            self._registrar_texto(tid, None, "sim", auto, mod)
            self._borrar(self.msp, e)
            return
        for a in e.attribs:
            v = (mod.get("attr") or {}).get(a.dxf.tag)
            if v is not None and str(v) != "":
                a.dxf.text = str(v)
        if mod.get("dx") or mod.get("dy"):              # símbolo movido a mano
            e.translate(float(mod.get("dx") or 0) * self._esc, float(mod.get("dy") or 0) * self._esc, 0)
        self._registrar_texto(tid, e, "sim", auto, mod)

    # símbolos de material: bloque visible del bloque dinámico original
    SIMB_MAT = {"s_relleno": "LLENO", "s_horm": "ZCONCRETO", "s_emp": "solado"}

    def simbolo_mat(self, clave, x, y, escala_rel=1.0):
        nombre = self.SIMB_MAT[clave]
        proto = self.P.get(clave)
        if nombre not in self.doc.blocks:
            return self.simbolo(clave, x, y, escala_rel)
        if proto is not None:
            sx, sy, capa = proto.dxf.xscale * escala_rel, proto.dxf.yscale * escala_rel, proto.dxf.layer
        else:   # escalas de los símbolos del plano original (1:35)
            k = 1000.2228 if nombre == "solado" else 30074.5221
            sx, sy, capa = (k if nombre == "solado" else -k) * escala_rel, k * escala_rel, L_ACH
        proto = proto or type("P", (), {"dxf": type("D", (), {"layer": capa})()})()
        X, Y = self._xy(x, y)
        e = self.msp.add_blockref(nombre, (X, Y), dxfattribs={
            "layer": proto.dxf.layer, "xscale": sx, "yscale": sy, "zscale": abs(sy)})
        return self._reg(e)

    # orientación del símbolo de corte del plano original (bloque dinámico): rotación y espejo en X
    CORTE_ORIENT = {"corte_izq": (90, -1), "corte_c_izq": (90, -1), "corte_der": (270, 1), "corte_c_der": (270, 1),
                    "corte_b_inf": (180, -1), "corte_b_sup": (0, 1)}
    BLOQUE_CORTE = "HMV_CORTE"

    def _bloque_corte(self):
        """bloque de corte con la geometría del símbolo original (flecha + línea de corte en L + letra)."""
        doc = self.doc
        if self.BLOQUE_CORTE in doc.blocks:
            return self.BLOQUE_CORTE
        for nm in ("GN-ANNO-SYMB", "GN-ANNO-TEXT-H3.5"):
            if nm not in doc.layers:
                doc.layers.add(nm, color=7 if nm.endswith("SYMB") else 4)
        b = doc.blocks.new(self.BLOQUE_CORTE)
        b.add_lwpolyline([(-7.15, 4.8), (-7.15, 6.84), (-16.0, 4.8), (0.0, 4.8), (0.0, 0.0)],
                         dxfattribs={"layer": "GN-ANNO-SYMB"})
        b.add_solid([(-16.0, 4.8), (-7.15, 6.84), (-7.15, 4.8), (-7.15, 4.8)], dxfattribs={"layer": "GN-ANNO-SYMB"})
        estilo = "ROMANS" if "ROMANS" in doc.styles else ESTILO
        a = b.add_attdef("A", (-12.4, 10.0), dxfattribs={"layer": "GN-ANNO-TEXT-H3.5", "height": 3.5,
                                                         "style": estilo})
        a.set_placement((-12.4, 10.0), align=ezdxf.enums.TextEntityAlignment.MIDDLE_CENTER)
        b.block.dxf.flags = int(b.block.dxf.get("flags", 0)) | 2      # bloque con atributos (lo exige el DWG)
        return self.BLOQUE_CORTE

    def _marca_corte(self, clave, x, y, letra):
        """símbolo de corte igual al del plano original (si la plantilla no trae el bloque reconocible):
        bloque HMV_CORTE con la línea de corte en L, la flecha rellena hacia el lado visto y la letra."""
        S = self._esc
        capa = "CERRAMIENTO EXTERNO" if "CERRAMIENTO EXTERNO" in self.doc.layers else L_TXT
        rot, sx = self.CORTE_ORIENT.get(clave, (0, 1))
        k = 50.0 * S / 35.0                       # escala del bloque original (50 a 1:35)
        X, Y = self._xy(x, y)
        ins = self.msp.add_blockref(self._bloque_corte(), (X, Y), dxfattribs={
            "layer": capa, "xscale": sx * k, "yscale": k, "zscale": k, "rotation": rot})
        # la letra queda horizontal (como en el original), al lado de la flecha
        a_, b_ = -12.4 * k, 10.0 * k
        a_ *= sx
        cr, sr = math.cos(math.radians(rot)), math.sin(math.radians(rot))
        px_, py_ = X + a_ * cr - b_ * sr, Y + a_ * sr + b_ * cr
        estilo = "ROMANS" if "ROMANS" in self.doc.styles else ESTILO
        at = ins.add_attrib("A", letra, (px_, py_), dxfattribs={"layer": "GN-ANNO-TEXT-H3.5", "height": 3.5 * k,
                                                                  "style": estilo, "rotation": 0.0})
        at.set_placement((px_, py_), align=ezdxf.enums.TextEntityAlignment.MIDDLE_CENTER)
        at.dxf.owner = ins.dxf.handle          # el atributo pertenece al bloque (si no, el DWG lo pierde)
        self._reg(ins)
        self._atributos_editables(ins, clave)
        return ins

    def eje(self, x, y, tipo, escala_vista):
        clave = "eje_num" if tipo == "NUM" else "eje_letra"
        p = getattr(self, "p", None) or {}
        sup = str(p.get("eje_txt_sup", "EJE"))
        nom = str(p.get("eje_txt_num" if tipo == "NUM" else "eje_txt_letra", tipo))
        bak = self._tag
        self._tag = ("eje_txt_sup", "eje_txt_num" if tipo == "NUM" else "eje_txt_letra")
        e = self.simbolo(clave, x, y, escala_rel=escala_vista / 35.0,
                         attribs={"EJEG": sup, "EJEC": sup, "ESPC": nom})
        self._tag = bak
        return e

    # ------------------------------------------------------------ vistas
    def _empezar(self, vista, p):
        self._vista = vista
        # cada vista en su propia zona del espacio modelo (lejos de la plantilla y de las otras vistas),
        # así ninguna invade la ventana de otra aunque crezca
        i = list(VISTAS).index(vista)
        self._ox, self._oy = 300000.0 + 250000.0 * i, -300000.0
        f = self._f_obj
        se = escala_efectiva(float(p[VISTAS[vista][2]]), f)
        se = (getattr(self, "_esc_forzada", None) or {}).get(vista, se)
        self.esc_eff[vista] = se
        self._esc = se * f        # tamaños de anotación coherentes con la hoja escalada
        self._tag = ()
        self.creados.setdefault(vista, [])
        self._cota_k = {}
        for cid in [k for k, v in self.cotas_info.items() if v["vista"] == vista]:
            self.cotas_info.pop(cid, None)
        for cid in [k for k in self.pernos_cadena if k.startswith(vista + ":")]:
            self.pernos_cadena.pop(cid, None)
        for tid in [k for k, v in self.textos_info.items() if v["vista"] == vista]:
            self.textos_info.pop(tid, None)

    def origen_vista(self, vista):
        """origen en espacio modelo de las coordenadas locales de la vista (mm)."""
        i = list(VISTAS).index(vista)
        return 300000.0 + 250000.0 * i, -300000.0

    def generar(self, p: dict | None = None, vistas=None):
        p = ajustar_estribos(normalizar_params(p))
        self.p = p
        self.c = calcular(p)
        W, H = HOJAS.get(p["hoja"], HOJAS["A1"])
        self._f_obj = W / 841.0
        todas = ["PLANTA", "AA_FORMAS", "BB_FORMAS", "AA_ARM", "BB_ARM", "CC", "ESQUEMA"]
        vistas = list(vistas or todas)
        if abs(self._f_obj - self._f) > 1e-9:
            vistas = todas            # al cambiar la hoja se regeneran todas las vistas
        self.limpiar(vistas)
        # 1) papel de la plantilla de vuelta a coordenadas A1
        if abs(self._f - 1.0) > 1e-9:
            self._escalar_papel(1.0 / self._f)
            self._f = 1.0
        # 2) vistas en espacio modelo
        _nombres = DT.NOMBRES if DT.es_dt(p) else NOMBRE_VISTA_MARCO
        NOMBRE_VISTA.clear()
        NOMBRE_VISTA.update(_nombres)
        self._esc_forzada = {}
        for v in vistas:
            pedida = None
            for _intento in range(8):
                if DT.es_dt(p):
                    DT.dibujar(self, v, p, self.c, sys.modules[__name__])
                else:
                    getattr(self, "_v_" + v.lower())(p, self.c)
                self._cotas_extra(v, p)
                self._cotas_grupo(v, p)
                self._rotulos_extra(v, p)
                # ¿cabe en su ventana de la lámina? si no, se redibuja a la escala normalizada siguiente
                se = self.esc_eff[v]
                pedida = pedida or se
                vp, b = self.vp.get(v), self._extension_vista(v)
                if DT.es_dt(p) or not str(p.get("escala_auto", "Sí")).startswith("S") or \
                        vp is None or b is None or se >= ESCALAS_STD[-1] or \
                        (b.size.x / se / self._f_obj <= vp.dxf.width * 1.02 and
                         b.size.y / se / self._f_obj <= vp.dxf.height * 1.02):
                    break
                self._esc_forzada[v] = next((e for e in ESCALAS_STD if e > se + 1e-6), ESCALAS_STD[-1])
                self.limpiar_vista(v)
            if self.esc_eff[v] != pedida:
                self.c.setdefault("avisos", []).append(
                    f"{NOMBRE_VISTA.get(v, v)}: a 1:{int(round(pedida))} no cabe en su ventana; se dibujó a "
                    f"1:{int(round(self.esc_eff[v]))} (cambie su escala en «Escalas» si prefiere otra).")
        self._tag = ()
        # 3) papel (tablas, notas, referencias, viñeta) en coordenadas A1
        self._papel(p, self.c)
        # 4) escalar la hoja al tamaño elegido
        if abs(self._f_obj - 1.0) > 1e-9:
            self._escalar_papel(self._f_obj, generados=True)
            self._f = self._f_obj
        self._tamano_hoja(W, H)
        ctb = p.get("ctb") or cargar_normas().get("ctb")
        if ctb:
            self.ps.dxf_layout.dxf.current_style_sheet = os.path.basename(ctb)
        # 5) formato del cliente a tamaño real
        self._formato_cliente(p)
        self._ajustar_viewports(p)
        self._capas(p)
        self._ventana_ploteo(W, H)
        if p["formato"].startswith("Original") and p["hoja"] != "A1":
            self.c["avisos"].append(f"El formato original es A1: se reduce/amplía a {p['hoja']}.")
        return self.c

    # ------------------------------------------------------------ hoja/formato
    def _escalar_papel(self, k, generados=False):
        m = Matrix44.scale(k, k, k)
        excl = set(id(e) for e in self.creados_post)
        if not generados:
            excl |= set(id(e) for e in self.creados_ps)
        for e in list(self.ps):
            if id(e) in excl:
                continue
            t = e.dxftype()
            if t == "VIEWPORT":
                e.dxf.center = Vec3(e.dxf.center) * k
                e.dxf.width = e.dxf.width * k
                e.dxf.height = e.dxf.height * k
                e.dxf.view_height = e.dxf.view_height * k
                continue
            try:
                e.transform(m)
            except Exception:
                pass

    def _tamano_hoja(self, W, H):
        """Hoja del formato (W×H, apaisada) y configuración de página de la lámina:
        papel de ploteo (por defecto el de la plantilla, p. ej. A0), ventana = marco completo y
        escala «ajustar al papel», como en el plano original."""
        lay = self.ps.dxf_layout.dxf
        lay.limmin = (0, 0)
        lay.limmax = (W, H)
        papel = str(getattr(self, "p", {}).get("papel_plot", "Según plantilla"))
        if papel in HOJAS:
            PW, PH = HOJAS[papel]                       # apaisado (largo, corto)
        elif self._lay0.get("paper_width") and self._lay0.get("paper_height"):
            PW, PH = max(self._lay0["paper_width"], self._lay0["paper_height"]), \
                min(self._lay0["paper_width"], self._lay0["paper_height"])
            if abs(PW - 841.0) < 1 and abs(W - 841.0) > 1:   # plantilla en A1 y hoja distinta: papel = hoja
                PW, PH = W, H
        else:
            PW, PH = W, H
        nombre = None
        for k_, (w_, h_) in HOJAS.items():
            if abs(w_ - PW) < 1 and abs(h_ - PH) < 1:
                nombre = k_
        orig = self._lay0.get("paper_size") or ""
        if nombre:
            m = re.search(r"\(([\d.]+)_x_([\d.]+)_MM\)", orig)
            if m and abs(max(float(m.group(1)), float(m.group(2))) - PW) < 1:
                lay.paper_size = orig                    # mismo papel que la plantilla: nombre original
            else:
                lay.paper_size = {"A0": "ISO_full_bleed_A0_(841.00_x_1189.00_MM)",
                                  "A1": "ISO_full_bleed_A1_(594.00_x_841.00_MM)",
                                  "A2": "ISO_full_bleed_A2_(420.00_x_594.00_MM)",
                                  "A3": "ISO_full_bleed_A3_(297.00_x_420.00_MM)",
                                  "A4": "ISO_full_bleed_A4_(210.00_x_297.00_MM)"}[nombre]
        # orientación del papel según el nombre del medio: «(841.00_x_594.00_MM)» = apaisado sin giro;
        # «(594.00_x_841.00_MM)» = vertical con plot_rotation = 1 (90°). Si no coinciden, el CAD dibuja la hoja
        # chica y corrida respecto del marco.
        m = re.search(r"\(([\d.]+)_x_([\d.]+)_MM\)", str(lay.get("paper_size", "") or ""))
        if m:
            apaisado = float(m.group(1)) > float(m.group(2))
        else:
            w0, h0 = self._lay0.get("paper_width") or PH, self._lay0.get("paper_height") or PW
            apaisado = w0 > h0
        if apaisado:
            lay.paper_width, lay.paper_height, lay.plot_rotation = PW, PH, 0
        else:
            lay.paper_width, lay.paper_height, lay.plot_rotation = PH, PW, 1
        self._papel_wh = (PW, PH)
        self.papel_plot = next((k_ for k_, (w_, h_) in HOJAS.items() if abs(w_ - PW) < 1 and abs(h_ - PH) < 1), "A0")

    def _ventana_ploteo(self, W, H):
        """ventana de ploteo = marco de la hoja realmente dibujado; escala «ajustar al papel»
        (AutoCAD la recalcula igual al abrir: flag 16 + standard_scale_type 0)."""
        from ezdxf import bbox as _bb
        lay = self.ps.dxf_layout.dxf
        PW, PH = getattr(self, "_papel_wh", (W, H))
        marcos = [i for i in self.formato_orig if i.is_alive and not i.dxf.get("invisible", 0)
                  and i.dxf.name.upper().startswith("T-F-")]
        if not marcos:
            marcos = [e for e in self.creados_post if e.is_alive and e.dxftype() == "INSERT"]
        caja = _bb.extents(marcos) if marcos else None
        if caja is not None and caja.has_data and caja.size.x > 0.5 * W:
            x1, y1, x2, y2 = caja.extmin.x, caja.extmin.y, caja.extmax.x, caja.extmax.y
        else:
            x1, y1, x2, y2 = 0.0, 0.0, W, H
        lay.plot_window_x1, lay.plot_window_y1 = x1, y1
        lay.plot_window_x2, lay.plot_window_y2 = x2, y2
        lay.limmin, lay.limmax = (min(0.0, x1), min(0.0, y1)), (max(W, x2), max(H, y2))
        ww, wh = (x2 - x1) or W, (y2 - y1) or H
        util_l = PW - lay.get("top_margin", 0.0) - lay.get("bottom_margin", 0.0)
        util_c = PH - lay.get("left_margin", 0.0) - lay.get("right_margin", 0.0)
        k = min(util_l / ww, util_c / wh)
        lay.plot_type = 4                                # ventana
        lay.scale_numerator = 1.0
        lay.scale_denominator = 1.0 / k
        lay.standard_scale_type = 0
        lay.plot_layout_flags = int(lay.get("plot_layout_flags", 0)) | 16 | 4   # escala estándar (ajustar) + centrado
        self.hoja_wh = (W, H)

    def _formato_cliente(self, p):
        original = p["formato"].startswith("Original")
        for ins in self.formato_orig:
            if not ins.is_alive:
                continue
            ins.dxf.invisible = 0 if original else 1
            for a in ins.attribs:
                a.dxf.invisible = 0 if original else 1
        if not p["formato"].startswith("Personalizado"):
            return
        ruta = (p.get("formato_archivo") or "").strip()
        if not ruta or not os.path.exists(ruta):
            self.c["avisos"].append("Formato personalizado: seleccione un archivo DXF/DWG válido.")
            return
        nombre = self._importar_formato(ruta)
        if not nombre:
            return
        ins = self.ps.add_blockref(nombre, (0, 0), dxfattribs={"layer": "0"})
        if self.doc.blocks[nombre].query("ATTDEF"):
            ins.add_auto_attribs({})
        self.creados_post.append(ins)
        self.tags[ins.dxf.handle] = ("@vineta",)
        self._aplicar_overrides(ins, nombre)

    def _importar_formato(self, ruta):
        if ruta in self._fmt_bloques and self._fmt_bloques[ruta] in self.doc.blocks:
            return self._fmt_bloques[ruta]
        from ezdxf import xref
        src_path = ruta
        if ruta.lower().endswith(".dwg"):
            src_path = os.path.splitext(ruta)[0] + "_formato_tmp.dxf"
            convertir_a_dxf(ruta, src_path)
        sdoc = ezdxf.readfile(src_path)
        smsp = sdoc.modelspace()
        nombre = "FORMATO_" + re.sub(r"[^A-Za-z0-9_]", "_", os.path.splitext(os.path.basename(ruta))[0])[:40]
        n = 1
        base = nombre
        while nombre in self.doc.blocks:
            n += 1
            nombre = f"{base}_{n}"
        blk = self.doc.blocks.new(nombre)
        loader = xref.Loader(sdoc, self.doc, conflict_policy=xref.ConflictPolicy.NUM_PREFIX)
        fuente = smsp
        if len(smsp) == 0:
            for lay in sdoc.layouts:
                if lay.name != "Model" and len(lay):
                    fuente = lay
                    break
        if fuente is smsp:
            loader.load_modelspace(target_layout=blk)
        else:
            loader.load_paperspace_layout_into(fuente, blk)
        loader.execute()
        # origen del bloque = esquina inferior izquierda del formato
        try:
            b = bbox.extents(blk, fast=True)
            if b.has_data:
                blk.block.dxf.base_point = (b.extmin.x, b.extmin.y, 0)
        except Exception:
            pass
        self._fmt_bloques[ruta] = nombre
        return nombre

    def _capas(self, p):
        off = p.get("capas_off")
        if off is None:
            off = self.capas_off_plantilla
        off = set(off)
        for l in self.doc.layers:
            if l.dxf.name in off:
                l.off()
            else:
                l.on()

    def capas(self):
        return sorted(l.dxf.name for l in self.doc.layers)

    # ---- PLANTA ---    # ---- PLANTA ----------------------------------------------------------
    def _v_planta(self, p, c):
        self._empezar("PLANTA", p)
        S = self._esc
        Ly, Lx = p["Lfy"] * K, p["Lfx"] * K
        px, py = p["ped_x"] * K, p["ped_y"] * K
        ys = [y * K for y in c["ped_pos"]]                 # columnas (horizontal en planta)
        xs_f = [x * K for x in c.get("ped_pos_x", [0.0])]  # filas (vertical en planta)
        fila_top, fila_bot = xs_f[-1], xs_f[0]
        self._t("Lfx", "Lfy")
        self.rect(-Ly / 2, -Lx / 2, Ly / 2, Lx / 2, L_FUND)
        for xc in xs_f:
            for yc in ys:
                self._t("ped_x", "ped_y", "n_ped", "dist_ped", "n_ped_x", "dist_ped_x")
                self.rect(yc - py / 2, xc - px / 2, yc + py / 2, xc + px / 2, L_EST)
                self._t("pernos_disp", "perno_sep", "PERF", "pernos_ped", "perno_txt")
                pts = [(u * K, v * K) for (u, v) in pernos_xy(p, yc / K, xc / K)]
                for (u, v) in pts:
                    self.circ(yc + u, xc + v, p["PERF"] / 2, L_EST)
                # líneas de perforaciones (por cada fila y columna de pernos)
                us, vs = sorted({round(u, 3) for u, _ in pts}), sorted({round(v, 3) for _, v in pts})
                for v in vs:
                    self.pl([(yc + us[0] - 90, xc + v), (yc + us[-1] + 90, xc + v)], L_EJE)
                for u in us:
                    self.pl([(yc + u, xc + vs[0] - 90), (yc + u, xc + vs[-1] + 90)], L_EJE)
        # ejes de los pedestales (columnas y filas)
        self._t()
        for yc in ys:
            self.pl([(yc, fila_bot - px / 2 - 150), (yc, fila_top + px / 2 + 150)], L_EJE)
        if len(xs_f) > 1:
            for xc in xs_f:
                self.pl([(ys[0] - py / 2 - 150, xc), (ys[-1] + py / 2 + 150, xc)], L_EJE)
        # ejes principales
        ex = Ly / 2 + 50 * S
        self.ln((-ex, 0), (ex, 0), L_EJE)
        ey_top = Lx / 2 + 26 * S
        ey_bot = -Lx / 2 - 22 * S
        self.ln((0, ey_bot), (0, ey_top), L_EJE)
        self.eje(0, ey_top, "NUM", S)
        self.eje(-ex, 0, "LETRA", S)
        # cortes A-A (por la fila superior de pedestales) y B-B (por la última columna)
        ya = fila_top if len(xs_f) > 1 else 0.0
        self.simbolo("corte_izq", -Ly / 2 - 26, ya - 11, S / 35.0, attribs={"A": "A"})
        self.simbolo("corte_der", Ly / 2, ya - 11, S / 35.0, attribs={"A": "A"})
        xb = ys[-1]
        self.simbolo("corte_b_inf", xb + 235, -Lx / 2 - 53 * S / 35 * 1.0 - 0, S / 35.0, attribs={"A": "B"})
        self.simbolo("corte_b_sup", xb + 215, Lx / 2 + 199 * S / 35, S / 35.0, attribs={"A": "B"})
        self.ln((xb, -Lx / 2 - 30 * S / 3.5 / 10), (xb, Lx / 2 + 30 * S / 3.5 / 10), L_EJE)
        # cotas generales
        self._t("Lfy", "ped_y", "dist_ped")
        self.cadena_h([-Ly / 2] + ys + [Ly / 2], Lx / 2, Lx / 2 + 12 * S)
        self._t("Lfy")
        self.cota((-Ly / 2, -Lx / 2), (Ly / 2, -Lx / 2), (-Ly / 2, -Lx / 2 - 12 * S))
        self._t("Lfx", "ped_x", "dist_ped_x", "n_ped_x")
        xcad = -Ly / 2 + 0.55 * (Ly / 2 + ys[0] - py / 2)
        self.cadena_v([-Lx / 2] + (xs_f if len(xs_f) > 1 else [0.0]) + [Lx / 2], xcad, xcad)
        self._t("Lfx")
        self.cota((Ly / 2, -Lx / 2), (Ly / 2, Lx / 2), (Ly / 2 + 14 * S, -Lx / 2), 90)
        # cotas de cada pedestal: las horizontales en la fila superior, las verticales en la columna izquierda
        for i, yc in enumerate(ys):
            xl, xr = yc - py / 2, yc + py / 2
            cx = yc / K
            yt = fila_top + px / 2
            self._t("pernos_disp", "perno_sep", "pernos_sx", "pernos_sy", "ped_y", "ped_x")
            self.cadena_pernos([(xl, None), (xr, None)] + [
                (yc + u * K, {"eje": "u", "c": u, "cx": cx, "cy": fila_top / K})
                for u in pernos_proy(p, "u", cx, fila_top / K)], yt, yt + 4 * S)
            self._t("perno_sep", "ped_y", "ped_x")
            self.cota((xl, yt), (xr, yt), (xl, yt + 8.5 * S))
            if i < len(ys) - 1:
                self._t("dist_ped")
                self.cota((xr, yt), (ys[i + 1] - py / 2, yt), (xr, yt + 8.5 * S))
        xl = ys[0] - py / 2
        for j, xc in enumerate(xs_f):
            cy = xc / K
            self._t("pernos_disp", "perno_sep", "pernos_sx", "pernos_sy", "ped_y", "ped_x")
            self.cadena_pernos([(xc - px / 2, None), (xc + px / 2, None)] + [
                (xc + v * K, {"eje": "v", "c": v, "cx": ys[0] / K, "cy": cy})
                for v in pernos_proy(p, "v", ys[0] / K, cy)], xl, xl - 4 * S, vertical=True)
            self._t("perno_sep", "ped_y", "ped_x")
            self.cota((xl, xc - px / 2), (xl, xc + px / 2), (xl - 8.5 * S, xc - px / 2), 90)
            if j < len(xs_f) - 1:
                self._t("dist_ped_x")
                self.cota((xl, xc + px / 2), (xl, xs_f[j + 1] - px / 2), (xl - 8.5 * S, xc + px / 2), 90)
        # rótulos
        self._t("perno_txt", "perno_d", "perno_desc", "perno_sep")
        verde = 3
        u0, v0 = min(pernos_xy(p, ys[0] / K, fila_top / K), key=lambda q: (q[0], -q[1]))
        u1, v1 = max(pernos_xy(p, ys[-1] / K, fila_bot / K), key=lambda q: (q[0], -q[1]))
        u0, v0, u1, v1 = u0 * K, v0 * K + fila_top, u1 * K, v1 * K + fila_bot
        self.rotulo([(ys[0] + u0, v0), (ys[0] + u0 - 3 * S, Lx / 2 + 22 * S), (ys[0] + u0 - 18 * S, Lx / 2 + 22 * S)],
                    "PERNO DE ANCLAJE (TÍP.)\\P(VER DETALLE 1)", 2.2, color=verde, lado=-1, italic=True)
        self.rotulo([(ys[-1] + u1, v1), (Ly / 2 + 2 * S, -Lx / 2 - 4 * S), (Ly / 2 + 5 * S, -Lx / 2 - 4 * S)],
                    f"PERNO DE ANCLAJE %%C{p['perno_txt']}", 2.2, color=verde, lado=1, italic=True)

    def _pernos_seccion(self, p, vista, centros, sep_pernos=None):
        """pernos que se ven en un corte, por pedestal: [(desplazamiento cm desde el centro, dato del perno)].
        A-A mira a lo largo de la planta (coordenada u de los pernos), B-B de través (coordenada v)."""
        aa = vista.startswith("AA")
        out = []
        for xc in centros:
            if sep_pernos is not None:                     # compatibilidad: separación simétrica fija
                vals = sorted({-float(sep_pernos) / 2, float(sep_pernos) / 2})
                out.append([(v, None) for v in vals])
                continue
            if DT.es_dt(p):                                # pedestales sobre el eje de cada zapata, a ±dpy
                dpy = (float(p["ped_y"]) + float(p["dist_ped"])) / 2.0
                cx, cy = (0.0, dpy) if aa else (0.0, float(xc))
            else:                                          # A-A: fila superior · B-B: última columna
                cc_ = calcular(p)
                fila = cc_.get("ped_pos_x", [0.0])[-1] if len(cc_.get("ped_pos_x", [0.0])) > 1 else 0.0
                cx, cy = (float(xc), float(fila)) if aa else (float(cc_["ped_pos"][-1]), float(xc))
            eje = "u" if aa else "v"
            out.append([(v, {"eje": eje, "c": v, "cx": cx, "cy": cy}) for v in pernos_proy(p, eje, cx, cy)])
        return out

    # ---- secciones de formas ----------------------------------------------
    def _seccion_formas(self, p, c, vista, ancho, centros, w_ped, eje_tipo, sep_pernos=None):
        self._empezar(vista, p)
        S = self._esc
        W = ancho * K
        wp = w_ped * K
        H = p["HLf"] * K
        y0 = 0.0                                   # coronamiento relleno (nivel de patio de diseño)
        y_nap = p["e_grava"] * K
        y_tp = p["dPd"] * K
        y_tz = -(p["Df"] - p["HLf"]) * K
        y_s = -p["Df"] * K
        y_e = y_s - p["e_emp"] * K
        xs_c = [x * K for x in centros]
        pern = self._pernos_seccion(p, vista, centros, sep_pernos)
        # contorno hormigón
        k_ancho = "Lfy" if vista.startswith("AA") else "Lfx"
        k_ped = "ped_y" if vista.startswith("AA") else "ped_x"
        self._t(k_ancho, "HLf", "Df", "dPd", k_ped, "dist_ped")
        pts = [(-W / 2, y_s), (W / 2, y_s), (W / 2, y_tz)]
        for xc in reversed(xs_c):
            pts += [(xc + wp / 2, y_tz), (xc + wp / 2, y_tp), (xc - wp / 2, y_tp), (xc - wp / 2, y_tz)]
        pts += [(-W / 2, y_tz)]
        self.pl(pts, L_FUND, closed=True)
        self._t("e_emp")
        # emplantillado
        self.rect(-W / 2, y_e, W / 2, y_s, L_EMP)
        n_e = max(int(W / 700), 2)
        for i in range(n_e):
            self.simbolo_mat("s_emp", -W / 2 + (i + 0.5) * W / n_e - 60, y_e + 0.3 * (y_s - y_e), S / 35.0)
        # excavación teórica (zapata hormigonada contra terreno)
        self._t("Df", "sobreexc")
        ext = 5.2 * S
        for sgn in (-1, 1):
            xe = sgn * W / 2
            self.ln((xe, y_s), (xe, y0), L_FINA, color=1)
            self.hatch([(xe, y_e), (xe + sgn * ext, y_e), (xe + sgn * ext, y0), (xe, y0)],
                       "EARTH", S / 35.0)
        # grava de patio y relleno
        self._t("e_grava")
        gx = W / 2 + 10 * S
        bordes = [-gx] + sum([[xc - wp / 2, xc + wp / 2] for xc in xs_c], []) + [gx]
        for i in range(0, len(bordes), 2):
            a, b = bordes[i], bordes[i + 1]
            self.hatch([(a, y0), (b, y0), (b, y_nap), (a, y_nap)], "GRAVEL", S / 35.0)
            self.ln((a, y_nap), (b, y_nap), L_FINA)
            self.ln((a, y0), (b, y0), L_FINA, color=1)
        q = self.P.get("quiebre")
        izq_espejo = q is not None and q.dxf.xscale > 0
        self.simbolo("quiebre", -gx, (y0 + y_nap) / 2, S / 35.0, espejo=izq_espejo)
        self.simbolo("quiebre", gx, (y0 + y_nap) / 2, S / 35.0, espejo=not izq_espejo)
        # símbolos de relleno y hormigón
        for i in range(len(bordes) - 1):
            a, b = bordes[i], bordes[i + 1]
            if i % 2 == 0:  # zona de relleno
                a = max(a, -W / 2)
                b = min(b, W / 2)
                if b - a < 300:
                    continue
                for fy in (0.3, 0.7):
                    self.simbolo_mat("s_relleno", a + 0.45 * (b - a), y_tz + fy * (y0 - y_tz), S / 35)
        for xc in xs_c:
            for fy in (0.15, 0.55, 0.9):
                self.simbolo_mat("s_horm", xc, y_tz + (y_tp - y_tz) * fy - (y_tz - y_s) * 0.3 * (fy < 0.2), S / 35)
        # pernos, grout y placas
        self._t("pernos_disp", "perno_sep", "perno_desc", "L", "e_grout")
        for xc, pp_ in zip(xs_c, pern):
            for dx, _d in pp_:
                xb = xc + dx * K
                self.simbolo("perno", xb, y_tp + 170, 1.0)
                g = p["G"] * 0.6
                self.pl([(xb - 92, y_tp), (xb - 62, y_tp + 30), (xb + 62, y_tp + 30), (xb + 92, y_tp)], L_MONT)
                self.hatch([(xb - 92, y_tp), (xb + 92, y_tp), (xb + 62, y_tp + 30), (xb - 62, y_tp + 30)],
                           "ANSI31", 1.0)
                self.rect(xb - 81, y_tp + 30, xb + 81, y_tp + 50, L_PLET)
        # eje
        self._t()
        y_eje = y_tp + 28 * S
        self.ln((0, y_e), (0, y_eje), L_EJE)
        self.eje(0, y_eje, eje_tipo, S)
        # niveles
        xr = xs_c[-1] + wp / 2
        self.simbolo("nth", xr + 30, y_tp, S / 35.0 * 1.0)
        self.simbolo("nap", gx + 3 * S, y_nap, S / 35.0)
        # cotas inferiores
        xs = [-W / 2] + sum([[xc - wp / 2, xc + wp / 2] for xc in xs_c], []) + [W / 2]
        self._t(k_ancho, k_ped, "dist_ped")
        self.cadena_h(xs, y_e, y_e - 6 * S)
        self._t(k_ancho)
        self.cota((-W / 2, y_e), (W / 2, y_e), (-W / 2, y_e - 13 * S))
        self._t("pernos_disp", "perno_sep", "dist_ped")
        # cotas superiores (pernos)
        pts_t = []
        for i, (xc, pp_) in enumerate(zip(xs_c, pern)):
            pts_t += [(xc - wp / 2, None), (xc + wp / 2, None)] + [(xc + dx * K, d) for dx, d in pp_]
            if i < len(xs_c) - 1 and len(xs_c) == 2:
                pts_t += [(0.0, None)]
        self.cadena_pernos(pts_t, y_tp + 50, y_tp + 13 * S)
        # cotas verticales izquierda
        xl = -W / 2 - 6.0 * S
        self._t("HLf")
        self.cadena_v([y_s, y_tz], -W / 2, xl)
        self._t("Df", "HLf", "e_grava")
        self.cadena_v([y_tz, y0, y_nap], -W / 2, xl)
        self._t("dPd")
        self.cota((-W / 2, y0), (xs[1], y_tp), (xl - 6 * S, y0), 90)
        self._t("dPd", "Df", "HLf")
        self.cota((-W / 2, y_tz), (xs[1], y_tp), (xl - 12 * S, y_tz), 90)
        self._t("e_emp")
        # rótulos
        verde = 3
        xt = W / 2 + 9 * S
        self.rotulo([(W / 2 - 8 * S, y0 - 0.25 * (y0 - y_tz)), (W / 2 + 5 * S, y0 - 0.45 * (y0 - y_tz)), (xt, y0 - 0.45 * (y0 - y_tz))],
                    "RELLENO ESTRUCTURAL\\PCOMPACTADO", 2.5, color=verde, italic=True)
        self.rotulo([(W / 2, y_tz + 0.35 * (y0 - y_tz)), (W / 2 + 5 * S, y_tz + 0.05 * (y0 - y_tz)), (xt, y_tz + 0.05 * (y0 - y_tz))],
                    "LÍNEA DE EXCAVACIÓN\\PTEÓRICA", 2.5, color=verde, italic=True)
        self.rotulo([(W / 2 - 1 * S, y_e), (W / 2 + 5 * S, y_e - 10 * S), (xt, y_e - 10 * S)],
                    f"EMPLANTILLADO\\Pe= {fmt_cm(p['e_emp'])}", 2.5, color=verde, italic=True)

    def _v_aa_formas(self, p, c):
        self._seccion_formas(p, c, "AA_FORMAS", p["Lfy"], c["ped_pos"], p["ped_y"], "NUM")

    def _v_bb_formas(self, p, c):
        self._seccion_formas(p, c, "BB_FORMAS", p["Lfx"], c.get("ped_pos_x", [0.0]), p["ped_x"], "LETRA")

    # ---- secciones de armaduras -------------------------------------------
    def _seccion_armadura(self, p, c, vista, ancho, centros, w_ped, eje_tipo,
                          db_lin, marca_lin, n_pts, s_pts, db_pts, marca_pts, L_pts, corte_c, sep_pernos=None):
        self._empezar(vista, p)
        pos_est = posiciones_estribos(p)
        self.estribos_ref.pop(vista, None)
        S = self._esc
        W = ancho * K
        wp = w_ped * K
        y_tp = p["dPd"] * K
        y_tz = -(p["Df"] - p["HLf"]) * K
        y_s = -p["Df"] * K
        pern = self._pernos_seccion(p, vista, centros, sep_pernos)
        k_rl = "rec_lat_y" if vista.startswith("AA") else "rec_lat_x"
        rec_l = rec_y(p) if vista.startswith("AA") else rec_x(p)
        ri, rs, rl = p["rec_inf"] * K, p["rec_sup"] * K, rec_l * K
        xs_c = [x * K for x in centros]
        es_aa = vista.startswith("AA")
        k_l = ("db_y", "n_y", "s_y") if es_aa else ("db_x", "n_x", "s_x")
        k_p = ("db_x", "n_x", "s_x") if es_aa else ("db_y", "n_y", "s_y")
        self._t("Lfy" if es_aa else "Lfx", "HLf", "Df", "dPd")
        pts = [(-W / 2, y_s), (W / 2, y_s), (W / 2, y_tz)]
        for xc in reversed(xs_c):
            pts += [(xc + wp / 2, y_tz), (xc + wp / 2, y_tp), (xc - wp / 2, y_tp), (xc - wp / 2, y_tz)]
        pts += [(-W / 2, y_tz)]
        self.pl(pts, L_FUND, closed=True)
        self._t(*k_l, "rec_inf", "rec_sup", "rec_lat", k_rl)
        # barras de la losa en el plano del corte (con ganchos)
        yb = y_s + ri + db_lin / 2
        yt = y_tz - rs - db_lin / 2
        xa = -W / 2 + rl
        xb = W / 2 - rl
        r = 3 * db_lin
        self.pl([(xa, yt - 25), (xa, yb), (xb, yb), (xb, yt - 25)], L_FIERRO, color=3)
        self.pl([(xa + 25, yb + 25), (xa + 25, yt), (xb - 25, yt), (xb - 25, yb + 25)], L_FIERRO, color=3)
        # barras perpendiculares (puntos)
        esq = float(p.get("esq_x" if k_p[1] == "n_x" else "esq_y") or 0.0)
        posx = posiciones_barras(L_pts, n_pts, s_pts, rec_l, esq)
        s_lab = separacion_real(L_pts, n_pts, s_pts, rec_l, esq)
        self._t(*k_p)
        for xx in posx:
            self.punto(xx * K, yb + db_lin / 2 + db_pts / 2, db_pts)
            self.punto(xx * K, yt - db_lin / 2 - db_pts / 2, db_pts)
        # posiciones (coordenadas locales de la vista, mm) para acotar grupos de elementos
        self.elementos[vista] = {
            "barras": {"x": [xx * K for xx in posx], "y": y_s, "marca": marca_pts, "eje": "x"},
            "estribos": {"y": [y_tp - pe * K for pe in pos_est], "x": xs_c[0] - wp / 2, "marca": c["m_est"],
                         "eje": "y", "marca2": c["m_tra"], "n_trabas": trabas_por_nivel(p)},
        }
        # pedestales
        cp = c["c_ped"] * K
        yb_ped = y_s + ri + db_lin + db_pts + p["db_ped"] / 2
        yt_ped = y_tp - p["rec_ped_sup"] * K
        gp = p["gancho_ped"] * K
        re_ = p["rec_ped"] * K
        for xc, pp_ in zip(xs_c, pern):
            x1, x2 = xc - wp / 2 + cp, xc + wp / 2 - cp
            self._t("db_ped", "n_cara", "gancho_ped", "rec_ped_sup")
            self.pl([(x1 + gp, yt_ped), (x1, yt_ped), (x1, yb_ped), (x1 + gp, yb_ped)], L_FIERRO, color=3)
            self.pl([(x2 - gp, yt_ped - 25), (x2, yt_ped - 25), (x2, yb_ped + 25), (x2 - gp, yb_ped + 25)], L_FIERRO, color=3)
            # estribos (cada uno identificable: se arrastra, se quita o se agrega con el mouse)
            for k, pe in enumerate(pos_est):
                ye = y_tp - pe * K
                self._t("@estribo", str(k), "n_est", "s_est", "db_est", "est_reparto")
                self.ln((xc - wp / 2 + re_, ye), (xc + wp / 2 - re_, ye), L_FIERRO, color=3)
            self._t()
            self.estribos_ref.setdefault(vista, {"y_tp": self._xy(0, y_tp)[1], "hpd": c["HPd"], "x": []})
            self.estribos_ref[vista]["x"].append(
                (self._xy(xc - wp / 2, 0)[0], self._xy(xc + wp / 2, 0)[0]))
            # pernos
            self._t("pernos_disp", "perno_sep", "perno_desc", "L")
            for dx, _d in pp_:
                xbp = xc + dx * K
                self.simbolo("perno", xbp, y_tp + 170, 1.0)
                self.pl([(xbp - 92, y_tp), (xbp - 62, y_tp + 30), (xbp + 62, y_tp + 30), (xbp + 92, y_tp)], L_MONT)
                self.hatch([(xbp - 92, y_tp), (xbp + 92, y_tp), (xbp + 62, y_tp + 30), (xbp - 62, y_tp + 30)],
                           "ANSI31", 1.0)
                self.rect(xbp - 81, y_tp + 30, xbp + 81, y_tp + 50, L_PLET)
        # eje
        self._t()
        y_eje = y_tp + 28 * S
        self.ln((0, y_s - 30), (0, y_eje), L_EJE)
        self.eje(0, y_eje, eje_tipo, S)
        # cotas superiores
        pts_t = []
        for xc, pp_ in zip(xs_c, pern):
            pts_t += [(xc + dx * K, d) for dx, d in pp_]
        bordes = [xs_c[0] - wp / 2, xs_c[-1] + wp / 2]
        pts_t += [(x, None) for x in bordes]
        if len(xs_c) == 1:
            pts_t += [(xs_c[0] - wp / 2, None), (xs_c[0] + wp / 2, None)]
        self._t("pernos_disp", "perno_sep", "dist_ped")
        self.cadena_pernos(pts_t, y_tp + 50, y_tp + 13 * S)
        # cotas estribos (pedestal izquierdo): tope | tramos de igual separación | losa
        xl0 = xs_c[0] - wp / 2
        xcota = xl0 - 8 * S
        self._cotas_estribos(p, c, vista, pos_est, xl0, xcota, y_tp, y_tz, S)
        # recubrimientos
        self._t("rec_sup", "rec_inf", "rec_lat", k_rl)
        self.cota((-W / 2, y_tz), (xa, yt + db_lin / 2), (-W / 2 - 4 * S, y_tz), 90,
                  cid=f"{vista}:rec:superior")
        self._t("rec_inf", "rec_sup", "rec_lat", k_rl)
        self.cota((-W / 2, y_s), (xa, yb - db_lin / 2), (-W / 2 - 4 * S, y_s), 90, cid=f"{vista}:rec:inferior")
        self._t(k_rl, "rec_lat", "rec_inf", "rec_sup")
        self.cota((-W / 2, y_s), (xa, y_s), (-W / 2, y_s - 4 * S), cid=f"{vista}:rec:lateral_izq")
        self.cota((xb, y_s), (W / 2, y_s), (xb, y_s - 4 * S), cid=f"{vista}:rec:lateral_der")
        # cota de reparto de barras perpendiculares
        self._t(*k_p)
        n_tot = int(n_pts)
        con_esq = esq > 0 and len(posx) >= 4
        self.cota((posx[0] * K, y_s), (posx[-1] * K, y_s), (posx[0] * K, y_s - (11.5 if con_esq else 9) * S),
                  texto=f"{n_tot}-{marca_pts}@{self._num_cota(s_lab)} (SUP E INF)")
        if con_esq:
            # distancia barra de esquina – 1ª repartida, a ambos lados (línea propia bajo los recubrimientos)
            self._t(k_p[1], "esq_x" if k_p[1] == "n_x" else "esq_y")
            self.cota((posx[0] * K, y_s), (posx[1] * K, y_s), (posx[0] * K, y_s - 7.5 * S))
            self.cota((posx[-2] * K, y_s), (posx[-1] * K, y_s), (posx[-2] * K, y_s - 7.5 * S))
        # rótulos
        self._t("db_ped", "n_cara", "gancho_ped")
        xc0 = xs_c[-1]
        self.rotulo([(xc0 + wp / 2 - cp, (yt_ped + y_tz) / 2 + 300), (xc0 + wp / 2 + 6 * S, (yt_ped + y_tz) / 2 + 900),
                     (xc0 + wp / 2 + 10 * S, (yt_ped + y_tz) / 2 + 900)], c["m_ped"], 3.0)
        if len(xs_c) > 1:
            xc1 = xs_c[0]
            self.rotulo([(xc1 + wp / 2 - cp, (yt_ped + y_tz) / 2 + 400), (xc1 + wp / 2 + 3 * S, (yt_ped + y_tz) / 2 + 1000),
                         (xc1 + wp / 2 + 7 * S, (yt_ped + y_tz) / 2 + 1000)], c["m_ped"], 3.0)
        xm = W / 2 - 0.12 * W
        self._t(*k_l)
        self.rotulo([(xm, yb), (xm, y_tz + 9 * S), (xm + 3 * S, y_tz + 9 * S)], marca_lin, 3.0)
        # cortes C-C
        if corte_c:
            xl = xs_c[0] - wp / 2
            xr = xs_c[0] + wp / 2
            ym = (y_tp + y_tz) / 2
            self.simbolo("corte_c_izq", xl - 4, ym, S / 35.0, attribs={"A": "C"})
            self.simbolo("corte_c_der", xr, ym, S / 35.0, attribs={"A": "C"})

    @staticmethod
    def tramos_estribos(pos, tol=0.05):
        """tramos de separación constante: [(i_inicio, i_fin, separación)] (índices en pos)."""
        tramos = []
        i = 0
        while i < len(pos) - 1:
            s = pos[i + 1] - pos[i]
            j = i + 1
            while j < len(pos) - 1 and abs((pos[j + 1] - pos[j]) - s) <= tol:
                j += 1
            tramos.append((i, j, s))
            i = j
        return tramos

    def _cotas_estribos(self, p, c, vista, pos, xl0, xcota, y_tp, y_tz, S):
        y = lambda pe: y_tp - pe * K
        claves = ("est_reparto", "est_top", "est_bot", "s_est", "n_est", "n_trabas")
        self._t(*claves)
        if not pos:
            return
        self.cota((xl0, y_tp), (xl0, y(pos[0])), (xcota + 5 * S, y_tp), 90, cid=f"{vista}:est:arriba")
        nt = trabas_por_nivel(p)
        tramos = self.tramos_estribos(pos)
        txts = []
        for k, (a, b, sep) in enumerate(tramos):
            cant = (b - a + 1) if k == 0 else (b - a)
            se = self._num_cota(sep)
            txt = f"{cant}-{c['m_est']} @{se}\\P{cant * nt}-{c['m_tra']} @{se}"
            if k > 0 and b - a == 1:
                txt = None          # un solo espacio suelto: se acota con su medida
            txts.append(txt)
        mods = (self.p.get("cotas_mod") or {})
        vis = [(mods.get(f"{vista}:est:tramo{k + 1}") or {}).get("texto") or t or
               self._num_cota(abs(pos[b] - pos[a])) for k, ((a, b, _s), t) in enumerate(zip(tramos, txts))]
        # los textos que no caben en su tramo van en una segunda columna, a la altura de su tramo
        # (así no se alejan de lo que acotan ni tapan el texto del tramo largo)
        h_, _g = self._cota_txt()
        no_caben = [k for k, ((a, b, _s), t) in enumerate(zip(tramos, vis))
                    if (self._ancho_txt(t) + 2.5) * S > abs(y(pos[b]) - y(pos[a]))]
        ubic = [None] * len(tramos)
        if no_caben:
            sub = self._repartir_textos([(y(pos[tramos[k][0]]), y(pos[tramos[k][1]])) for k in no_caben],
                                        [vis[k] for k in no_caben])
            for j, k in enumerate(no_caben):
                a, b, _s = tramos[k]
                ubic[k] = sub[j] if sub[j] is not None else (y(pos[a]) + y(pos[b])) / 2
        for k, (a, b, sep) in enumerate(tramos):
            self.cota((xl0, y(pos[a])), (xl0, y(pos[b])), (xcota, y(pos[a])), 90, texto=txts[k],
                      cid=f"{vista}:est:tramo{k + 1}", pos_txt=ubic[k], opuesto=k in no_caben)
            self.cotas_info[f"{vista}:est:tramo{k + 1}"]["tramo"] = (a, b, sep)
        if len(pos) == 1:
            self.cota((xl0, y(pos[0])), (xl0, y_tz), (xcota + 5 * S, y(pos[0])), 90, cid=f"{vista}:est:abajo")
        else:
            self.cota((xl0, y(pos[-1])), (xl0, y_tz), (xcota + 5 * S, y(pos[-1])), 90, cid=f"{vista}:est:abajo")

    def _v_aa_arm(self, p, c):
        self._seccion_armadura(p, c, "AA_ARM", p["Lfy"], c["ped_pos"], p["ped_y"], "NUM",
                               p["db_y"], c["m_y"], p["n_x"], p["s_x"], p["db_x"], c["m_x"], p["Lfy"], True)

    def _v_bb_arm(self, p, c):
        self._seccion_armadura(p, c, "BB_ARM", p["Lfx"], c.get("ped_pos_x", [0.0]), p["ped_x"], "LETRA",
                               p["db_x"], c["m_x"], p["n_y"], p["s_y"], p["db_y"], c["m_y"], p["Lfx"], False)

    # ---- sección C-C ------------------------------------------------------
    def _v_cc(self, p, c):
        self._empezar("CC", p)
        S = self._esc
        a, b = p["ped_y"] * K, p["ped_x"] * K
        re_ = p["rec_ped"] * K
        de = p["db_est"]
        cp = c["c_ped"] * K
        dbp = p["db_ped"]
        self._t("ped_x", "ped_y")
        self.rect(-a / 2, -b / 2, a / 2, b / 2, L_FUND)
        self._t("db_est", "rec_ped", "gancho_est", "n_est", "s_est")
        # estribo
        xa, ya = a / 2 - re_ - de / 2, b / 2 - re_ - de / 2
        self.rect(-xa, -ya, xa, ya, L_FIERRO, color=3)
        g = p["gancho_est"] * K * 0.6
        self.ln((-xa, ya), (-xa + g * 0.7, ya - g * 0.7), L_FIERRO, color=3)
        self.ln((-xa + 25, ya), (-xa + 25 + g * 0.7, ya - g * 0.7), L_FIERRO, color=3)
        # barras longitudinales
        self._t("db_ped", "n_cara", "n_cara_b", "rec_ped")
        n = int(p["n_cara"])
        nb = int(p.get("n_cara_b") or 0) or n
        xx = [-(a / 2 - cp) + i * (a - 2 * cp) / (n - 1) for i in range(n)]
        yy = [-(b / 2 - cp) + i * (b - 2 * cp) / (nb - 1) for i in range(nb)]
        pos = set()
        for x in xx:
            pos.add((round(x, 3), round(yy[0], 3)))
            pos.add((round(x, 3), round(yy[-1], 3)))
        for y in yy:
            pos.add((round(xx[0], 3), round(y, 3)))
            pos.add((round(xx[-1], 3), round(y, 3)))
        for (x, y) in pos:
            self.punto(x, y, dbp)
        self.elementos["CC"] = {
            "barras": {"x": list(xx), "y": -b / 2, "marca": c["m_ped"], "eje": "x"},
            "barras_v": {"y": list(yy), "x": -a / 2, "marca": c["m_ped"], "eje": "y"},
        }
        # trabas (1002): una por dirección y barra intermedia, gancho alrededor de la barra
        trabas = []
        rt = dbp / 2 + de / 2
        self._t("n_trabas", "n_trabas_b", "db_est", "s_est")

        def elegir(cuantas, total):
            inter = list(range(1, total - 1))
            cuantas = min(cuantas, len(inter))
            if cuantas <= 0:
                return []
            if cuantas >= len(inter):
                return inter
            return sorted({inter[int(round((i + 1) * (len(inter) + 1) / (cuantas + 1))) - 1]
                           for i in range(cuantas)})
        nta = int(p["n_trabas"])
        ntb = nta if int(p.get("n_trabas_b", -1)) < 0 else int(p["n_trabas_b"])
        sel_x, sel_y = elegir(nta, n), elegir(ntb, nb)
        for k in sel_x:
            if True:
                x = xx[k]
                xt = x + rt
                self.pl([(xt, yy[0]), (xt, yy[-1])], L_FIERRO, color=3)
                self._arco(x, yy[-1], rt, 0, 180)
                self.pl([(x - rt, yy[-1]), (x - rt, yy[-1] - 2.2 * S)], L_FIERRO, color=3)
                self._arco(x, yy[0], rt, 180, 360)
                self.pl([(x - rt, yy[0]), (x - rt + 1.5 * S, yy[0] + 1.5 * S)], L_FIERRO, color=3)
                trabas.append((xt, yy[0] + 0.62 * (yy[-1] - yy[0])))
        for k in sel_y:
            if True:
                y = yy[k]
                yt_ = y - rt
                self.pl([(xx[0], yt_), (xx[-1], yt_)], L_FIERRO, color=3)
                self._arco(xx[0], y, rt, 90, 270)
                self.pl([(xx[0], y + rt), (xx[0] + 2.2 * S, y + rt)], L_FIERRO, color=3)
                self._arco(xx[-1], y, rt, 270, 90)
                self.pl([(xx[-1], y + rt), (xx[-1] - 1.5 * S, y + rt - 1.5 * S)], L_FIERRO, color=3)
                trabas.append((xx[0] + 0.78 * (xx[-1] - xx[0]), yt_))
        # ejes
        self._t()
        self.ln((-a / 2 - 20 * S, 0), (a / 2 + 24 * S, 0), L_EJE)
        self.ln((0, -b / 2 - 10 * S), (0, b / 2 + 27 * S), L_EJE)
        self.eje(0, b / 2 + 41 * S, "LETRA", S)
        self.eje(0, b / 2 + 27 * S, "NUM", S)
        # cotas
        self._t("db_ped", "n_cara", "rec_ped", "db_est")
        sep = "."
        if ESTILO_COTA in self.doc.dimstyles and self.doc.dimstyles.get(ESTILO_COTA).dxf.get("dimdsep", 46) == 44:
            sep = ","
        if p.get("cc_cota_rec", "").startswith("Recubrimiento"):
            # cadena: recubrimiento libre (cara exterior del estribo) | barras U.E. | recubrimiento
            self.cadena_h([-a / 2, -a / 2 + re_, a / 2 - re_, a / 2], -b / 2, -b / 2 - 5 * S,
                          textos=[None, f"{n}-{c['m_ped']} U.E.", None])
            self.cadena_v([-b / 2, -b / 2 + re_, b / 2 - re_, b / 2], -a / 2, -a / 2 - 6 * S,
                          textos=[None, f"{nb}-{c['m_ped']} U.E.", None])
        else:
            ue_a = fmt_cm(c["ue_ped_y"]).replace(",", sep)
            ue_b = fmt_cm(c["ue_ped_x"]).replace(",", sep)
            self.cadena_h([-a / 2, xx[0], xx[-1], a / 2], -b / 2, -b / 2 - 5 * S,
                          textos=[None, f"{n}-{c['m_ped']} U.E.= {ue_a}", None])
            self.cadena_v([-b / 2, yy[0], yy[-1], b / 2], -a / 2, -a / 2 - 6 * S,
                          textos=[None, f"{nb}-{c['m_ped']} U.E.= {ue_b}", None])
        # rótulos
        self._t("n_est", "db_est", "s_est")
        self.rotulo([(-xa * 0.15, ya), (-xa * 0.6, b / 2 + 14 * S), (-a / 2 - 10 * S, b / 2 + 14 * S)],
                    f"{int(p['n_est'])}-{c['m_est']}-%%C{int(p['db_est'])}@{self._num_cota(p['s_est'])}", 2.5, lado=1)
        self._t("n_trabas", "db_est", "s_est")
        if trabas:
            izq = DT.es_dt(p)              # pedestal alto y angosto: el rótulo va a la izquierda (no tapa tablas)
            org = (-a / 2 - 12 * S, b / 2 + 4 * S) if izq else (a / 2 + 12 * S, b / 2 + 4 * S)
            for t in trabas:
                self.pl([t, org], L_TXT)
                self.flecha(t, org)
            self.pl([org, (org[0] + (-1 if izq else 1), org[1])], L_TXT)
            self.rotulo([trabas[0], org, (org[0] + (-0.1 if izq else 0.1), org[1])],
                        f"{c['m_tra']}-%%C{int(p['db_est'])}@{self._num_cota(p['s_est'])}\\PALTERNAR POSICIÓN DE\\PGANCHOS EN ALTURA", 2.5,
                        lado=-1 if izq else 1)

    # ---- esquema ----------------------------------------------------------
    def _v_esquema(self, p, c, _forzar=None):
        """esquema de distribución: grilla de ejes (columnas) × filas con distancias independientes entre
        cada par, fundaciones que se dibujan o no, y nombre de nodo por pedestal (tabla esq_fund)."""
        self._empezar("ESQUEMA", p)
        Ly, Lx = p["Lfy"] * K, p["Lfx"] * K
        px, py = p["ped_x"] * K, p["ped_y"] * K
        xs_e, ys_f = esquema_grilla(p)
        S = self._esc
        ejes_x, filas_y = [x * K for x in xs_e], [y * K for y in ys_f]
        ne, nf = len(ejes_x), len(filas_y)
        se_ = self.esc_eff["ESQUEMA"]

        def legible(mm_modelo):               # cotas de menos de ~5 mm en papel no se leen: se omiten
            return abs(mm_modelo) / se_ / self._f_obj >= 5.0
        funds = [f for f in esquema_fundaciones(p) if f[3]]
        ys_ped = [y * K for y in c["ped_pos"]]
        tags_e = ("seps_ejes", "sep_ejes", "n_ejes")
        tags_f = ("seps_filas", "sep_patas", "n_filas")
        for e, r, nodos, _d in funds:
            xe, yz = ejes_x[e - 1], filas_y[r - 1]
            self._t("Lfx", "Lfy", "n_filas", "n_ejes")
            self.rect(xe - Ly / 2, yz - Lx / 2, xe + Ly / 2, yz + Lx / 2, L_FUND)
            self.ln((xe - Ly / 2 - 4 * S, yz), (xe + Ly / 2 + 4 * S, yz), L_EJE)
            xs_pf = [x * K for x in c.get("ped_pos_x", [0.0])][::-1]       # filas de pedestales, de arriba abajo
            pedes = [(yp, xq) for xq in xs_pf for yp in ys_ped]
            for j, (yp, xq) in enumerate(pedes):
                xp, yq = xe + yp, yz + xq
                self._t("ped_x", "ped_y", "n_ped", "n_ped_x")
                self.rect(xp - py / 2, yq - px / 2, xp + py / 2, yq + px / 2, L_EST)
                self.ln((xp, yq - px / 2 - 2 * S), (xp, yq + px / 2 + 2 * S), L_EJE)
                self._t("pernos_disp", "perno_sep", "PERF")
                for (u, v) in pernos_xy(p, yp / K, (yz + xq) / K):
                    self.circ(xp + u * K, yq + v * K, max(p["PERF"] / 2, 0.35 * S), L_EST, color=1)
                # rótulo de nodo (pata)
                if j < len(nodos) and nodos[j]:
                    sx = -1 if yp < -1e-6 else 1
                    if len(xs_pf) > 1:
                        sy = 1 if xq > 1e-6 else -1
                    else:
                        sy = 1 if (r - 1) < nf / 2.0 else -1
                    yz_n = yq
                    self._t("esq_fund", "nodos_ejes", "nodos_izq", "nodos_der")
                    p1 = (xp + sx * (py / 2 + 2.5 * S), yz_n + sy * (px / 2 + 9 * S))
                    p2 = (p1[0] + sx * 3 * S, p1[1])
                    self.rotulo([(xp, yz_n), p1, p2], nodos[j], 2.5, color=7, lado=sx)
        # ejes verticales, cotas de cada eje
        for e, xe in enumerate(ejes_x, start=1):
            filas_e = sorted({r for ee, r, _n, _d in funds if ee == e})
            if not filas_e:
                continue
            ys_e = [filas_y[r - 1] for r in filas_e]
            self._t(*tags_e)
            self.ln((xe, min(ys_e) - Lx / 2 - 12 * S), (xe, max(ys_e) + Lx / 2 + 10 * S), L_EJE)
            # cotas de patas (arriba de la fila superior)
            y_top = max(ys_e)
            yt = y_top + Lx / 2
            self._t("dist_ped", "ped_y", "n_ped")
            if len(ys_ped) > 1:
                tramos = [xe + ys_ped[0], xe, xe + ys_ped[-1]] if len(ys_ped) == 2 else [xe + y for y in ys_ped]
                if all(legible(b_ - a_) for a_, b_ in zip(tramos, tramos[1:])):
                    self.cadena_h(tramos, y_top, yt + 5 * S)
                if legible(ys_ped[-1] - ys_ped[0]):
                    self.cota((xe + ys_ped[0], y_top), (xe + ys_ped[-1], y_top), (xe + ys_ped[0], yt + 10 * S))
            self._t("Lfy")
            self.cota((xe - Ly / 2, yt), (xe + Ly / 2, yt), (xe - Ly / 2, yt + 15 * S))
            # cotas verticales: filas (distancias independientes) y largo de zapatas
            sx = 1 if (e == ne and ne > 1) else -1
            x0 = xe + sx * Ly / 2
            xv = xe + sx * (Ly / 2 + 6 * S)
            gap = 5 * S if sx < 0 else 8 * S       # a la derecha el texto queda hacia el dibujo: más aire
            if len(ys_e) > 1:
                if nf == 2 and len(ys_e) == 2 and legible((ys_e[1] - ys_e[0]) / 2):
                    self._t(*tags_f)
                    self.cadena_v([ys_e[0], 0.0, ys_e[1]], x0, xv)
                pares = list(zip(filas_e, filas_e[1:]))
                for (ra, rb) in pares:
                    ya, yb_ = filas_y[ra - 1], filas_y[rb - 1]
                    self._t(*tags_f)
                    if rb == ra + 1:
                        self.cota((x0, yb_), (x0, ya), (xv + sx * gap, yb_), 90, cid=f"ESQUEMA:filas:{ra - 1}:{e}")
                    else:
                        self.cota((x0, yb_), (x0, ya), (xv + sx * gap, yb_), 90)
            self._t("Lfx")
            for yz in ys_e:
                if legible(Lx):
                    self.cadena_v([yz - Lx / 2, yz + Lx / 2], x0, xv + sx * 2 * gap)
        # eje horizontal central y cadena de distancias entre ejes (cada tramo editable por separado)
        self._t()
        self.ln((ejes_x[0] - Ly / 2 - 8 * S, 0), (ejes_x[-1] + Ly / 2 + 8 * S, 0), L_EJE)
        yb = min(filas_y) - Lx / 2
        if ne > 1:
            self._t(*tags_e)
            for i in range(ne - 1):
                self.cota((ejes_x[i], yb), (ejes_x[i + 1], yb), (ejes_x[i], yb - 10 * S), 0, cid=f"ESQUEMA:ejes:{i}")
        self._t()

    def resolver_esquema(self, p, cid, valor):
        """distancia entre dos ejes (o dos filas) del esquema: cambia sólo ese tramo."""
        partes = cid.split(":")
        i = int(partes[2])
        if partes[1] == "ejes":
            n = max(int(p.get("n_ejes", 2) or 1), 1) - 1
            vals = _lista_cm(p.get("seps_ejes"), n, p.get("sep_ejes", 1720.0))
            clave = "seps_ejes"
        else:
            n = max(int(p.get("n_filas", 2) or 1), 1) - 1
            vals = _lista_cm(p.get("seps_filas"), n, p.get("sep_patas", 200.0))
            clave = "seps_filas"
        if not (0 <= i < len(vals)):
            return None
        vals[i] = float(valor)
        return {clave: ";".join(fmt_cm(v).replace(",", ".") for v in vals)}

    # ------------------------------------------------------------ viewports
    def _extension_vista(self, key):
        ents = [e for e in (self.creados.get(key) or []) if e.is_alive]
        # los símbolos de relleno/hormigón traen geometría oculta desplazada: no cuentan
        excl = {self.P[k].dxf.name for k in ("s_relleno", "s_horm", "s_emp") if self.P.get(k) is not None}
        excl |= set(self.SIMB_MAT.values())
        ents = [e for e in ents if not (e.dxftype() == "INSERT" and e.dxf.name in excl)]
        if not ents:
            return None
        textos = [e for e in ents if e.dxftype() == "MTEXT"]
        b = bbox.extents([e for e in ents if e.dxftype() not in ("MTEXT", "MULTILEADER")], fast=True)
        for e in ents:              # rótulos: sus puntos y la caja aproximada del texto
            if e.dxftype() == "MULTILEADER":
                for pt in _caja_rotulo(e):
                    b.extend([pt])
        for t in textos:
            for pt in _caja_mtext(t):
                b.extend([pt])
        return b if b.has_data else None

    def _ajustar_viewports(self, p):
        for key, vp in self.vp.items():
            b = self._extension_vista(key)
            if b is None:
                continue
            esc = self.esc_eff.get(key, float(p[VISTAS[key][2]]))
            vp.dxf.view_target_point = (0, 0, 0)
            vp.dxf.view_direction_vector = (0, 0, 1)
            vp.dxf.view_center_point = (b.center.x, b.center.y)
            vp.dxf.view_height = vp.dxf.height * esc

    # --------------------------------------------------------------- papel
    def _ps_reg(self, e):
        self.creados_ps.append(e)
        if self._tag:
            self.tags[e.dxf.handle] = self._tag
        return e

    def _ps_txt(self, txt, x, y, h=2.5, adj=5, color=None, ancho=None, estilo="ROMANS"):
        at = {"layer": L_TABLA, "char_height": h, "style": estilo}
        if color is not None:
            at["color"] = color
        if ancho:
            at["width"] = ancho
        m = self.ps.add_mtext(txt, dxfattribs=at)
        m.set_location(insert=(x, y), attachment_point=adj)
        return self._ps_reg(m)

    def _ps_ln(self, x0, y0, x1, y1, color=None):
        at = {"layer": L_TABLA}
        if color is not None:
            at["color"] = color
        return self._ps_reg(self.ps.add_line((x0, y0), (x1, y1), dxfattribs=at))

    def _tabla(self, ox, oy, xs, ys, celdas, titulo=None, horizontales=None, verticales=None):
        """xs, ys: coordenadas locales (ys negativas hacia abajo). celdas: (col0,col1,fila0,fila1,texto,h)."""
        x0, x1 = xs[0], xs[-1]
        for y in (horizontales if horizontales is not None else [(y, x0, x1) for y in ys]):
            yy, a, b = y
            self._ps_ln(ox + a, oy + yy, ox + b, oy + yy)
        for v in (verticales if verticales is not None else [(x, ys[0], ys[-1]) for x in xs]):
            xx, a, b = v
            self._ps_ln(ox + xx, oy + a, ox + xx, oy + b)
        for (c0, c1, f0, f1, txt, h) in celdas:
            cx = ox + (xs[c0] + xs[c1]) / 2
            cy = oy + (ys[f0] + ys[f1]) / 2
            self._ps_txt(txt, cx, cy, h, adj=5, ancho=abs(xs[c1] - xs[c0]) - 1.0)

    def _papel(self, p, c):
        doc = self.doc
        db = doc.entitydb
        est = p["estructura"]
        # títulos de vistas (escala efectiva según la hoja)
        for key, (_pc, h, esc_k) in VISTAS.items():
            m = db.get(self.h_titulos.get(key) or h)
            if m is None:
                continue
            if key not in self._titulo_orig:
                self._titulo_orig[key] = m.text
            t = self._titulo_orig[key]
            se = int(round(self.esc_eff.get(key, p[esc_k])))
            propio = str((p.get("titulos_mod") or {}).get(key) or "").strip()
            if DT.es_dt(p):
                t = DT.titulo(key, p, se)
            else:
                t = re.sub(r"ESCALA 1:\d+", f"ESCALA 1:{se}", t)
                t = re.sub(r"MARCO DE BARRA 220 ?kV", est, t)
                if getattr(self, "_est_prev", None) and self._est_prev != est:
                    t = t.replace(self._est_prev, est)
            self.titulos_auto[key] = t
            if propio:                                   # la escala escrita a mano sigue a la de la vista
                propio = re.sub(r"ESCALA 1:\d+", f"ESCALA 1:{se}", propio)
            m.text = titulo_formateado(propio) if propio else t
            self.tags[m.dxf.handle] = ("@titulo", key, "estructura", esc_k)
        self._est_prev = est
        # notas y referencias
        n = db.get(self.h_notas)
        if n is not None:
            n.text = mtext_notas(p["notas"])
            if p.get("notas_juntas") and not DT.es_dt(p):
                n.text += "\\P" + mtext_notas(p["notas_juntas"], "JUNTAS FRÍAS :")
            self.tags[n.dxf.handle] = ("@notas",)
        ref = db.get(self.h_refs)
        if ref is not None:
            cuerpo = "\\P\\P".join(f"{r[0]}^I{r[1]}" for r in p["referencias"] if any(x.strip() for x in r))
            ref.text = ("{\\H1.54x;\\C4;REFERENCIAS :\\P\\H0.64936x;\\C44;\\P\\H0.87999x;\\C256;" + cuerpo + "}")
            self.tags[ref.dxf.handle] = ("@referencias",)
        # viñeta
        for ins in self.formato_orig:
            if not ins.is_alive:
                continue
            nm = ins.dxf.name.upper()
            if nm == "T-F-A0":
                self._vineta_transelec(ins, p)
            else:
                self._vineta_hmv(ins, p)
            self._aplicar_overrides(ins, ins.dxf.name)
            self.tags[ins.dxf.handle] = ("@vineta",)
        if p["formato"].startswith("Genérico"):
            self._tag = ("@vineta",)
            self._vineta_generica(p)
            self._tag = ()
        elif p["vineta_extra"]:
            self._tag = ("@vineta",)
            self._datos_adicionales(p)
            self._tag = ()
        # tablas
        self._tablas(p, c)
        for key, vp in self.vp.items():
            self.tags[vp.dxf.handle] = ("@vista", key)
        # aviso cantidades
        for e in self.ps.query("MTEXT"):
            if "CANTIDADES DE OBRA CORRESPONDEN" in e.text:
                e.text = "" if DT.es_dt(p) else "* CANTIDADES DE OBRA CORRESPONDEN A UNA FUNDACIÓN "
        # desconectador: notas bajo la última tabla (más chicas, son muchas) y sin rosa de los vientos
        n = db.get(self.h_notas)
        if n is not None:
            if "notas" not in self._papel_orig:
                self._papel_orig["notas"] = (tuple(n.dxf.insert), n.dxf.char_height, n.dxf.get("width", 0.0))
            ins, ch, an = self._papel_orig["notas"]
            if DT.es_dt(p) and self.tablas_spec:
                ult = self.tablas_spec[-1]
                y_fin = ult["origen"][1] - sum(ult["altos"]) - 8.0
                x0 = min(t["origen"][0] for t in self.tablas_spec)
                x1 = max(t["origen"][0] + sum(t["anchos"]) for t in self.tablas_spec)
                n.dxf.insert = (x0, min(ins[1], y_fin), 0)
                n.dxf.char_height = 1.1
                n.dxf.width = x1 - x0
                # notas de juntas frías: bloque aparte, a la izquierda de la tabla N°2
                if p.get("notas_juntas"):
                    t2 = next((t for t in self.tablas_spec if t["id"] == "T2"), None)
                    if t2 is not None:
                        self._tag = ("@notas",)
                        self._ps_txt(mtext_notas(p["notas_juntas"], "JUNTAS FRÍAS :"), t2["origen"][0] - 118.0,
                                     t2["origen"][1], h=1.2, adj=1, ancho=108.0,
                                     estilo=n.dxf.get("style", "ROMANS"))
                        self._tag = ()
            else:
                n.dxf.insert = ins
                n.dxf.char_height = ch
                n.dxf.width = an
        for e in self.norte:
            try:
                e.dxf.invisible = 1 if DT.es_dt(p) else 0
            except Exception:
                pass

    # ---- viñetas ----------------------------------------------------------
    @staticmethod
    def _rellenar(txt, p):
        try:
            return str(txt).format(**{k: v for k, v in p.items() if not isinstance(v, (list, dict))})
        except (KeyError, IndexError, ValueError):
            return str(txt)

    def _vineta_hmv(self, ins, p):
        filas = ["A", "B", "C", "D", "E", "F", "G", "0"]
        pers = "ABCDEFGH"
        vals = {}
        for i, l in enumerate(filas):
            vals[l] = ""
            vals[f"FECHA_{l}"] = ""
            vals[f"MODIFICACIONES_{l}"] = ""
            vals[f"DIB_{pers[i]}."] = ""
            vals[f"REV_{pers[i]}."] = ""
            vals[f"APR_{pers[i]}."] = ""
        revs = p["revisiones"]
        if len(revs) > len(filas):
            self.c["avisos"].append(f"La viñeta HMV admite {len(filas)} revisiones; se muestran las últimas.")
            revs = revs[-len(filas):]
        for i, r in enumerate(revs):
            r = (list(r) + [""] * 6)[:6]
            l = filas[i]
            vals[l], vals[f"FECHA_{l}"], vals[f"MODIFICACIONES_{l}"] = r[0], r[1], r[2]
            vals[f"DIB_{pers[i]}."], vals[f"REV_{pers[i]}."], vals[f"APR_{pers[i]}."] = r[3], r[4], r[5]
        fecha = p["fecha"]
        vals["D_HMV"] = p["dibujo"]
        vals["DI_HMV"] = p["proyecto"]
        vals["R_HMV"] = p["reviso"]
        vals["F_HMV"] = (fecha[:6].replace("-", ".") + fecha[-2:]) if len(fecha) == 10 else fecha
        vals["M_HMV"] = p["rev"]
        vals["P_HMV"] = p["codigo"]
        for a in ins.attribs:
            if a.dxf.tag in vals:
                a.dxf.text = vals[a.dxf.tag]

    def _vineta_transelec(self, ins, p):
        vals = {"DESC-1": p["titulo1"], "DESC-2": p["titulo2"], "DESC-3": p.get("titulo3", ""),
                "DESC-4": p.get("titulo4", ""),
                "IIIIIII-AA-EE-TTTT-NNNN-LLLLLZ": p["codigo"], "RR": p["rev"],
                "DD/MM/AA": p["fecha_txt"]}
        n_ap = 0
        for a in ins.attribs:
            if a.dxf.tag in vals:
                a.dxf.text = vals[a.dxf.tag]
            elif a.dxf.tag == "N.APELLIDO":
                if n_ap == 0:
                    a.dxf.text = p["proyecto"]
                elif n_ap == 1:
                    a.dxf.text = p["reviso_cliente"]
                elif n_ap == 2:
                    a.dxf.text = p["aprobo_cliente"]
                n_ap += 1

    def _claves_attribs(self, ins, nombre):
        cont = {}
        out = []
        for a in ins.attribs:
            t = a.dxf.tag
            cont[t] = cont.get(t, 0) + 1
            out.append((f"{nombre}|{t}|{cont[t]}", a))
        return out

    def _aplicar_overrides(self, ins, nombre):
        ov = self.p.get("vineta_attr") or {}
        for clave, a in self._claves_attribs(ins, nombre):
            if clave in ov:
                a.dxf.text = self._rellenar(ov[clave], self.p)
        # textos sueltos dentro del bloque de formato del cliente
        if nombre.startswith("FORMATO_") and nombre in self.doc.blocks:
            orig = self._fmt_txt_orig.setdefault(nombre, {})
            for i, e in enumerate(t for t in self.doc.blocks[nombre] if t.dxftype() in ("TEXT", "MTEXT")):
                clave = f"{nombre}|#TEXTO|{i + 1}"
                actual = e.dxf.text if e.dxftype() == "TEXT" else e.text
                orig.setdefault(clave, actual)
                nuevo = self._rellenar(ov.get(clave, orig[clave]), self.p)
                if e.dxftype() == "TEXT":
                    e.dxf.text = nuevo
                else:
                    e.text = nuevo
            # atributos de bloques anidados (rótulos con ATTDEF dentro del formato)
            for j, ins2 in enumerate(self.doc.blocks[nombre].query("INSERT")):
                for clave, a in self._claves_attribs(ins2, f"{nombre}/{ins2.dxf.name}#{j + 1}"):
                    orig.setdefault(clave, a.dxf.text)
                    a.dxf.text = self._rellenar(ov.get(clave, orig[clave]), self.p)

    _fmt_txt_orig: dict = {}

    def atributos_formato(self):
        """[(clave, bloque, campo, valor)] de la viñeta activa (para la tabla del editor)."""
        filas = []
        p = self.p
        if p["formato"].startswith("Original"):
            inss = [i for i in self.formato_orig if i.is_alive]
        elif p["formato"].startswith("Personalizado"):
            inss = [i for i in self.creados_post if i.dxftype() == "INSERT"]
        else:
            inss = []
        for ins in inss:
            nombre = ins.dxf.name
            for clave, a in self._claves_attribs(ins, nombre):
                filas.append((clave, nombre, a.dxf.tag, a.dxf.text))
            if nombre.startswith("FORMATO_"):
                for i, e in enumerate(t for t in self.doc.blocks[nombre] if t.dxftype() in ("TEXT", "MTEXT")):
                    filas.append((f"{nombre}|#TEXTO|{i + 1}", nombre, f"texto {i + 1}",
                                  e.dxf.text if e.dxftype() == "TEXT" else e.plain_text()))
                for j, ins2 in enumerate(self.doc.blocks[nombre].query("INSERT")):
                    for clave, a in self._claves_attribs(ins2, f"{nombre}/{ins2.dxf.name}#{j + 1}"):
                        filas.append((clave, f"{nombre}/{ins2.dxf.name}", a.dxf.tag, a.dxf.text))
        return filas

    def _vineta_generica(self, p):
        """marco + viñeta + cuadro de revisiones dibujados en coordenadas A1 (se escalan con la hoja)."""
        at_g = {"layer": L_TABLA, "lineweight": 50}
        tag, self._tag = self._tag, ()
        self._ps_reg(self.ps.add_lwpolyline([(0, 0), (841, 0), (841, 594), (0, 594)], close=True,
                                            dxfattribs={"layer": L_TABLA}))
        self._ps_reg(self.ps.add_lwpolyline([(20, 10), (831, 10), (831, 584), (20, 584)], close=True,
                                            dxfattribs=at_g))
        self._tag = tag
        # campos (columna derecha)
        campos = [r for r in p["vineta_campos"] if any(str(x).strip() for x in r)]
        x0, x1, xm = 586.0, 831.0, 624.0
        hf = 4.6
        y = 10.0
        for et, val in reversed(campos):
            self._ps_ln(x0, y, x1, y)
            self._ps_txt(et, x0 + 1.0, y + hf / 2, 1.6, adj=4, color=8)
            self._ps_txt(self._rellenar(val, p), xm + 1.5, y + hf / 2, 2.0, adj=4, ancho=x1 - xm - 3)
            y += hf
        self._ps_ln(x0, y, x1, y)
        self._ps_ln(x0, 10, x0, y)
        self._ps_ln(xm, 10, xm, y)
        # cuadro de revisiones (izquierda), encabezado abajo
        anchos = [12, 22, 90, 25, 25, 27]
        xs = [380.0]
        for w in anchos:
            xs.append(xs[-1] + w)
        hr = 5.0
        yy = 10.0
        for j, t in enumerate(COLS_REV):
            self._ps_txt(t.upper(), (xs[j] + xs[j + 1]) / 2, yy + hr / 2, 1.8, adj=5, color=8)
        filas = 1
        for r in p["revisiones"]:
            yy += hr
            filas += 1
            r = (list(r) + [""] * 6)[:6]
            for j, v in enumerate(r):
                self._ps_txt(str(v), (xs[j] + xs[j + 1]) / 2 if j != 2 else xs[j] + 1.0, yy + hr / 2, 1.8,
                             adj=5 if j != 2 else 4, ancho=anchos[j] - 1)
        for k in range(filas + 1):
            self._ps_ln(xs[0], 10 + k * hr, xs[-1], 10 + k * hr)
        for x in xs:
            self._ps_ln(x, 10, x, 10 + filas * hr)
        if y > 80 or 10 + filas * hr > 80:
            self.c["avisos"].append("La viñeta genérica es alta: puede tapar las notas o referencias.")

    def _datos_adicionales(self, p):
        x0, x1, xm = 693.0, 838.0, 733.0
        hf = 5.0
        y = 62.5
        filas = [r for r in p["vineta_extra"] if any(str(x).strip() for x in r)]
        for et, val in filas:
            self._ps_ln(x0, y, x1, y)
            self._ps_txt(str(et), x0 + 1, y + hf / 2, 1.8, adj=4)
            self._ps_txt(self._rellenar(val, p), xm + 1.5, y + hf / 2, 2.0, adj=4, ancho=x1 - xm - 3)
            y += hf
        if filas:
            self._ps_ln(x0, y, x1, y)
            for x in (x0, xm, x1):
                self._ps_ln(x, 62.5, x, y)

    # ---- zonas clicables del papel ----------------------------------------
    def zonas_papel(self):
        """[(x0, y0, x1, y1, claves)] en coordenadas de papel actuales."""
        grupos = {}
        for e in list(self.ps) + self.creados_post:
            if not e.is_alive:
                continue
            k = self.tags.get(e.dxf.handle)
            if not k:
                continue
            if e.dxftype() == "INSERT" and e.dxf.name.upper() == "T-F-A0":
                f = self._f   # solo el rótulo inferior derecho del marco
                grupos.setdefault(k, []).append((577 * f, 0, 839 * f, 65 * f))
                continue
            if e.dxftype() == "VIEWPORT":
                c, w, h = e.dxf.center, e.dxf.width, e.dxf.height
                grupos.setdefault(k, []).append((c.x - w / 2, c.y - h / 2, c.x + w / 2, c.y + h / 2))
                continue
            try:
                b = bbox.extents([e], fast=True)
            except Exception:
                continue
            if b.has_data:
                grupos.setdefault(k, []).append((b.extmin.x, b.extmin.y, b.extmax.x, b.extmax.y))
        zonas = []
        for k, cajas in grupos.items():
            if k[0] == "@vista":
                zonas += [(*cj, k) for cj in cajas]
            else:
                zonas.append((min(c[0] for c in cajas), min(c[1] for c in cajas),
                              max(c[2] for c in cajas), max(c[3] for c in cajas), k))
        return zonas

    # ---- tablas (especificación con fórmulas + dibujo de respaldo) ---------
    def _tablas(self, p, c):
        if DT.es_dt(p):
            self.tablas_spec = DT.especificar_tablas(p, c, self.orig_tablas, sys.modules[__name__])
        else:
            self.tablas_spec = especificar_tablas(p, c, self.orig_tablas)
        mods = p.get("celdas_mod") or {}
        self.celdas_info = {}
        for t in self.tablas_spec:
            for (r, cc), cel in t["celdas"].items():
                k = f"{t['id']}:{r}:{cc}"
                self.celdas_info[k] = str(cel.get("v", ""))
                v = mods.get(k)
                if v is not None and str(v).strip() != "":
                    cel["v"] = str(v)                 # escrito a mano: queda como valor fijo (sin fórmula)
                    cel.pop("f", None)
                    try:
                        cel["n"] = float(str(v).replace(".", "").replace(",", ".")) if "," in str(v) else float(v)
                    except ValueError:
                        cel.pop("n", None)
            self._tag = ("@celdas", t["id"]) + tuple(x for x in t["tag"] if not str(x).startswith("@"))
            self._dibujar_tabla(t)
        self._tag = ()

    def _dibujar_tabla(self, t):
        """Respaldo visual de la tabla (líneas + MTEXT) marcado con XDATA HMV_TABLA=<id>.
        El LISP HMV_FINALIZAR lo borra y crea en su lugar la tabla real de AutoCAD con fórmulas."""
        ox, oy = t["origen"]
        xs = [0.0]
        for w in t["anchos"]:
            xs.append(xs[-1] + w)
        ys = [0.0]
        for h in t["altos"]:
            ys.append(ys[-1] - h)
        nf, nc = len(t["altos"]), len(t["anchos"])
        region = {}
        for (r0, c0, r1, c1) in t["combinadas"]:
            for r in range(r0, r1 + 1):
                for cc in range(c0, c1 + 1):
                    region[(r, cc)] = (r0, c0, r1, c1)
        segs = set()
        sin_borde = set(tuple(x) for x in t.get("sin_borde", []))
        for r in range(nf):
            for cc in range(nc):
                r0, c0, r1, c1 = region.get((r, cc), (r, cc, r, cc))
                if (r, cc) != (r0, c0):
                    continue
                x0, x1, y0, y1 = xs[c0], xs[c1 + 1], ys[r0], ys[r1 + 1]
                lados = {"arriba": (x0, y0, x1, y0), "abajo": (x0, y1, x1, y1),
                         "izq": (x0, y0, x0, y1), "der": (x1, y0, x1, y1)}
                for lado, sg in lados.items():
                    if (r0, c0, lado) in sin_borde:
                        continue
                    segs.add(tuple(round(v, 4) for v in sg))
        for (x0, y0, x1, y1) in sorted(segs):
            self._xd(self._ps_ln(ox + x0, oy + y0, ox + x1, oy + y1), t["id"])
        for (r, cc), cel in t["celdas"].items():
            txt = cel.get("v", "")
            if txt in ("", None):
                continue
            r0, c0, r1, c1 = region.get((r, cc), (r, cc, r, cc))
            cx = ox + (xs[c0] + xs[c1 + 1]) / 2
            cy = oy + (ys[r0] + ys[r1 + 1]) / 2
            m = self._ps_txt(txt, cx, cy, cel.get("h", 2.5), adj=5, ancho=abs(xs[c1 + 1] - xs[c0]) - 1.0,
                             estilo=t.get("estilo_texto", "ROMANS"))
            self._xd(m, t["id"])

    def _xd(self, e, ident):
        try:
            e.set_xdata(APPID_TABLA, [(1000, ident)])
        except Exception:
            pass
        return e

    # ------------------------------------------------------------- salida
    def guardar(self, ruta_dxf, normalizar=True, tablas_reales=None):
        """tablas_reales: escribe las tablas como ACAD_TABLE con fórmulas (FIELD AcExpr) que AutoCAD y
        Open CAD Studio recalculan; None = según el parámetro «tablas_dxf»."""
        os.makedirs(os.path.dirname(os.path.abspath(ruta_dxf)), exist_ok=True)
        try:                                   # los parámetros quedan dentro del archivo (abrirlo después es exacto)
            import importar_plano
            importar_plano.guardar_parametros(self.doc, getattr(self, "p", None) or {})
        except Exception:
            pass
        if normalizar:
            self.resumen_normas = normalizar_documento(self.doc)
        self.doc.audit()   # elimina objetos huérfanos de las entidades borradas
        # cada ATTRIB debe pertenecer a su bloque (ezdxf los deja con el dueño del espacio): sin esto el
        # conversor a DWG los suelta y se pierden los textos de los atributos
        for lay in [self.msp] + [l for l in self.doc.layouts if l.name != "Model"]:
            for ins in lay.query("INSERT"):
                for at in ins.attribs:
                    if at.dxf.get("owner") != ins.dxf.handle:
                        at.dxf.owner = ins.dxf.handle
        if tablas_reales is None:
            tablas_reales = str((getattr(self, "p", None) or {}).get("tablas_dxf", "Sí")).startswith("S")
        info = None
        if tablas_reales:
            import tablas_dxf
            info = tablas_dxf.preparar(self)
        try:
            self.doc.saveas(ruta_dxf)
            if info:
                import tablas_dxf
                self.tablas_escritas = tablas_dxf.escribir(ruta_dxf, info, ESTILO)
        finally:
            if info:
                import tablas_dxf
                tablas_dxf.restaurar(self, info)
        return ruta_dxf

    def exportar_lisp(self, ruta_dxf, ruta_dwg=None, ruta_pdf=None, hoja=None, salir=False, relativas=False):
        """genera <codigo>_finalizar.lsp/.scr para crear en AutoCAD las tablas reales con fórmulas,
        asignar el CTB, guardar el DWG y plotear el PDF."""
        import finalizar_autocad as fa
        base = os.path.splitext(os.path.abspath(ruta_dxf))[0]
        normas = cargar_normas()
        hoja = hoja or getattr(self, "papel_plot", "A0")
        lsp = fa.generar_lisp(self.tablas_spec, base + "_finalizar.lsp", layout=self.ps.name,
                              ctb=self.p.get("ctb") or normas.get("ctb", "GN-PLOT-HMV.ctb"),
                              estilo_texto=ESTILO, estilo_tabla=normas.get("estilo_tabla", "HMV-TABLA"),
                              capa=L_TABLA, ruta_dwg=ruta_dwg, ruta_pdf=ruta_pdf, hoja=hoja, appid=APPID_TABLA,
                              relativas=relativas)
        scr = fa.generar_scr(os.path.basename(lsp) if relativas else lsp, base + "_finalizar.scr", salir=salir)
        return lsp, scr

    def entidades_vista(self, vista):
        return [e for e in self.creados.get(vista, []) if e.is_alive]


# --------------------------------------------------------------------------
# TABLAS: especificación común para el respaldo (DXF/DWG) y la tabla real de AutoCAD
# --------------------------------------------------------------------------
FMT2 = '%lu2%pr2%ds44'            # decimal, 2 decimales, coma decimal (como el plano original)
FMT2M = '%lu2%pr2%ds44%th46'      # ídem con punto de miles
COL = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def _ref(r, cc):
    """referencia de celda de AutoCAD (fila 1 = primera fila de la tabla)."""
    return f"{COL[cc]}{r + 1}"


M3 = "m{\\H0.56x;\\S3^ ;}"   # m³ como en el plano original (superíndice apilado)


def especificar_tablas(p, c, origenes=None):
    origenes = origenes or {}
    tablas = []
    # ---------------- TABLA N°1 ----------------
    barras = c["barras"]
    anchos = [15.9, 18.5, 18.9, 17.8, 14.1, 15.7, 13.0, 13.0, 18.0, 16.5, 18.0]
    altos = [12.3, 30.0, 7.7, 8.0, 8.0] + [9.7] * len(barras) + [6.8]
    cel = {}
    comb = [(0, 0, 0, 10), (1, 0, 1, 10), (2, 0, 2, 10), (3, 0, 4, 0), (3, 1, 4, 1), (3, 2, 4, 2), (3, 3, 4, 3),
            (3, 4, 4, 4), (3, 5, 3, 7), (3, 8, 3, 9), (3, 10, 4, 10)]
    cel[(0, 0)] = dict(v="TABLA N°1\\PLISTADO DE ARMADURAS", h=3.0)
    cel[(2, 0)] = dict(v="LISTA DE BARRAS", h=3.0)
    for cc, t in enumerate(["ÍTEM", "Ø (mm)", "PESO\\P(kg/m)", "TIPO", "CANT."]):
        cel[(3, cc)] = dict(v=t, h=2.2 if cc == 0 else 2.5)
    cel[(3, 5)] = dict(v="DIMENSIONES (cm)")
    cel[(3, 8)] = dict(v="LONGITUD (m)")
    cel[(3, 10)] = dict(v="PESO\\PTOTAL\\P(kg)")
    for cc, t in zip(range(5, 10), ["a", "b", "c", "PARCIAL", "TOTAL"]):
        cel[(4, cc)] = dict(v=t)
    r_ini = 5
    for i, b in enumerate(barras):
        r = r_ini + i
        F, G, H, E, I, J, C = (_ref(r, k) for k in (5, 6, 7, 4, 8, 9, 2))
        if b["tipo"] == "O":
            f_parc = f"(({F}*2+{G}*2+{H}*2)/100)"
        elif b["tipo"] == "IG":
            f_parc = f"(({F}+{G}+{H})/100)"
        elif b["tipo"] == "L":                     # un solo gancho
            f_parc = f"(({F}+{G})/100)"
        elif b["tipo"] == "I":                     # recta
            f_parc = f"({F}/100)"
        else:
            f_parc = f"(({F}+2*{G})/100)"
        cel[(r, 0)] = dict(v=b["marca"])
        cel[(r, 1)] = dict(v=str(b["d"]))
        cel[(r, 2)] = dict(v=fmt(b["masa"], 3), n=b["masa"])
        cel[(r, 3)] = dict(v=b["tipo"])
        cel[(r, 4)] = dict(v=str(b["cant"]), f=f"({b['por']}*{b['veces']})")
        cel[(r, 5)] = dict(v=fmt_cm(b["a"]), n=b["a"])
        cel[(r, 6)] = dict(v=fmt_cm(b["b"]), n=b["b"])
        cel[(r, 7)] = dict(v=fmt_cm(b["c"]), n=b["c"])
        cel[(r, 8)] = dict(v=fmt(b["Lp"], 2), f=f_parc, fmt=FMT2)
        cel[(r, 9)] = dict(v=fmt(b["Lt"], 2, True), f=f"({E}*{I})", fmt=FMT2M)
        cel[(r, 10)] = dict(v=fmt(b["peso"], 2, True), f=f"({C}*{J})", fmt=FMT2M)
    r_tot = r_ini + len(barras)
    comb.append((r_tot, 0, r_tot, 8))
    cel[(r_tot, 9)] = dict(v="TOTAL")
    cel[(r_tot, 10)] = dict(v=fmt(c["acero"], 2, True),
                            f=f"(Sum({_ref(r_ini, 10)}:{_ref(r_tot - 1, 10)}))", fmt=FMT2M)
    tablas.append(dict(id="T1", tag=("@tabla1",), origen=origenes.get("1", (647.2, 579.4)), anchos=anchos,
                       altos=altos, celdas=cel, combinadas=comb, celda_total=_ref(r_tot, 10),
                       sin_borde=[(r_tot, 0, "izq"), (r_tot, 0, "abajo")]))
    # ---------------- TABLA N°2 ----------------
    nf = int(p["n_fund"]) or int(c.get("n_fund_esq") or 1)
    anchos = [78.0, 32.4, 32.5, 35.2]
    altos = [12.2, 15.6, 6.8, 6.8, 7.3, 6.8, 6.8, 6.8, 9.7, 9.6]
    cel = {(0, 0): dict(v="TABLA N°2\\PCANTIDADES DE OBRA", h=3.0),
           (1, 0): dict(v="TIPO"), (1, 1): dict(v="UNIDAD"), (1, 2): dict(v="CANTIDAD\\PPOR FUND"),
           (1, 3): dict(v=f"CANTIDAD TOTAL\\P({nf} FUND.)")}
    filas = [("VOL. HORMIGÓN (G35)", M3, c["v_horm"], c["f_horm"]),
             ("VOL. EMPLANTILLADO (G10)", M3, c["v_emp"], c["f_emp"]),
             ("ACERO", "kg", c["acero"], "@T1"),
             ("VOL. EXCAVACIÓN (MÁX)", M3, c["v_exc"], c.get("f_exc")),
             ("VOL. RELLENO (MÁX)", M3, c["v_rell"], c.get("f_rell")),
             ("VOL. GROUTING", "lt", c["v_grout"], c.get("f_grout")),
             ("PERNO DE ANCLAJE ASTM A193 GRADO B7", "UNIDAD", c["pernos"], c["f_pernos"])]
    for i, (t, u, v, f) in enumerate(filas):
        r = 2 + i
        cel[(r, 0)] = dict(v="\\pql;" + t, al="ML")
        cel[(r, 1)] = dict(v=u)
        cel[(r, 2)] = dict(v=fmt(v, 2, True), f=f, fmt=FMT2M, n=v)
        cel[(r, 3)] = dict(v=fmt(v * nf, 2, True), f=f"({_ref(r, 2)}*{nf})", fmt=FMT2M)
    comb = [(0, 0, 0, 3), (9, 0, 9, 3)]
    cel[(9, 0)] = dict(v=f"* CANTIDADES DE OBRA POR FUNDACIÓN Y TOTALES PARA {nf} FUNDACIONES.")
    tablas.append(dict(id="T2", tag=("n_fund", "placa", "sobreexc", "e_emp", "e_grout", "q_exc", "q_rell", "q_grout"),
                       origen=origenes.get("2", (638.0, 439.2)), anchos=anchos, altos=altos, celdas=cel,
                       combinadas=comb))
    # ---------------- TABLA N°3 ----------------
    heads = ["Ø", "P", "G", "Lr", "C", "Ldh", "L", "Lg", "Eg", "PERF"]
    vals = [fmt(p["perno_d"], 2), str(int(p["P"])), str(int(p["G"])), str(int(p["Lr"])), str(int(p["C"])),
            str(int(p["Ldh"])), str(int(p["L"])), str(int(p["Lg"])), fmt_cm(p["Eg"]), fmt_cm(p["PERF"])]
    n_ped = int(p["n_ped"]) * int(c.get("n_ped_x") or 1)     # pedestales por fundación (grilla X × Y)
    tag3 = ("perno_desc", "perno_d", "P", "G", "Lr", "C", "Ldh", "L", "Lg", "Eg", "PERF", "pernos_ped", "tabla3_estilo")
    if str(p.get("tabla3_estilo", "")).startswith("Compacta"):
        anchos = [40.0] + [18.5] * 10 + [44.7]
        altos = [15.0, 7.5, 7.5, 10.0]
        cel = {(0, 0): dict(v="TABLA N°3\\PPARÁMETROS GEOMÉTRICOS PERNOS DE ANCLAJE", h=3.0),
               (1, 0): dict(v="PERNO"), (1, 11): dict(v="CANTIDAD DE\\PPERNOS POR\\PFUNDACIÓN", h=2.2),
               (3, 0): dict(v=p["perno_desc"]),
               (3, 11): dict(v=str(c["pernos"]), f=f"({int(p['pernos_ped'])}*{n_ped})")}
        for j, (h, v) in enumerate(zip(heads, vals)):
            cel[(1, 1 + j)] = dict(v=h)
            cel[(2, 1 + j)] = dict(v="(mm)")
            cel[(3, 1 + j)] = dict(v=v)
        comb = [(0, 0, 0, 11), (1, 0, 2, 0), (1, 11, 2, 11)]
    else:
        anchos = [53.3, 24.5, 13.5, 13.1, 13.3, 12.9, 13.2, 13.0, 13.3, 14.3, 13.0, 13.5, 27.8, 31.0]
        altos = [13.0, 6.3, 11.5, 11.6]
        cel = {(0, 0): dict(v="TABLA N°3\\PPARÁMETROS GEOMÉTRICOS PERNOS DE ANCLAJE", h=3.0),
               (1, 0): dict(v="DESCRIPCIÓN"), (1, 1): dict(v="PERNO"),
               (1, 12): dict(v="CANTIDAD DE\\PPERNOS POR\\PPEDESTAL", h=2.2),
               (1, 13): dict(v="CANTIDAD DE\\PPERNOS TOTAL", h=2.2),
               (3, 0): dict(v=f"PERNOS FUNDACIÓN\\P{p['estructura']}", h=2.2), (3, 1): dict(v=p["perno_desc"]),
               (3, 12): dict(v=str(int(p["pernos_ped"]))),
               (3, 13): dict(v=str(c["pernos"]), f=f"({_ref(3, 12)}*{n_ped})")}
        for j, (h, v) in enumerate(zip(heads, vals)):
            cel[(1, 2 + j)] = dict(v=h)
            cel[(2, 2 + j)] = dict(v="(mm)")
            cel[(3, 2 + j)] = dict(v=v)
        comb = [(0, 0, 0, 13), (1, 0, 2, 0), (1, 1, 2, 1), (1, 12, 2, 12), (1, 13, 2, 13)]
    tablas.append(dict(id="T3", tag=tag3, origen=origenes.get("3", (556.9, 344.4)), anchos=anchos, altos=altos,
                       celdas=cel, combinadas=comb))
    return tablas


def normalizar_documento(doc, normas=None):
    """Unifica estilos de texto y cota según normas_hmv.json y purga estilos/capas sin uso.
    Devuelve un resumen de lo hecho."""
    normas = normas or cargar_normas()
    cfg = normas.get("normalizar") or {}
    perm_txt = set(cfg.get("estilos_texto_permitidos") or [])
    reemplazo_txt = cfg.get("estilo_texto_reemplazo") or normas.get("estilo_texto_altura_libre") or "Standard"
    perm_cota = set(cfg.get("estilos_cota_permitidos") or [])
    est_cota = normas.get("estilo_cota") or "Standard"
    res = {"textos": 0, "cotas": 0, "estilos_texto_purgados": [], "estilos_cota_purgados": [], "capas_purgadas": []}
    if reemplazo_txt not in doc.styles or (est_cota not in doc.dimstyles):
        return res
    res["bloques_purgados"] = []
    if cfg.get("purgar_bloques_portapapeles", True):
        # bloques "A$C..." que AutoCAD crea al pegar desde el portapapeles y que nadie inserta
        ref = {i.dxf.name.upper() for lay in list(doc.layouts) + list(doc.blocks) for i in lay.query("INSERT")}
        for b in list(doc.blocks):
            if b.name.upper().startswith("A$C") and b.name.upper() not in ref:
                try:
                    doc.blocks.delete_block(b.name, safe=False)
                    res["bloques_purgados"].append(b.name)
                except Exception:
                    pass
    import fnmatch
    excl = [x.upper() for x in (cfg.get("bloques_excluidos") or [])]
    def _excluido(nombre):
        return any(fnmatch.fnmatchcase(nombre.upper(), pat) for pat in excl)
    contenedores = list(doc.layouts) + [b for b in doc.blocks if not b.name.upper().startswith(("*D", "*T"))]
    usados_txt, usados_dim, usadas_capas = set(), set(), set()
    for lay in contenedores:
        for e in lay:
            usadas_capas.add(e.dxf.get("layer", "0"))
            t = e.dxftype()
            if t in ("MTEXT", "TEXT", "ATTRIB", "ATTDEF"):
                st = e.dxf.get("style", "Standard")
                if perm_txt and st not in perm_txt and not _excluido(lay.name):
                    e.dxf.style = reemplazo_txt
                    res["textos"] += 1
                usados_txt.add(e.dxf.get("style", "Standard"))
            elif t == "DIMENSION":
                if perm_cota and e.dxf.dimstyle not in perm_cota and not _excluido(lay.name):
                    e.dxf.dimstyle = est_cota
                    res["cotas"] += 1
                usados_dim.add(e.dxf.dimstyle)
            for a in getattr(e, "attribs", []) or []:
                usados_txt.add(a.dxf.get("style", "Standard"))
            if t == "MULTILEADER":       # su estilo de texto va por handle (entidad y contexto)
                for h in (e.dxf.get("text_style_handle"),
                          getattr(getattr(getattr(e, "context", None), "mtext", None), "style_handle", None)):
                    st = doc.entitydb.get(h) if h else None
                    if st is not None and st.dxftype() == "STYLE":
                        usados_txt.add(st.dxf.name)
    # entidades dentro de bloques de cota/tabla también usan estilos
    for b in doc.blocks:
        if b.name.upper().startswith(("*D", "*T")):
            for e in b:
                usadas_capas.add(e.dxf.get("layer", "0"))
                if e.dxftype() in ("MTEXT", "TEXT"):
                    usados_txt.add(e.dxf.get("style", "Standard"))
    for ds in doc.dimstyles:
        if ds.dxf.name in usados_dim or ds.dxf.name in perm_cota:
            usados_txt.add(ds.dxf.get("dimtxsty", "Standard"))
    for obj in doc.objects:
        if obj.dxftype() not in ("MLEADERSTYLE", "TABLESTYLE", "MLINESTYLE"):
            continue
        hs = []
        try:
            if obj.dxf.hasattr("text_style_handle"):
                hs.append(obj.dxf.text_style_handle)
        except Exception:
            pass
        # objetos sin clase específica en ezdxf: buscar códigos 7 (nombre) y 340 (handle) en las tags crudas
        tags = getattr(obj, "xtags", None)
        try:
            for sub in (tags.subclasses if tags is not None else []):
                for tag in sub:
                    if tag.code == 340:
                        hs.append(tag.value)
                    elif tag.code == 7 and isinstance(tag.value, str):
                        usados_txt.add(tag.value)
        except Exception:
            pass
        for h in hs:
            st = doc.entitydb.get(h) if h else None
            if st is not None and st.dxftype() == "STYLE":
                usados_txt.add(st.dxf.name)
    for lt in doc.linetypes:   # tipos de línea complejos con texto
        try:
            for tag in lt.pattern_tags.tags:
                if tag.code == 340:
                    st = doc.entitydb.get(tag.value)
                    if st is not None:
                        usados_txt.add(st.dxf.name)
        except Exception:
            pass
    if cfg.get("purgar_no_usados", True):
        for st in list(doc.styles):
            n = st.dxf.name
            if n in usados_txt or n in perm_txt or n.upper() in ("STANDARD", "ANNOTATIVE") or not n:
                continue
            try:
                doc.styles.remove(n)
                res["estilos_texto_purgados"].append(n)
            except Exception:
                pass
        for ds in list(doc.dimstyles):
            n = ds.dxf.name
            if n in usados_dim or n in perm_cota or n.upper() in ("STANDARD", "ANNOTATIVE"):
                continue
            try:
                doc.dimstyles.remove(n)
                res["estilos_cota_purgados"].append(n)
            except Exception:
                pass
        # capas: no se purgan las de la norma ni las referenciadas por viewports
        protegidas = {"0", "DEFPOINTS"} | {v.upper() for v in (normas.get("capas") or {}).values()}
        for lay in doc.layouts:
            for vp in lay.query("VIEWPORT"):
                for n in vp.frozen_layer_names if hasattr(vp, "frozen_layer_names") else []:
                    protegidas.add(str(n).upper())
        for capa in list(doc.layers):
            n = capa.dxf.name
            if n in usadas_capas or n.upper() in protegidas:
                continue
            try:
                doc.layers.remove(n)
                res["capas_purgadas"].append(n)
            except Exception:
                pass
    return res


def leer_datos_plantilla(gen):
    """Datos de viñeta, revisiones, notas y referencias tal como están en la plantilla (DWG del usuario)."""
    out = {}
    for ins in gen.formato_orig:
        at = {}
        for a in ins.attribs:
            at.setdefault(a.dxf.tag, a.dxf.text)
        nm = ins.dxf.name.upper()
        if nm == "T-F-A0":
            for i in range(1, 5):
                if f"DESC-{i}" in at:
                    out[f"titulo{i}"] = at[f"DESC-{i}"].strip()
            if at.get("IIIIIII-AA-EE-TTTT-NNNN-LLLLLZ"):
                out["codigo"] = at["IIIIIII-AA-EE-TTTT-NNNN-LLLLLZ"].strip()
            if at.get("DD/MM/AA"):
                out["fecha_txt"] = at["DD/MM/AA"].strip()
        else:
            filas = ["A", "B", "C", "D", "E", "F", "G", "0"]
            pers = "ABCDEFGH"
            revs = []
            for i, l in enumerate(filas):
                if at.get(l, "").strip():
                    revs.append([at.get(l, ""), at.get(f"FECHA_{l}", ""), at.get(f"MODIFICACIONES_{l}", ""),
                                 at.get(f"DIB_{pers[i]}.", ""), at.get(f"REV_{pers[i]}.", ""),
                                 at.get(f"APR_{pers[i]}.", "")])
            if revs:
                out["revisiones"] = revs
            for k, t in (("dibujo", "D_HMV"), ("proyecto", "DI_HMV"), ("reviso", "R_HMV")):
                if at.get(t, "").strip():
                    out[k] = at[t].strip()
    db = gen.doc.entitydb
    n = db.get(gen.h_notas) if gen.h_notas else None
    if n is not None:
        txt = n.plain_text()
        partes = re.split(r"\n\s*\d+\.\t", "\n" + txt.split("\n", 1)[-1])
        notas = []
        for parte in partes[1:]:
            lineas = [l.strip() for l in parte.strip().split("\n") if l.strip()]
            notas.append("\n".join(("- " + l[1:].strip()) if l.startswith("-") else l for l in lineas))
        if notas:
            out["notas"] = notas
    r = db.get(gen.h_refs) if gen.h_refs else None
    if r is not None:
        refs = []
        for l in r.plain_text().split("\n")[1:]:
            l = l.strip()
            if not l:
                continue
            partes = [x.strip() for x in re.split(r"\t+", l, maxsplit=1)]
            refs.append(partes if len(partes) == 2 else [partes[0], ""])
        if refs:
            out["referencias"] = refs
    return out


def _caja_mtext(m):
    """esquinas aproximadas de un MTEXT (la estimación de ezdxf exagera con formatos en línea)."""
    txt = re.sub(r"\\[A-Za-z][^;\\]*;|[{}]", "", m.text)
    lineas = txt.split("\\P")
    h = m.dxf.char_height
    w = max(len(l) for l in lineas) * h * 0.85
    alto = len(lineas) * h * 1.67
    x, y = m.dxf.insert.x, m.dxf.insert.y
    ap = m.dxf.get("attachment_point", 1)
    col, fila = (ap - 1) % 3, (ap - 1) // 3
    x0 = x - w * (0, 0.5, 1)[col]
    y1 = y + alto * (0, 0.5, 1)[fila]
    return [(x0, y1 - alto), (x0 + w, y1)]


def _caja_rotulo(ml):
    """puntos que encierran un MULTILEADER: flecha, quiebres y caja aproximada del texto."""
    pts = []
    try:
        ctx = ml.context
        for ld in ctx.leaders:
            pts.append(ld.last_leader_point)
            for ln in ld.lines:
                pts += list(ln.vertices)
        mt = ctx.mtext
        if mt is not None:
            h = ctx.char_height or 2.5
            lineas = re.sub(r"\\[A-Za-z][^;]*;|[{}]", "", mt.default_content).split("\\P")
            ancho = max(len(l) for l in lineas) * h * 0.85
            x, y = mt.insert.x, mt.insert.y
            alin = getattr(mt, "alignment", 1)
            x0 = x - ancho if alin == 3 else (x - ancho / 2 if alin == 2 else x)
            pts += [(x0, y + h), (x0 + ancho, y - 1.7 * h * len(lineas))]
    except Exception:
        pass
    return pts


def mtext_notas(notas, titulo="NOTAS :"):
    """lista de notas -> MTEXT con numeración y sangría como el plano original.
    En cada nota, las líneas que empiezan con '-' se dibujan como viñetas."""
    t = "{\\H1.75x;\\C4;" + titulo + "\\P}\\P"
    for i, nota in enumerate([n for n in notas if str(n).strip()], start=1):
        lineas = [l.strip() for l in str(nota).replace("\r", "").split("\n") if l.strip()]
        if not lineas:
            continue
        t += f"\\pxi-3,l4,qj,t4;{i}.^I{lineas[0]}\\P"
        for l in lineas[1:]:
            if l.startswith("-"):
                t += "\\pxi-2,l6,qj,t6;-^I" + l.lstrip("-").strip() + "\\P"
            else:
                t += "\\pxi0,l4,qj;" + l + "\\P"
        t += "\\pxi0,l0;\\P"
    return t


def convertir_a_dxf(ruta_dwg, ruta_dxf):
    """DWG -> DXF (formato del cliente) con ODA File Converter o dwgconv."""
    try:
        from ezdxf.addons import odafc
        if odafc.is_installed():
            odafc.convert(ruta_dwg, ruta_dxf, version="R2018", replace=True)
            return
    except Exception:
        pass
    dll = _buscar_dwgconv()
    if dll and shutil.which("dotnet"):
        r = subprocess.run(["dotnet", dll, ruta_dwg, ruta_dxf], capture_output=True, text=True)
        if r.returncode == 0:
            return
    raise RuntimeError("No se pudo leer el DWG del formato: instale ODA File Converter o .NET 8, "
                       "o entregue el formato en DXF.")


# --------------------------------------------------------------------------
# IMPORTACIÓN DESDE LA PLANILLA EXCEL (01_Procedimiento_E*.xlsm)
# --------------------------------------------------------------------------
MAPA_PLANILLA = {
    # parámetro: (hoja, celda)
    "HLf": ("Fund", "G10"), "Lfx": ("Fund", "G11"), "Lfy": ("Fund", "G12"),
    "n_ped": ("Fund", "G33"), "ped_x": ("Fund", "G30"), "ped_y": ("Fund", "G34"),
    "dist_ped": ("Fund", "G35"),
    "dPd": ("GralFund", "H28"), "Df": ("GralFund", "H29"), "e_grout": ("GralFund", "H30"),
    "e_emp": ("GralFund", "H31"), "rec_inf": ("GralFund", "H47"), "rec_sup": ("GralFund", "H48"),
    "rec_lat": ("GralFund", "H49"), "rec_ped": ("GralFund", "H50"), "rec_ped_sup": ("GralFund", "H51"),
    "s_x": ("Detallado", "K36"), "s_y": ("Detallado", "K36"),
    "db_x": ("Detallado", "K41"), "n_x": ("Detallado", "K42"),
    "db_y": ("Detallado", "K71"), "n_y": ("Detallado", "K72"),
    "n_est": ("Detallado", "K179"), "db_est": ("Detallado", "K180"), "s_est": ("Detallado", "K181"),
    "n_cara": ("Detallado", "K188"), "db_ped": ("Detallado", "K189"),
}


def importar_planilla(ruta_xlsm):
    """Lee los valores calculados (caché) de la planilla y devuelve un dict de parámetros."""
    import openpyxl
    wb = openpyxl.load_workbook(ruta_xlsm, data_only=True, read_only=True)
    out, faltan = {}, []
    for k, (hoja, celda) in MAPA_PLANILLA.items():
        try:
            v = wb[hoja][celda].value
        except KeyError:
            v = None
        if isinstance(v, str):
            try:
                v = float(v.replace(",", "."))
            except ValueError:
                v = None
        if v is None:
            faltan.append(k)
            continue
        tipo = type(DEFAULTS[k])
        out[k] = int(round(v)) if tipo is int else float(v)
    wb.close()
    return out, faltan


# --------------------------------------------------------------------------
# CONVERSIÓN A DWG
# --------------------------------------------------------------------------
def _buscar_dwgconv():
    cands = [os.path.join(AQUI, "dwgconv", "bin", "Release", "net8.0", "dwgconv.dll"),
             os.path.join(AQUI, "dwgconv", "dwgconv.dll")]
    for c in cands:
        if os.path.exists(c):
            return c
    return None


def convertir_dwg(ruta_dxf, ruta_dwg, version="R2018"):
    """1) ODA File Converter (vía ezdxf.addons.odafc) si está instalado;
       2) conversor ACadSharp incluido (requiere .NET 8: carpeta dwgconv)."""
    errores = []
    try:
        from ezdxf.addons import odafc
        if odafc.is_installed():
            odafc.convert(ruta_dxf, ruta_dwg, version=version, replace=True)
            return "ODA File Converter"
    except Exception as ex:  # pragma: no cover
        errores.append(f"ODA: {ex}")
    dll = _buscar_dwgconv()
    if dll and shutil.which("dotnet"):
        r = subprocess.run(["dotnet", dll, ruta_dxf, ruta_dwg, "AC1032"], capture_output=True, text=True)
        if r.returncode == 0 and os.path.exists(ruta_dwg):
            return "ACadSharp (dwgconv)"
        errores.append(f"dwgconv: {r.stderr[-500:]}")
    raise RuntimeError("No se encontró conversor DWG. Instale ODA File Converter (gratuito) o "
                       "compile la carpeta dwgconv con 'dotnet build -c Release'.\n" + "\n".join(errores))


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--params", help="JSON con parámetros (caso)")
    ap.add_argument("--salida", default=os.path.join(AQUI, "salida"))
    ap.add_argument("--sin-dwg", action="store_true")
    ap.add_argument("--sin-normalizar", action="store_true", help="no unificar estilos ni purgar")
    ap.add_argument("--pdf", action="store_true", help="plotear también el PDF (Python, con el CTB del caso)")
    ap.add_argument("--hoja-pdf", default=None, help="papel del PDF (por defecto el de la lámina)")
    ap.add_argument("--dump-params", action="store_true")
    a = ap.parse_args(argv)
    if a.dump_params:
        with open(os.path.join(AQUI, "parametros_por_defecto.json"), "w", encoding="utf-8") as f:
            json.dump(DEFAULTS, f, ensure_ascii=False, indent=2)
        print("parametros_por_defecto.json escrito")
        return
    p = dict(DEFAULTS)
    if a.params:
        with open(a.params, encoding="utf-8") as f:
            p.update(json.load(f))
    plant = (p.get("plantilla") or "").strip()
    if plant and not os.path.isabs(plant):
        plant = os.path.join(AQUI, plant)
    g = Generador(plant or None)
    c = g.generar(p)
    for av in c["avisos"]:
        print("AVISO:", av)
    dxf = os.path.join(a.salida, p["codigo"] + ".dxf")
    dwg = os.path.join(a.salida, p["codigo"] + ".dwg")
    pdf = os.path.join(a.salida, p["codigo"] + ".pdf")
    g.guardar(dxf, normalizar=not a.sin_normalizar)
    print("DXF:", dxf)
    if getattr(g, "resumen_normas", None):
        print("Normalización:", g.resumen_normas)
    a.hoja_pdf = a.hoja_pdf or getattr(g, "papel_plot", "A0")
    lsp, scr = g.exportar_lisp(dxf, ruta_dwg=os.path.basename(dwg), ruta_pdf=os.path.basename(pdf),
                               hoja=a.hoja_pdf, relativas=True)
    print("LISP (tablas con fórmulas + CTB + PDF en AutoCAD):", lsp)
    if not a.sin_dwg:
        try:
            # el DWG sale con las tablas dibujadas (el conversor no escribe bien ACAD_TABLE con campos)
            tmp = os.path.splitext(dxf)[0] + "_tmp_dwg.dxf"
            g.guardar(tmp, normalizar=False, tablas_reales=False)
            try:
                via = convertir_dwg(tmp, dwg)
            finally:
                os.remove(tmp)
            print("DWG:", dwg, "(", via, ")")
        except RuntimeError as ex:
            print(ex)
    if a.pdf:
        import plotear_pdf
        print("PDF:", plotear_pdf.plotear(dxf, pdf, a.hoja_pdf, ctb=p.get("ctb") or "auto"))


if __name__ == "__main__":
    main()
