"""Abrir un plano DWG/DXF ya hecho (por este programa) y recuperar sus parámetros para seguir editándolo.

1) Si el archivo trae los parámetros guardados por el programa (XRECORD «HMV_PARAMETROS», desde la v9),
   se usan tal cual: es exacto.
2) Si no (planos hechos con versiones anteriores), se reconstruyen leyendo el dibujo:
   geometría de cada vista (zapata, pedestales, pernos, estribos, niveles), tablas N°1/2/3,
   cotas, rótulos y viñeta.
3) Se regenera el plano con esos parámetros usando el MISMO DWG como plantilla (formato, viñeta,
   notas, referencias y simbología quedan como estaban) y se comparan las tablas y las cotas con las
   del original: el informe dice qué coincide y qué no.
4) Las ediciones hechas a mano en el CAD que el programa puede representar se conservan:
   textos de cotas cambiados, cotas borradas, cotas y rótulos agregados, textos de rótulos cambiados.

Uso:  py importar_plano.py PLANO.dwg [caso_salida.json]
"""
import copy
import json
import math
import os
import re
import shutil
import sys
import tempfile
from collections import Counter, defaultdict

import ezdxf
from ezdxf import bbox

import plano_fundacion as pf

XREC = "HMV_PARAMETROS"
K = pf.K


# --------------------------------------------------------------------------
# lectura del documento
# --------------------------------------------------------------------------
def abrir_doc(ruta):
    if ruta.lower().endswith(".dwg"):
        tmp = os.path.join(tempfile.mkdtemp(prefix="hmv_imp_"), "plano.dxf")
        pf.convertir_a_dxf(ruta, tmp)
        return ezdxf.readfile(tmp)
    return ezdxf.readfile(ruta)


def parametros_guardados(doc):
    """parámetros que el programa dejó dentro del archivo (o None)."""
    try:
        x = doc.rootdict.get(XREC)
        if x is None:
            return None
        txt = "".join(v for c, v in x.tags if c == 1)
        d = json.loads(txt)
        return d if isinstance(d, dict) else None
    except Exception:
        return None


def guardar_parametros(doc, p):
    """deja los parámetros dentro del DXF/DWG (XRECORD en el diccionario raíz)."""
    try:
        if XREC in doc.rootdict:
            doc.rootdict.remove(XREC)
        x = doc.rootdict.add_xrecord(XREC)
        txt = json.dumps(p, ensure_ascii=False, default=str)
        x.reset([(1, txt[i:i + 240]) for i in range(0, len(txt), 240)])
    except Exception:
        pass


def _papel(doc):
    for lay in doc.layouts:
        if lay.name != "Model":
            return lay


def ventanas(doc):
    """clave de vista -> (cx, cy, w, h, escala) en el espacio modelo, igual que el generador."""
    ps = _papel(doc)
    vps = [v for v in ps.query("VIEWPORT")]
    if not vps:
        return {}
    grande = max(vps, key=lambda v: v.dxf.width * v.dxf.height)
    vps = [v for v in vps if v is not grande] or vps
    out = {}
    f_t = pf.factor_lamina(doc)                  # lámina ampliada/reducida: las posiciones A1 se escalan
    for key, (pc, _h, _e) in pf.VISTAS.items():
        v = min(vps, key=lambda v: (v.dxf.center.x - pc[0] * f_t) ** 2 + (v.dxf.center.y - pc[1] * f_t) ** 2)
        s = v.dxf.view_height / v.dxf.height
        t = v.dxf.view_target_point
        cx = v.dxf.view_center_point.x + t.x
        cy = v.dxf.view_center_point.y + t.y
        out[key] = (cx, cy, v.dxf.width * s / 2, v.dxf.view_height / 2, s)
    return out


def _punta(e):
    try:
        q = e.context.leaders[0].lines[0].vertices[0]
        return (q.x, q.y)
    except Exception:
        return None


def entidades_en(msp, win, cache=None):
    cx, cy, w, h = win[:4]
    out = []
    cache = cache or bbox.Cache()
    for e in msp:
        if e.dxftype() == "MULTILEADER":           # rótulos: cuenta la punta de la flecha
            q = _punta(e)
            if q and cx - w <= q[0] <= cx + w and cy - h <= q[1] <= cy + h:
                out.append(e)
            continue
        try:
            b = bbox.extents([e], cache=cache, fast=True)
        except Exception:
            continue
        if not b.has_data:
            continue
        c = b.center
        if cx - w <= c.x <= cx + w and cy - h <= c.y <= cy + h:
            out.append(e)
    return out


def geometria(E, prof=0):
    """entidades + contenido de los bloques anónimos (*U) sin atributos (p. ej. estribos agrupados o
    copiados en matriz en el CAD), como entidades virtuales en coordenadas del modelo."""
    out = []
    for e in E:
        out.append(e)
        if prof < 4 and e.dxftype() == "INSERT" and e.dxf.name.startswith("*U") and not e.attribs:
            try:
                out += geometria(list(e.virtual_entities()), prof + 1)
            except Exception:
                pass
    return out


def _num(t):
    t = str(t).strip().replace(" ", "")
    t = re.sub(r"[^\d,.\-]", "", t)
    if not t:
        raise ValueError
    if "," in t and "." in t:
        t = t.replace(".", "").replace(",", ".")
    else:
        t = t.replace(",", ".")
    return float(t)


def _rects(ents, capa):
    out = []
    for e in ents:
        if e.dxftype() == "LWPOLYLINE" and e.dxf.layer == capa:
            pts = [(q[0], q[1]) for q in e.get_points()]
            if len(pts) >= 4:
                xs, ys = [q[0] for q in pts], [q[1] for q in pts]
                out.append((min(xs), min(ys), max(xs), max(ys), e))
    return out


def _texto(e):
    t = e.dxftype()
    try:
        if t == "MTEXT":
            return e.plain_text()
        if t == "TEXT":
            return e.dxf.text
        if t == "MULTILEADER":
            return pf.texto_plano(e.context.mtext.default_content) if e.context.mtext else ""
    except Exception:
        pass
    return ""


def _contenido_mleader(e):
    try:
        return e.context.mtext.default_content
    except Exception:
        return ""


# --------------------------------------------------------------------------
# tablas de la lámina
# --------------------------------------------------------------------------
def tablas(doc):
    """{N° de tabla: [filas de textos ordenadas por x]} leyendo bloques *T, ACAD_TABLE o respaldo con XDATA."""
    ps = _papel(doc)
    grupos = defaultdict(list)
    for e in ps:
        t = e.dxftype()
        if t in ("INSERT", "ACAD_TABLE"):
            nombre = e.dxf.get("name") if t == "INSERT" else e.dxf.get("block_name")
            if not nombre or not nombre.startswith("*T") or nombre not in doc.blocks:
                continue
            for m in doc.blocks[nombre].query("MTEXT TEXT"):
                p = m.dxf.insert
                grupos[nombre].append((p.x, p.y, _texto(m)))
        elif t in ("MTEXT", "TEXT") and e.has_xdata(pf.APPID_TABLA):
            try:
                ident = [v for c, v in e.get_xdata(pf.APPID_TABLA) if c == 1000][0]
            except Exception:
                continue
            p = e.dxf.insert
            grupos["X" + ident].append((p.x, p.y, _texto(e)))
    out = {}
    for g, items in grupos.items():
        todo = " ".join(t for _, _, t in items).upper()
        n = None
        for k in ("1", "2", "3", "4"):
            if re.search(rf"TABLA\s*N\s*[°º]\s*{k}\b", todo):
                n = k
                break
        if n is None:
            continue
        items.sort(key=lambda q: -q[1])
        filas, actual, y0 = [], [], None
        for x, y, t in items:
            if y0 is None or abs(y - y0) > 1.6:
                if actual:
                    filas.append(sorted(actual))
                actual, y0 = [], y
            actual.append((x, t.strip()))
        if actual:
            filas.append(sorted(actual))
        out[n] = [[t for _, t in f] for f in filas]
    return out


# --------------------------------------------------------------------------
# reconstrucción de parámetros (plano de marco)
# --------------------------------------------------------------------------
def reconstruir(doc, informe):
    msp = doc.modelspace()
    win = ventanas(doc)
    cache = bbox.Cache()
    ent = {k: entidades_en(msp, w, cache) for k, w in win.items()}
    p = {}
    tab = tablas(doc)

    # ---- tipo de plano
    titulos = " ".join(_texto(e) for e in _papel(doc).query("MTEXT")).upper()
    if "DESCONECTADOR" in titulos or "4" in tab:
        p["tipo_plano"] = pf.DT.TIPO_DT
        informe.append("AVISO: es un plano de desconectador; la lectura automática está pensada para planos de "
                       "marco. Revise los parámetros recuperados.")
    else:
        p["tipo_plano"] = pf.DT.TIPO_MARCO

    # ---- hoja y escalas: el tamaño de la lámina sale del marco (el papel de ploteo puede ser otro, p. ej.
    # una lámina A1 que se plotea ajustada a papel A0)
    f_t = pf.factor_lamina(doc)
    p["hoja"] = min(pf.HOJAS, key=lambda k: abs(pf.HOJAS[k][0] - 841.0 * f_t))
    f = pf.HOJAS[p["hoja"]][0] / 841.0
    for k, (_pc, _h, esc_k) in pf.VISTAS.items():
        if k in win:
            p[esc_k] = int(round(win[k][4] / f))

    # ---- planta: zapata, pedestales, pernos
    E = ent.get("PLANTA", [])
    zap = max(_rects(E, pf.L_FUND), key=lambda r: (r[2] - r[0]) * (r[3] - r[1]), default=None)
    if zap is None:
        raise ValueError("No se encontró la zapata en la planta (capa %s)." % pf.L_FUND)
    x0, y0, x1, y1, _ = zap
    p["Lfy"], p["Lfx"] = round((x1 - x0) / K, 2), round((y1 - y0) / K, 2)
    zc = ((x0 + x1) / 2, (y0 + y1) / 2)
    peds = sorted([r for r in _rects(E, pf.L_EST) if r[0] >= x0 - 1 and r[2] <= x1 + 1 and r[1] >= y0 - 1
                   and r[3] <= y1 + 1 and (r[2] - r[0]) < (x1 - x0) * 0.9], key=lambda r: r[0])
    if not peds:
        raise ValueError("No se encontraron los pedestales en la planta (capa %s)." % pf.L_EST)
    p["ped_y"] = round((peds[0][2] - peds[0][0]) / K, 2)
    p["ped_x"] = round((peds[0][3] - peds[0][1]) / K, 2)
    cxs = sorted({round((r[0] + r[2]) / 2, 0) for r in peds})          # columnas (horizontal en planta)
    cys = sorted({round((r[1] + r[3]) / 2, 0) for r in peds})          # filas (vertical en planta)
    p["n_ped"], p["n_ped_x"] = len(cxs), len(cys)
    if len(cxs) > 1:
        p["dist_ped"] = round((cxs[1] - cxs[0]) / K - p["ped_y"], 2)
    if len(cys) > 1:
        p["dist_ped_x"] = round((cys[1] - cys[0]) / K - p["ped_x"], 2)
    # el pedestal de referencia de los pernos es el de arriba a la izquierda
    peds = sorted(peds, key=lambda r: (-(r[1] + r[3]) / 2, (r[0] + r[2]) / 2))
    circ = [e for e in E if e.dxftype() == "CIRCLE" and e.dxf.layer == pf.L_EST]
    por_ped = []
    for r in peds:
        pc = ((r[0] + r[2]) / 2, (r[1] + r[3]) / 2)
        pts = [(round((c.dxf.center.x - pc[0]) / K, 2), round((c.dxf.center.y - pc[1]) / K, 2), c.dxf.radius)
               for c in circ if r[0] <= c.dxf.center.x <= r[2] and r[1] <= c.dxf.center.y <= r[3]]
        por_ped.append(pts)
    base = [(u, v) for u, v, _ in por_ped[0]]
    if por_ped[0]:
        p["PERF"] = round(2 * por_ped[0][0][2], 1)
    us, vs = sorted({u for u, _ in base}), sorted({v for _, v in base})
    cuadro = len(base) == 4 and len(us) == 2 and len(vs) == 2 and abs((us[1] - us[0]) - (vs[1] - vs[0])) < 0.05 \
        and abs(us[0] + us[1]) < 0.05 and abs(vs[0] + vs[1]) < 0.05
    if cuadro:
        p["pernos_disp"] = pf.OPCIONES["pernos_disp"][0]
        p["perno_sep"] = round(us[1] - us[0], 2)
        p["pernos_ped"] = 4
    elif base:
        p["pernos_disp"] = pf.OPCIONES["pernos_disp"][2]
        p["pernos_pos"] = [[pf.fmt_cm(u).replace(",", "."), pf.fmt_cm(v).replace(",", ".")] for u, v in base]
        if len(por_ped) > 1:
            otro = sorted((round(u, 1), round(v, 1)) for u, v, _ in por_ped[-1])
            su = -1 if len(cxs) > 1 else 1
            sv = -1 if len(cys) > 1 else 1
            espejo = sorted((round(su * u, 1), round(sv * v, 1)) for u, v in base)
            if otro == espejo and otro != sorted((round(u, 1), round(v, 1)) for u, v in base):
                p["pernos_espejo"] = pf.OPCIONES["pernos_espejo"][1]
        informe.append(f"Pernos: {len(base)} por pedestal en disposición propia (se pasó a «Manual»).")
    for e in E:
        if e.dxftype() == "MULTILEADER":
            m = re.search(r"PERNO DE ANCLAJE\s*(?:%%[Cc]|Ø)\s*(.+)$", _texto(e).replace("\n", " "))
            if m:
                p["perno_txt"] = m.group(1).strip()

    # ---- sección A-A formas: niveles
    E = ent.get("AA_FORMAS", [])
    cont = max(_rects(E, pf.L_FUND), key=lambda r: (r[2] - r[0]) * (r[3] - r[1]), default=None)
    if cont is not None:
        verts = []
        for e in E:
            if e.dxftype() == "LWPOLYLINE" and e.dxf.layer == pf.L_FUND and e.closed:
                verts = sorted({round(q[1], 1) for q in e.get_points()})
                if len(verts) >= 3:
                    break
        if len(verts) >= 3:
            y_s, y_tz, y_tp = verts[0], verts[1], verts[-1]
            p["HLf"] = round((y_tz - y_s) / K, 2)
            hpd = (y_tp - y_tz) / K
            ys_d = set()
            for d in E:
                if d.dxftype() == "DIMENSION" and abs(d.dxf.get("angle", 0) - 90) < 1:
                    for q in (d.dxf.defpoint2, d.dxf.defpoint3):
                        if y_tz + 1 < q.y < y_tp - 1:
                            ys_d.add(round(q.y, 1))
            ys_d = sorted(ys_d)
            if ys_d:
                y_0 = ys_d[0]
                p["Df"] = round((y_0 - y_s) / K, 2)
                p["dPd"] = round((y_tp - y_0) / K, 2)
                if len(ys_d) > 1:
                    p["e_grava"] = round((ys_d[1] - y_0) / K, 2)
            else:
                p["dPd"], p["Df"] = 35.0, round(hpd + p["HLf"] - 35.0, 2)
                informe.append("AVISO: no se pudo leer el nivel de patio; se supuso dPd = 35 cm.")
            emp = [r for r in _rects(E, pf.L_EMP)]
            if emp:
                p["e_emp"] = round((emp[0][3] - emp[0][1]) / K, 2)

    # ---- tablas
    t1 = tab.get("1", [])
    barras = []
    for fila in t1:
        if fila and re.fullmatch(r"\d{3,5}", fila[0] or ""):
            try:
                barras.append(dict(marca=fila[0], d=int(_num(fila[1])), tipo=fila[3].strip().upper(),
                                   cant=int(_num(fila[4])), a=_num(fila[5]), b=_num(fila[6]), c=_num(fila[7])))
            except (ValueError, IndexError):
                continue
    t3 = tab.get("3", [])
    for fila in t3:
        idx = next((i for i, x in enumerate(fila) if re.fullmatch(r"[A-Z]\d+\.\d+[A-Z]*", x or "")), None)
        if idx is None:
            continue
        try:
            vals = [_num(x) for x in fila[idx + 1:idx + 11]]
        except ValueError:
            continue
        p["perno_desc"] = fila[idx]
        for k, v in zip(("perno_d", "P", "G", "Lr", "C", "Ldh", "L", "Lg", "Eg", "PERF"), vals):
            p[k] = int(v) if k in ("P", "G", "Lr", "C", "Ldh", "L", "Lg") else float(v)
        resto = fila[idx + 11:]
        todo3 = re.sub(r"\s+", " ", " ".join(" ".join(f) for f in t3).upper())
        p["tabla3_estilo"] = pf.OPCIONES["tabla3_estilo"][0 if "POR PEDESTAL" in todo3 else 1]
        try:
            npt = p["n_ped"] * p.get("n_ped_x", 1)
            cant_fund = int(_num(resto[-1])) if "POR PEDESTAL" not in todo3 else int(_num(resto[0])) * npt
            if not str(p.get("pernos_disp", "")).startswith("Manual"):
                p["pernos_ped"] = max(int(round(cant_fund / npt)), 1)
        except (ValueError, IndexError):
            pass
        break
    t2 = " ".join(" ".join(f) for f in tab.get("2", []))
    m = re.search(r"\(\s*(\d+)\s*FUND", t2.upper())
    if m:
        p["n_fund"] = int(m.group(1))
    filas2 = {f[0].upper(): f for f in tab.get("2", []) if f}

    def valor2(clave):
        for k, f in filas2.items():
            if clave in k:
                try:
                    return _num(f[2])
                except (ValueError, IndexError):
                    return None
    v_exc, v_grout = valor2("EXCAVACI"), valor2("GROUTING")

    # ---- sección A-A armaduras: estribos, recubrimientos, pedestal
    E = geometria(ent.get("AA_ARM", []))
    verts = []
    for e in E:
        if e.dxftype() == "LWPOLYLINE" and e.dxf.layer == pf.L_FUND and e.closed:
            verts = [(q[0], q[1]) for q in e.get_points()]
            break
    if verts:
        ys = sorted({round(q[1], 1) for q in verts})
        xs = sorted({round(q[0], 1) for q in verts})
        y_s, y_tz, y_tp = ys[0], ys[1], ys[-1]
        W = xs[-1] - xs[0]
        xl0 = min(q[0] for q in verts if abs(q[1] - y_tp) < 1)
        wp = p["ped_y"] * K
        lineas = []
        for e in E:
            if e.dxftype() == "LINE" and e.dxf.layer == pf.L_FIERRO:
                a, b = e.dxf.start, e.dxf.end
                if abs(a.y - b.y) < 0.5 and y_tz < a.y < y_tp and xl0 - 1 <= min(a.x, b.x) and max(a.x, b.x) <= xl0 + wp + 1:
                    lineas.append((a.y, min(a.x, b.x), max(a.x, b.x)))
        if lineas:
            p["est_pos"] = sorted(round((y_tp - y) / K, 2) for y, _, _ in lineas)
            p["est_reparto"] = pf.OPCIONES["est_reparto"][2]
            # si los estribos son una serie regular desde la losa (más algunos sueltos), se deja ese reparto:
            # así la cantidad, la separación y la posición del 1° se pueden cambiar como parámetros
            serie = pf.deducir_reparto(p["est_pos"], (y_tp - y_tz) / K)
            if serie:
                p.update(serie)
                p["est_top"] = min(p["est_pos"])
            p["rec_ped"] = round((lineas[0][1] - xl0) / K, 2)
        # recubrimientos de la losa: cotas que arrancan en el borde
        for d in E:
            if d.dxftype() != "DIMENSION":
                continue
            q2, q3 = d.dxf.defpoint2, d.dxf.defpoint3
            med = round(d.get_measurement() / K, 2)
            if med > 30:
                continue
            ang = d.dxf.get("angle", 0)
            if abs(q2.x - xs[0]) < 1 and abs(ang - 90) < 1:
                if abs(q2.y - y_tz) < 1:
                    p["rec_sup"] = med
                elif abs(q2.y - y_s) < 1:
                    p["rec_inf"] = med
            elif abs(q2.x - xs[0]) < 1 and abs(ang) < 1 and abs(q2.y - y_s) < 1:
                p["rec_lat_y"] = med
        # pedestal: tope de barras
        tops = []
        for e in E:
            if e.dxftype() == "LWPOLYLINE" and e.dxf.layer == pf.L_FIERRO:
                pts = [(q[0], q[1]) for q in e.get_points()]
                if pts and all(xl0 - 1 <= q[0] <= xl0 + wp + 1 for q in pts) and max(q[1] for q in pts) > y_tz:
                    tops.append(max(q[1] for q in pts))
        if tops:
            p["rec_ped_sup"] = round((y_tp - max(tops)) / K, 2)
        # barras perpendiculares (puntos) de la fila inferior: separación y barra de esquina
        p.update(_puntos(E, y_s, "x"))
    E = geometria(ent.get("BB_ARM", []))
    xs_b = None
    for e in E:
        if e.dxftype() == "LWPOLYLINE" and e.dxf.layer == pf.L_FUND and e.closed:
            pts = [(q[0], q[1]) for q in e.get_points()]
            xs_b = min(q[0] for q in pts)
            y_sb = min(q[1] for q in pts)
            break
    if xs_b is not None:
        for d in E:
            if d.dxftype() == "DIMENSION" and abs(d.dxf.get("angle", 0)) < 1:
                q2 = d.dxf.defpoint2
                med = round(d.get_measurement() / K, 2)
                if med <= 30 and abs(q2.x - xs_b) < 1 and abs(q2.y - y_sb) < 1:
                    p["rec_lat_x"] = med
        p.update(_puntos(E, y_sb, "y"))
    if p.get("rec_lat_x") and p.get("rec_lat_y") and abs(p["rec_lat_x"] - p["rec_lat_y"]) < 1e-6:
        p["rec_lat"] = p.pop("rec_lat_x")
        p.pop("rec_lat_y")
        p["rec_lat_x"] = p["rec_lat_y"] = 0.0

    # ---- barras de la tabla N°1
    rx = p.get("rec_lat_x") or p.get("rec_lat") or 7.5
    ry = p.get("rec_lat_y") or p.get("rec_lat") or 7.5
    largo_x, largo_y = p["Lfx"] - 2 * rx, p["Lfy"] - 2 * ry
    for b in barras:
        if b["tipo"] == "O":
            p["db_est"], p["gancho_est"] = b["d"], b["c"]
            n_t1 = int(round(b["cant"] / (p["n_ped"] * p.get("n_ped_x", 1))))
            if not str(p.get("est_reparto", "")).startswith("Desde"):
                p["n_est"] = n_t1
            p["_m_est"] = b["marca"]
        elif b["tipo"] == "IG":
            p["_m_tra"] = b["marca"]
            n_est = len(p.get("est_pos") or []) or p.get("n_est") or 1
            tot = int(round(b["cant"] / (p["n_ped"] * p.get("n_ped_x", 1)) / n_est))
            p["n_trabas"], p["n_trabas_b"] = (tot // 2, -1) if tot % 2 == 0 else (tot, 0)
        elif b["tipo"] == "C":
            if abs(b["a"] - largo_x) < 1 and "_x" not in p:
                p["_x"] = 1
                p.update(db_x=b["d"], n_x=int(round(b["cant"] / 2)), marca_x=b["marca"])
                p["_gancho_losa"] = b["b"]
            elif abs(b["a"] - largo_y) < 1 and "_y" not in p:
                p["_y"] = 1
                p.update(db_y=b["d"], n_y=int(round(b["cant"] / 2)), marca_y=b["marca"])
            else:
                p.update(db_ped=b["d"], gancho_ped=b["b"], marca_ped=b["marca"], _a_ped=b["a"])
                por = b["cant"] / (p["n_ped"] * p.get("n_ped_x", 1))
                p["n_cara"] = int(round((por + 4) / 4))
    if p.get("est_pos") and p.get("n_est") and len(p["est_pos"]) != p["n_est"] and \
            str(p.get("est_reparto", "")).startswith("Manual"):
        informe.append(f"AVISO: la tabla N°1 dice {p['n_est']} estribos por pedestal y en el corte A-A se dibujan "
                       f"{len(p['est_pos'])}; se usan los dibujados.")
    # ---- C-C: caras del pedestal y forma de acotar
    E = ent.get("CC", [])
    for e in E:
        if e.dxftype() == "MULTILEADER":
            mm = re.search(r"(\d+)-\d{3,5}\s*(?:%%[Cc]|Ø)\s*\d+\s*@\s*([\d.,]+)", _texto(e).replace("\n", " "))
            if mm:
                p["s_est"] = _num(mm.group(2))
                break
    txt_cc = " ".join(str(d.dxf.get("text", "")) for d in E if d.dxftype() == "DIMENSION")
    if "U.E.=" in txt_cc.replace(" ", ""):
        p["cc_cota_rec"] = pf.OPCIONES["cc_cota_rec"][1]
    m = re.findall(r"(\d+)-\d{3,5}\s*U\.E", txt_cc)
    if m:
        p["n_cara"] = int(m[0])
        if len(m) > 1 and int(m[1]) != int(m[0]):
            p["n_cara_b"] = int(m[1])

    # ---- esquema: grilla, distancias, nodos
    E = ent.get("ESQUEMA", [])
    funds = [r for r in _rects(E, pf.L_FUND)]
    if funds:
        cx_ = sorted({round((r[0] + r[2]) / 2, 0) for r in funds})
        cy_ = sorted({round((r[1] + r[3]) / 2, 0) for r in funds}, reverse=True)
        p["n_ejes"], p["n_filas"] = len(cx_), len(cy_)
        if len(cx_) > 1:
            dx = [round((b - a) / K, 2) for a, b in zip(cx_, cx_[1:])]
            p["sep_ejes"] = dx[0]
            p["seps_ejes"] = "" if len(set(dx)) == 1 else ";".join(pf.fmt_cm(v).replace(",", ".") for v in dx)
        if len(cy_) > 1:
            dy = [round((a - b) / K, 2) for a, b in zip(cy_, cy_[1:])]
            p["sep_patas"] = dy[0]
            p["seps_filas"] = "" if len(set(dy)) == 1 else ";".join(pf.fmt_cm(v).replace(",", ".") for v in dy)
        peds_e = [r for r in _rects(E, pf.L_EST)]
        nodos = defaultdict(dict)
        for e in E:
            if e.dxftype() != "MULTILEADER":
                continue
            t = _texto(e).strip()
            try:
                tip = e.context.leaders[0].lines[0].vertices[0]
            except Exception:
                continue
            r = min(peds_e, key=lambda r: ((r[0] + r[2]) / 2 - tip.x) ** 2 + ((r[1] + r[3]) / 2 - tip.y) ** 2,
                    default=None)
            if r is None or not t:
                continue
            pcx, pcy = (r[0] + r[2]) / 2, (r[1] + r[3]) / 2
            fz = min(funds, key=lambda f: ((f[0] + f[2]) / 2 - pcx) ** 2 + ((f[1] + f[3]) / 2 - pcy) ** 2)
            ie = cx_.index(min(cx_, key=lambda v: abs(v - (fz[0] + fz[2]) / 2))) + 1
            ir = cy_.index(min(cy_, key=lambda v: abs(v - (fz[1] + fz[3]) / 2))) + 1
            j = 0 if pcx < (fz[0] + fz[2]) / 2 - 1 else (1 if p["n_ped"] > 1 else 0)
            nodos[(ie, ir)][j] = t
        dibujadas = {(cx_.index(min(cx_, key=lambda v: abs(v - (f[0] + f[2]) / 2))) + 1,
                      cy_.index(min(cy_, key=lambda v: abs(v - (f[1] + f[3]) / 2))) + 1) for f in funds}
        filas = []
        for ie in range(1, len(cx_) + 1):
            for ir in range(1, len(cy_) + 1):
                nn = nodos.get((ie, ir), {})
                filas.append([str(ie), str(ir), ",".join(nn.get(j, "") for j in range(p["n_ped"])).rstrip(","),
                              "Sí" if (ie, ir) in dibujadas else "No"])
        p["esq_fund"] = filas
    # ---- títulos -> estructura
    for e in _papel(doc).query("MTEXT"):
        t = e.plain_text()
        if t.upper().lstrip().startswith("PLANTA DE FUNDACI"):
            lineas = [l.strip() for l in t.split("\n") if l.strip()]
            cuerpo = [l for l in lineas[1:] if not l.upper().startswith(("ESCALA", "SIN ESCALA"))]
            if cuerpo:
                p["estructura"] = " ".join(cuerpo)
            break
    # ---- derivados de la tabla N°2 y ajustes automáticos
    q = pf.normalizar_params(dict({k: v for k, v in p.items() if not k.startswith("_")}))
    c = pf.calcular(q)
    if "_gancho_losa" in p and abs(p["_gancho_losa"] - (q["HLf"] - q["rec_inf"] - q["rec_sup"])) > 0.01:
        p["gancho_losa"] = p["_gancho_losa"]
    if "_a_ped" in p and abs(p["_a_ped"] - (c["Htot"] - q["rec_ped_sup"] - q["rec_inf"])) > 0.01:
        p["a_ped"] = p["_a_ped"]
    if v_exc:
        A = q["Lfx"] * q["Lfy"] / 1e4
        so = v_exc * 100 / A - q["Df"] - q["e_emp"]
        if 0 <= so < 300:
            p["sobreexc"] = round(so, 1)
    if v_grout:
        npt = q["n_ped"] * max(int(q.get("n_ped_x", 1) or 1), 1)
        pl = math.sqrt(v_grout / (npt * q["e_grout"] / 100 * 1000)) * 100 if q["e_grout"] else 0
        if 10 < pl < 300:
            p["placa"] = round(pl, 1)
    # barra de esquina: sólo si el primer espacio no es el que da el reparto centrado (esq = 0)
    for eje, L_, n_, s_, rec_ in (("x", q["Lfy"], q["n_x"], q["s_x"], pf.rec_y(q)), ("y", q["Lfx"], q["n_y"], q["s_y"], pf.rec_x(q))):
        k = f"esq_{eje}"
        if p.get(k):
            pos0 = pf.posiciones_barras(L_, int(n_), s_, rec_, 0.0)
            if len(pos0) > 1 and abs((pos0[1] - pos0[0]) - p[k]) < 0.15:
                p.pop(k)
    # volúmenes de la tabla N°2 que no salen de las fórmulas: quedan como valor fijo (q_exc, q_rell, q_grout)
    q = pf.normalizar_params(dict({k: v for k, v in p.items() if not k.startswith("_")}))
    c = pf.calcular(q)
    for clave_t, v_c, q_k in (("EXCAVACI", "v_exc", "q_exc"), ("RELLENO", "v_rell", "q_rell"),
                              ("GROUTING", "v_grout", "q_grout")):
        v_t = valor2(clave_t)
        if v_t is not None and abs(v_t - c[v_c]) > max(0.011, 0.005 * abs(v_t)):
            p[q_k] = v_t
            informe.append(f"Tabla N°2: «{clave_t.lower()}…» = {pf.fmt(v_t)} no sale de las fórmulas; "
                           f"queda como valor fijo ({q_k}).")
    # marcas: sólo se dejan fijas las que no salen solas
    q = pf.normalizar_params(dict({k: v for k, v in p.items() if not k.startswith("_")}))
    c = pf.calcular(q)
    for k, auto in (("marca_x", c["m_x"]), ("marca_y", c["m_y"]), ("marca_ped", c["m_ped"])):
        if p.get(k) == auto:
            p[k] = ""
    return {k: v for k, v in p.items() if not k.startswith("_")}


def _puntos(E, y_s, eje):
    """separación y barra de esquina de las barras perpendiculares (puntos de la fila inferior)."""
    pts = sorted(e.dxf.center.x for e in E if e.dxftype() == "CIRCLE" and e.dxf.layer == pf.L_FIERRO
                 and abs(e.dxf.center.y - (y_s + 0)) < 400)
    if len(pts) < 4:
        return {}
    ymin = min(e.dxf.center.y for e in E if e.dxftype() == "CIRCLE" and e.dxf.layer == pf.L_FIERRO)
    fila = sorted(e.dxf.center.x for e in E if e.dxftype() == "CIRCLE" and e.dxf.layer == pf.L_FIERRO
                  and abs(e.dxf.center.y - ymin) < 1)
    if len(fila) < 4:
        return {}
    dif = [round((b - a) / K, 2) for a, b in zip(fila, fila[1:])]
    s = Counter(dif).most_common(1)[0][0]
    out = {f"s_{eje}": s}
    if abs(dif[0] - s) > 0.05:
        out[f"esq_{eje}"] = dif[0]
    return out


# --------------------------------------------------------------------------
# comparación y ediciones hechas a mano
# --------------------------------------------------------------------------
def _alinear(ents_o, ents_g):
    """desplazamiento original -> generado de una vista (centro de la zapata/contorno)."""
    def centro(E):
        rs = _rects(E, pf.L_FUND)
        if not rs:
            return None
        r = max(rs, key=lambda r: (r[2] - r[0]) * (r[3] - r[1]))
        return ((r[0] + r[2]) / 2, (r[1] + r[3]) / 2)
    a, b = centro(ents_o), centro(ents_g)
    if a is None or b is None:
        return None
    return (b[0] - a[0], b[1] - a[1])


def _dims(E):
    out = []
    for d in E:
        if d.dxftype() != "DIMENSION":
            continue
        try:
            q2, q3 = d.dxf.defpoint2, d.dxf.defpoint3
            out.append(dict(e=d, med=round(d.get_measurement() / K, 2), p2=(q2.x, q2.y), p3=(q3.x, q3.y),
                            base=(d.dxf.defpoint.x, d.dxf.defpoint.y), ang=d.dxf.get("angle", 0),
                            texto=d.dxf.get("text", "") or ""))
        except Exception:
            continue
    return out


def _cerca(a, b, tol=6.0):
    return abs(a[0] - b[0]) < tol and abs(a[1] - b[1]) < tol


def ediciones_a_mano(doc_o, gen, p, informe):
    """compara cada vista original con la regenerada y pasa a parámetros lo que se editó a mano."""
    win_o = ventanas(doc_o)
    msp_o = doc_o.modelspace()
    cache = bbox.Cache()
    cotas_mod = dict(p.get("cotas_mod") or {})
    cotas_extra = list(p.get("cotas_extra") or [])
    textos_mod = dict(p.get("textos_mod") or {})
    rotulos_extra = list(p.get("rotulos_extra") or [])
    n_txt = n_oc = n_ex = n_rot = n_rex = 0
    for v in pf.VISTAS:
        if v not in win_o:
            continue
        Eo = entidades_en(msp_o, win_o[v], cache)
        Eg = gen.entidades_vista(v)
        dd = _alinear(Eo, Eg)
        if dd is None:
            continue
        ox, oy = gen.origen_vista(v)
        do, dg = _dims(Eo), _dims(Eg)
        esc = (gen.esc_eff.get(v) or 1.0) * gen._f_obj
        usados = set()
        sin_par = []

        def tramo(dm, desp=(0.0, 0.0)):
            vert = abs(dm["ang"] - 90) < 1
            i = 1 if vert else 0
            a_, b_ = sorted((dm["p2"][i] + desp[i], dm["p3"][i] + desp[i]))
            return vert, a_, b_
        for g in dg:
            cid = gen.cotas_ids.get(g["e"].dxf.handle)
            if cid is None:
                continue
            vg, ga, gb = tramo(g)
            mejor = None
            for i, o in enumerate(do):
                if i in usados or abs(o["med"] - g["med"]) > 0.05:
                    continue
                vo, oa, ob = tramo(o, dd)
                if vo != vg:
                    continue
                err = abs(oa - ga) + abs(ob - gb)
                if err > 30:
                    continue
                j = 0 if vg else 1                          # distancia de las líneas de cota
                dist = abs(o["base"][j] + dd[j] - g["base"][j])
                if mejor is None or (err, dist) < mejor[0]:
                    mejor = ((err, dist), i)
            if mejor is None:
                sin_par.append((g, cid))
                continue
            par = mejor[1]
            usados.add(par)
            o = do[par]
            norm = lambda t: "" if t in ("", "<>") else t
            if norm(o["texto"]) != norm(g["texto"]) and norm(o["texto"]):
                cotas_mod.setdefault(cid, {})["texto"] = o["texto"]
                n_txt += 1
            j = 0 if vg else 1
            dmm = (o["base"][j] + dd[j] - g["base"][j]) / esc
            if abs(dmm) > 0.8:
                cotas_mod.setdefault(cid, {})["desp"] = round(dmm, 2)
        for g, cid in sin_par:                         # ¿la misma cota dibujada algo distinto por otra versión?
            vg, ga, gb = tramo(g)
            par = None
            for i, o in enumerate(do):
                if i in usados:
                    continue
                vo, oa, ob = tramo(o, dd)
                j = 0 if vg else 1
                comun = min(gb, ob) - max(ga, oa)
                if vo == vg and comun > 0.6 * max(gb - ga, ob - oa) and \
                        abs(o["base"][j] + dd[j] - g["base"][j]) / esc < 12:
                    par = i
                    break
            if par is not None:
                usados.add(par)
            elif cid.split(":")[1] not in ("extra", "grupo"):
                cotas_mod.setdefault(cid, {})["oculta"] = True
                n_oc += 1
        # cadena de estribos: la regenera el programa; la del original no se copia como cota agregada
        x_est = [g["base"][0] for g in dg if ":est:" in (gen.cotas_ids.get(g["e"].dxf.handle) or "")]
        for i, o in enumerate(do):                       # cotas del original que el programa no hace
            if i in usados:
                continue
            if abs(o["ang"] - 90) < 1 and any(abs(o["base"][0] + dd[0] - xe) / esc < 15 for xe in x_est):
                continue
            a2 = (o["p2"][0] + dd[0] - ox, o["p2"][1] + dd[1] - oy)
            a3 = (o["p3"][0] + dd[0] - ox, o["p3"][1] + dd[1] - oy)
            b = (o["base"][0] + dd[0] - ox, o["base"][1] + dd[1] - oy)
            tipo = "Vertical" if abs(o["ang"] - 90) < 1 else "Horizontal"
            cotas_extra.append([v, round(a2[0], 3), round(a2[1], 3), round(a3[0], 3), round(a3[1], 3),
                                round(b[0], 3), round(b[1], 3), tipo, "" if o["texto"] in ("<>",) else o["texto"]])
            n_ex += 1
        # rótulos: primero por texto (normalizado), luego por posición de la punta
        ro = [e for e in Eo if e.dxftype() == "MULTILEADER"]
        rg = [e for e in Eg if e.dxftype() == "MULTILEADER"]

        def clave(e):
            t = pf.texto_plano(_contenido_mleader(e)).upper().replace("%%C", "Ø").replace(",", ".")
            return re.sub(r"[\s\-]+", "", t)
        usados_r, usados_g = set(), set()
        for gi, g in enumerate(rg):                     # mismo texto: es el rótulo del programa
            pg_ = _punta(g)
            cands = [(i, o) for i, o in enumerate(ro) if i not in usados_r and clave(o) == clave(g)]
            if cands and pg_:
                i, o = min(cands, key=lambda io: ((_punta(io[1]) or (0, 0))[0] + dd[0] - pg_[0]) ** 2 +
                           ((_punta(io[1]) or (0, 0))[1] + dd[1] - pg_[1]) ** 2)
                usados_r.add(i)
                usados_g.add(gi)
        for gi, g in enumerate(rg):                     # texto cambiado a mano: misma punta
            if gi in usados_g:
                continue
            tid = gen.textos_ids.get(g.dxf.handle)
            pg_ = _punta(g)
            if pg_ is None:
                continue
            cerca = []
            for i, o in enumerate(ro):
                po = _punta(o)
                if i in usados_r or po is None or not _cerca((po[0] + dd[0], po[1] + dd[1]), pg_, 25 * esc):
                    continue
                cerca.append((math.hypot(po[0] + dd[0] - pg_[0], po[1] + dd[1] - pg_[1]), i, o))
            for _d, i, o in sorted(cerca)[:1]:
                usados_r.add(i)
                usados_g.add(gi)
                if tid:
                    txt = re.sub(r"^\{\\C\d+;|\}$", "", _contenido_mleader(o)).replace("\\A1;", "")
                    textos_mod.setdefault(tid, {})["texto"] = txt
                    n_rot += 1
                break
        if v == "ESQUEMA":
            continue                                    # los nodos del esquema ya se leen como tabla
        for i, o in enumerate(ro):                      # rótulos que agregó el usuario
            if i in usados_r:
                continue
            po = _punta(o)
            if po is None:
                continue
            try:
                q2 = o.context.mtext.insert if o.context.mtext else po
            except Exception:
                q2 = po
            rotulos_extra.append([v, round(po[0] + dd[0] - ox, 3), round(po[1] + dd[1] - oy, 3),
                                  round(q2[0] + dd[0] - ox, 3), round(q2[1] + dd[1] - oy, 3),
                                  pf.texto_plano(_contenido_mleader(o)).replace("\n", "\\P"), ""])
            n_rex += 1
    p["cotas_mod"], p["cotas_extra"] = cotas_mod, cotas_extra
    p["textos_mod"], p["rotulos_extra"] = textos_mod, rotulos_extra
    informe.append(f"Ediciones a mano recuperadas: {n_txt} textos de cota, {n_oc} cotas ocultas, {n_ex} cotas "
                   f"agregadas, {n_rot} textos de rótulo, {n_rex} rótulos agregados.")


def comparar_tablas(tab_o, gen, informe):
    """compara los textos de las tablas originales con las regeneradas (celda por celda, por fila)."""
    difs = []
    spec = {t["id"]: t for t in gen.tablas_spec}
    for n, filas in tab_o.items():
        t = spec.get("T" + n)
        if t is None:
            continue
        nf = len(t["altos"])
        gen_filas = []
        for r in range(nf):
            celdas = [pf.texto_plano(t["celdas"][(r, cc)].get("v", "")) for cc in range(len(t["anchos"]))
                      if (r, cc) in t["celdas"]]
            gen_filas.append([x for x in celdas if x.strip()])
        norm = lambda s: re.sub(r"\s+", " ", s.replace("\n", " ")).strip().upper()
        go = Counter(norm(x) for f in filas for x in f if x.strip())
        gg = Counter(norm(x) for f in gen_filas for x in f if x.strip())
        faltan = go - gg
        sobran = gg - go
        if faltan or sobran:
            difs.append(f"Tabla N°{n}: en el original y no en el regenerado: {sorted(faltan)[:12]} · "
                        f"en el regenerado y no en el original: {sorted(sobran)[:12]}")
    if difs:
        informe += ["DIFERENCIA " + d for d in difs]
    else:
        informe.append("Tablas N°1, N°2 y N°3: el plano regenerado da los mismos valores que el original.")
    return difs


# --------------------------------------------------------------------------
# entrada principal
# --------------------------------------------------------------------------
def importar(ruta, destino_plantilla=None):
    """Devuelve (parámetros, informe). Copia el DWG a plantilla/ para usarlo como base del plano."""
    informe = []
    doc = abrir_doc(ruta)
    guardados = parametros_guardados(doc)
    nombre = os.path.basename(ruta)
    dest = destino_plantilla or os.path.join(pf.AQUI, "plantilla", "importados")
    os.makedirs(dest, exist_ok=True)
    copia = os.path.join(dest, nombre)
    if os.path.abspath(copia) != os.path.abspath(ruta):
        shutil.copy2(ruta, copia)
    rel = os.path.relpath(copia, pf.AQUI)
    if guardados:
        p = pf.normalizar_params(guardados)
        p["plantilla"] = rel
        informe.append("El archivo trae sus parámetros guardados por el programa: se recuperaron tal cual.")
        gen = pf.Generador(copia)
        gen.generar(p)
        ediciones_a_mano(doc, gen, p, informe)          # lo que se haya cambiado después en el CAD
        return json.loads(json.dumps(pf.normalizar_params(p) | {"plantilla": rel}, default=float)), informe
    p = reconstruir(doc, informe)
    p["plantilla"] = rel
    p["escala_auto"] = pf.OPCIONES["escala_auto"][1]          # se respetan las escalas del plano original
    gen = pf.Generador(copia)
    datos = pf.leer_datos_plantilla(gen)
    p.update({k: v for k, v in datos.items() if v})
    gen.generar(p)
    comparar_tablas(tablas(doc), gen, informe)
    ediciones_a_mano(doc, gen, p, informe)
    q = json.loads(json.dumps(pf.normalizar_params(p), default=float))     # sin tipos numpy
    q["plantilla"] = rel
    informe.insert(0, f"Plano leído: {nombre} · {q.get('codigo', '')} · zapata {pf.fmt_cm(q['Lfy'])} × "
                      f"{pf.fmt_cm(q['Lfx'])} cm · {q['n_ped']} pedestales {pf.fmt_cm(q['ped_y'])} × "
                      f"{pf.fmt_cm(q['ped_x'])} · pernos {q.get('perno_txt', '')} ({q.get('perno_desc', '')})")
    return q, informe


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    params, inf = importar(sys.argv[1])
    salida = sys.argv[2] if len(sys.argv) > 2 else os.path.join(
        pf.AQUI, "casos", (params.get("codigo") or "plano") + "_importado_parametros.json")
    with open(salida, "w", encoding="utf-8") as fh:
        json.dump(params, fh, ensure_ascii=False, indent=2)
    print("\n".join(inf))
    print("Caso guardado en", salida)
