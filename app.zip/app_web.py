# -*- coding: utf-8 -*-
"""
Puente entre la página web y el generador de planos (corre en el navegador con Pyodide).

Todas las funciones reciben y devuelven texto JSON (o bytes para los archivos), para que la página
(JavaScript) no tenga que conocer objetos de Python.
"""
from __future__ import annotations

import copy
import io
import json
import os
import pathlib
import re
import sys
import time
import traceback
import zipfile

APP = os.path.dirname(os.path.abspath(__file__))
if APP not in sys.path:
    sys.path.insert(0, APP)

pf = None
_gens = {}          # plantilla -> Generador (se reutiliza: cargar una plantilla es lo más lento)
_estado = {"g": None, "p": None, "c": None}


def _json(obj):
    return json.dumps(obj, ensure_ascii=False, default=str)


def _plantilla_web(ruta):
    """en la web no hay conversor DWG: las plantillas DWG van convertidas a DXF junto al programa."""
    if not ruta:
        return None
    r = ruta if os.path.isabs(ruta) else os.path.join(APP, ruta)
    if r.lower().endswith(".dwg"):
        r = r[:-4] + ".dxf"
    return r


# ---------------------------------------------------------------------------
def init():
    global pf
    import ezdxf
    from ezdxf.fonts import fonts
    fuentes = os.path.join(APP, "fuentes")
    if fuentes not in ezdxf.options.support_dirs:
        ezdxf.options.support_dirs.append(fuentes)
    ezdxf.options.set("drawing-addon", "shx_resolve_order", "lst")
    try:
        fonts.font_manager.scan_folder(pathlib.Path(fuentes))
    except Exception:
        pass
    import plano_fundacion as _pf
    pf = _pf
    casos = []
    cdir = os.path.join(APP, "casos")
    for f in sorted(os.listdir(cdir)):
        if f.endswith("_parametros.json"):
            try:
                with open(os.path.join(cdir, f), encoding="utf-8") as fh:
                    d = json.load(fh)
            except (OSError, ValueError):
                continue
            casos.append({"archivo": f, "nombre": f.replace("_parametros.json", ""),
                          "tipo": "dt" if pf.DT.es_dt(d) else "marco", "codigo": d.get("codigo", "")})
    grupos = []
    for k, (v, g, etq) in pf.PARAM_DEF.items():
        if g not in grupos:
            grupos.append(g)
    meta = {
        "params": [{"clave": k, "defecto": v, "grupo": g, "etiqueta": etq,
                    "tipo": ("bool" if isinstance(v, bool) else "int" if isinstance(v, int)
                             else "float" if isinstance(v, float) else "str"),
                    "opciones": pf.OPCIONES.get(k)} for k, (v, g, etq) in pf.PARAM_DEF.items()],
        "grupos": grupos,
        "listas": list(pf.DEFAULTS_LISTAS.keys()),
        "defectos_listas": pf.DEFAULTS_LISTAS,
        "casos": casos,
        "tipo_dt": pf.DT.TIPO_DT, "tipo_marco": pf.DT.TIPO_MARCO,
        "vistas": ["PLANTA", "AA_FORMAS", "BB_FORMAS", "AA_ARM", "BB_ARM", "CC", "ESQUEMA"],
        "nombres_marco": pf.NOMBRE_VISTA_MARCO, "nombres_dt": pf.DT.NOMBRES,
        "ctbs": sorted(f for f in os.listdir(os.path.join(APP, "ctb")) if f.lower().endswith(".ctb")),
        "plantillas_pernos": pf.PLANTILLAS_PERNOS,
    }
    return _json(meta)


def cargar_caso(archivo):
    with open(os.path.join(APP, "casos", archivo), encoding="utf-8") as fh:
        d = json.load(fh)
    return _json(pf.normalizar_params(d))


def normalizar(params_json):
    return _json(pf.normalizar_params(json.loads(params_json)))


def _generador(p):
    clave = _plantilla_web(p.get("plantilla") or "") or ""
    g = _gens.get(clave)
    if g is None:
        g = pf.Generador(clave or None)
        _gens[clave] = g
    return g


def generar(params_json):
    """genera el plano y devuelve el resumen (avisos, barras, cotas, estribos)."""
    t = time.time()
    p = json.loads(params_json)
    try:
        g = _generador(p)
        c = g.generar(p)
    except Exception as ex:
        return _json({"ok": False, "error": f"{type(ex).__name__}: {ex}", "traza": traceback.format_exc()[-1500:]})
    _estado.update(g=g, p=g.p, c=c)
    cotas = {}
    for cid, i in g.cotas_info.items():
        cotas.setdefault(i["vista"], []).append(
            {"cid": cid, "medida": round(i["medida"], 3), "texto_auto": i.get("texto_auto"),
             "texto": i.get("texto"), "oculta": i.get("oculta"), "desp": i.get("desp"),
             "tags": [t_ for t_ in i.get("tags", ()) if not str(t_).startswith("@")]})
    barras = [{k: b.get(k) for k in ("marca", "d", "tipo", "cant", "a", "b", "c", "Lp", "Lt", "peso")}
              for b in c["barras"]]
    textos = {}
    for tid, i in g.textos_info.items():
        a = i.get("auto")
        textos.setdefault(i["vista"], []).append(
            {"id": tid, "tipo": i["tipo"], "auto": a if isinstance(a, dict) else pf.texto_plano(a)})
    titulos = {k: pf.texto_plano(v) for k, v in g.titulos_auto.items()}
    celdas = {}
    for k, v in g.celdas_info.items():
        celdas.setdefault(k.split(":")[0], []).append({"id": k, "auto": pf.texto_plano(v)})
    pos = pf.posiciones_estribos(g.p)
    res = {
        "ok": True, "segundos": round(time.time() - t, 2), "avisos": c.get("avisos", []),
        "acero": c.get("acero"), "barras": barras, "cotas": cotas, "estribos": pos,
        "hpd": c.get("HPd"), "nombres": dict(pf.NOMBRE_VISTA), "dt": pf.DT.es_dt(g.p),
        "textos": textos, "titulos": titulos, "celdas": celdas,
        "tablas": [{"id": t_["id"], "filas": len(t_["altos"])} for t_ in g.tablas_spec],
        "cantidades": {k: c.get(k) for k in ("v_horm", "v_emp", "v_exc", "v_rell", "v_grout", "pernos",
                                             "v_mold", "ganchos") if c.get(k) is not None},
    }
    return _json(res)


def resolver_cota(params_json, cid, valor):
    g = _estado["g"]
    p = json.loads(params_json)
    if g is None:
        return _json({"ok": False, "error": "Primero genere el plano."})
    try:
        upd = g.resolver_cota(pf.normalizar_params(p), cid, float(valor))
    except Exception as ex:
        return _json({"ok": False, "error": str(ex)})
    if upd is None:
        return _json({"ok": False, "error": "Esta cota no depende de ningún parámetro numérico: cambie su texto."})
    return _json({"ok": True, "cambios": upd})


def esquema_tabla(params_json):
    """tabla de fundaciones del esquema con todas las de la grilla (ejes × filas) y sus nodos actuales."""
    return _json(pf.esquema_tabla_inicial(pf.normalizar_params(json.loads(params_json))))


def pernos_actuales(params_json):
    p = pf.normalizar_params(json.loads(params_json))
    return _json([[pf.fmt_cm(u).replace(",", "."), pf.fmt_cm(v).replace(",", ".")] for u, v in pf.pernos_base(p)])


def editar_estribos(params_json, accion, opciones_json):
    o = json.loads(opciones_json or "{}")
    p = json.loads(params_json)
    upd = pf.editar_estribos(p, accion, valor=o.get("valor"), indice=o.get("indice"), cid=o.get("cid"),
                             sep=o.get("sep"), espacios=o.get("espacios"), kw_grupo=o.get("grupo"))
    return _json(upd)


# ---------------------------------------------------------------------------
# dibujo: SVG de una vista (vista previa) o de la lámina completa con el CTB (para el PDF)
# ---------------------------------------------------------------------------
_RE_COLOR = re.compile(r"\\[Cc]\d+;|\\c\d+;")


def _svg(doc, layout_, filtro=None, pagina=None, ctb=None, escala=None):
    from ezdxf.addons.drawing import Frontend, RenderContext, svg, layout
    from ezdxf.addons.drawing.config import Configuration, BackgroundPolicy, ColorPolicy, LineweightPolicy
    ctb_obj = None
    if ctb:
        from ezdxf.addons import acadctb
        ruta = os.path.join(APP, "ctb", os.path.basename(ctb))
        if os.path.exists(ruta):
            ctb_obj = acadctb.load(ruta)
    cfg = Configuration(background_policy=BackgroundPolicy.WHITE,
                        color_policy=ColorPolicy.COLOR if ctb_obj is None else ColorPolicy.COLOR,
                        lineweight_policy=LineweightPolicy.ABSOLUTE,
                        lineweight_scaling=1.0 if ctb_obj is not None else 0.5)
    ctx = RenderContext(doc, ctb=ctb_obj) if ctb_obj is not None else RenderContext(doc)
    be = svg.SVGBackend()
    fe = Frontend(ctx, be, config=cfg)
    fe.draw_layout(layout_, finalize=True, filter_func=filtro)
    if pagina is None:
        pagina = layout.Page(0, 0, layout.Units.mm, margins=layout.Margins.all(3))
        ajustes = layout.Settings(scale=1.0 / (escala or 1.0), max_stroke_width=0.0015, min_stroke_width=0.0001,
                                  fixed_stroke_width=0.0005)
    else:
        ajustes = layout.Settings(fit_page=True, max_stroke_width=0.0016, min_stroke_width=0.00005,
                                  fixed_stroke_width=0.00012)
    return be.get_string(pagina, settings=ajustes)


def svg_vista(vista):
    g = _estado["g"]
    if g is None:
        return ""
    hs = {e.dxf.handle for e in g.entidades_vista(vista)}
    esc = (g.esc_eff.get(vista) or 35.0) * getattr(g, "_f_obj", 1.0)
    return _svg(g.doc, g.msp, filtro=lambda e: e.dxf.handle in hs, escala=esc)


def svg_lamina(ctb="", hoja="A0"):
    """lámina completa, como sale ploteada: CTB, sin colores escritos dentro de los textos, m³ como carácter."""
    import plotear_pdf as pp
    from ezdxf.addons.drawing import layout
    g = _estado["g"]
    if g is None:
        return ""
    guardados = []
    for lay in [g.msp, g.ps] + list(g.doc.blocks):
        for e in lay:
            t = e.dxftype()
            try:
                if t == "MTEXT":
                    nuevo = pp._superindices(_RE_COLOR.sub("", e.text))
                    if nuevo != e.text:
                        guardados.append((e, "text", e.text))
                        e.text = nuevo
                elif t == "MULTILEADER" and e.context.mtext is not None:
                    mt = e.context.mtext
                    nuevo = _RE_COLOR.sub("", mt.default_content)
                    if nuevo != mt.default_content:
                        guardados.append((mt, "default_content", mt.default_content))
                        mt.default_content = nuevo
            except Exception:
                pass
    try:
        W, H = pp.HOJAS.get(str(hoja).upper(), pp.HOJAS["A0"])
        pagina = layout.Page(W, H, layout.Units.mm, margins=layout.Margins.all(0))
        nombre = ctb or g.ps.dxf_layout.dxf.get("current_style_sheet", "") or "GN-PLOT-HMV.ctb"
        return _svg(g.doc, g.ps, pagina=pagina, ctb=nombre)
    finally:
        for obj, attr, val in guardados:
            setattr(obj, attr, val)


# ---------------------------------------------------------------------------
# archivos
# ---------------------------------------------------------------------------
def exportar_zip(params_json):
    """ZIP con: DXF (tablas reales con fórmulas), LISP/SCR para AutoCAD, el caso (JSON) y un LÉAME."""
    g = _estado["g"]
    if g is None:
        raise RuntimeError("Primero genere el plano.")
    p = json.loads(params_json)
    cod = (g.p.get("codigo") or "plano").strip() or "plano"
    tmp = "/tmp/hmv_export"
    os.makedirs(tmp, exist_ok=True)
    dxf = os.path.join(tmp, cod + ".dxf")
    g.guardar(dxf)
    lsp, scr = g.exportar_lisp(dxf, ruta_dwg=cod + ".dwg", ruta_pdf=cod + ".pdf", relativas=True)
    caso = {k: v for k, v in p.items()}
    leame = (
        f"{cod}\r\n\r\n"
        f"- {cod}.dxf: plano con capas, estilos HMV y tablas REALES con fórmulas ({getattr(g, 'tablas_escritas', 0)} tablas).\r\n"
        "  Ábralo en AutoCAD u Open CAD Studio; para tener DWG use Guardar como -> DWG.\r\n"
        f"- {os.path.basename(lsp)} / .scr: en AutoCAD (APPLOAD + HMV_FINALIZAR) vuelve a crear las tablas con el estilo\r\n"
        "  de AutoCAD, asigna el CTB y plotea el PDF.\r\n"
        f"- {cod}_parametros.json: el caso, para volver a abrirlo en la web («Abrir caso»).\r\n"
        "- Los CTB GN-PLOT-HMV / GN-FIT-HMV deben estar en la carpeta de estilos de ploteo del programa CAD.\r\n")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(dxf, cod + ".dxf")
        z.write(lsp, os.path.basename(lsp))
        z.write(scr, os.path.basename(scr))
        z.writestr(cod + "_parametros.json", json.dumps(caso, ensure_ascii=False, indent=2))
        z.writestr("LEAME.txt", leame)
        for f in os.listdir(os.path.join(APP, "ctb")):
            z.write(os.path.join(APP, "ctb", f), "ctb/" + f)
    return buf.getvalue()


def subir_archivo(nombre, datos):
    """guarda un archivo subido por el usuario (plantilla o formato DXF, planilla Excel)."""
    d = os.path.join(APP, "subidos")
    os.makedirs(d, exist_ok=True)
    ruta = os.path.join(d, os.path.basename(nombre))
    with open(ruta, "wb") as fh:
        fh.write(bytes(datos))
    _gens.pop(ruta, None)
    return ruta


def importar_planilla(ruta, params_json):
    p = json.loads(params_json)
    try:
        nuevos = pf.importar_planilla(ruta)
    except Exception as ex:
        return _json({"ok": False, "error": str(ex)})
    p.update(nuevos if isinstance(nuevos, dict) else {})
    return _json({"ok": True, "params": p})
