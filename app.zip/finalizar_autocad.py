# -*- coding: utf-8 -*-
"""
Post-proceso en AutoCAD (requiere AutoCAD completo, no AutoCAD LT):

  1. borra el respaldo de las tablas (líneas + MTEXT marcados con XDATA "HMV_TABLA")
  2. crea las tablas N°1, N°2 y N°3 como objetos TABLE reales de AutoCAD, con las mismas
     fórmulas de campo que el plano original:
        PARCIAL = (a+2b)/100 · TOTAL = CANT×PARCIAL · PESO = PESO/m×TOTAL · TOTAL = Sum(...)
        ACERO (tabla 2) = Table(tabla 1).K<total> · TOTAL obra = por fundación × N
  3. asigna el estilo de ploteo CTB a la lámina
  4. guarda como DWG 2018 y, si se pide, plotea a PDF con "DWG To PDF.pc3" y el CTB

Se genera un archivo .lsp (comando HMV_FINALIZAR) y un .scr que AutoCAD ejecuta al abrir el DXF:
    acad.exe "plano.dxf" /b "plano_finalizar.scr"
"""
from __future__ import annotations

import glob
import os
import sys
import shutil
import subprocess

AQUI = os.path.dirname(os.path.abspath(__file__))
CTB_DIR = os.path.join(AQUI, "ctb")

MEDIOS = {  # nombre canónico de "DWG To PDF.pc3"
    "A0": "ISO_full_bleed_A0_(841.00_x_1189.00_MM)",
    "A1": "ISO_full_bleed_A1_(594.00_x_841.00_MM)",
    "A2": "ISO_full_bleed_A2_(420.00_x_594.00_MM)",
    "A3": "ISO_full_bleed_A3_(297.00_x_420.00_MM)",
    "A4": "ISO_full_bleed_A4_(210.00_x_297.00_MM)",
}


def _s(txt):
    """cadena AutoLISP (escapa barras invertidas y comillas)."""
    return '"' + str(txt).replace("\\", "\\\\").replace('"', '\\"') + '"'


def _num(v):
    return ("%.4f" % float(v)).rstrip("0").rstrip(".")


def _campo(formula, fmt=None):
    if formula.startswith("@T1"):
        return None  # se arma en AutoCAD con el ObjectId de la tabla N°1
    f = f'%<\\AcExpr {formula}'
    if fmt:
        f += f' \\f "{fmt}"'
    return f + ">%"


def _lisp_tablas(tablas, estilo_texto):
    out = ["(setq *hmv-tablas* (list"]
    for t in tablas:
        celdas = []
        for (r, c), cel in sorted(t["celdas"].items()):
            f = cel.get("f")
            if f == "@T1":
                tipo, contenido = "T1", cel.get("fmt") or ""
            elif f:
                tipo, contenido = "F", _campo(f, cel.get("fmt"))
            else:
                tipo, contenido = "T", cel.get("v", "")
            if contenido in ("", None) and tipo == "T":
                continue
            al = 4 if cel.get("al") == "ML" else 5
            celdas.append(f"    (list {r} {c} {_s(tipo)} {_s(contenido)} {_num(cel.get('h', 2.5))} {al})")
        comb = " ".join(f"(list {r0} {r1} {c0} {c1})" for (r0, c0, r1, c1) in t["combinadas"])
        sinb = " ".join(f"(list {r} {c} {_s(l)})" for (r, c, l) in t.get("sin_borde", []))
        out.append(
            f"  (list {_s(t['id'])} (list {_num(t['origen'][0])} {_num(t['origen'][1])})\n"
            f"    (list {' '.join(_num(w) for w in t['anchos'])})\n"
            f"    (list {' '.join(_num(h) for h in t['altos'])})\n"
            f"    (list {comb})\n"
            f"    (list {sinb})\n"
            f"    (list\n" + "\n".join(celdas) + "))")
    out.append("))")
    return "\n".join(out)


LISP_CUERPO = r'''
;;; ---------------------------------------------------------------------------
;;; HMV_FINALIZAR  -  generado por plano_fundacion (no editar a mano)
;;; ---------------------------------------------------------------------------
(vl-load-com)

(defun hmv:log (msg / f)
  (if (setq f (open *hmv-log* "a")) (progn (write-line msg f) (close f)))
  (princ (strcat "\nHMV: " msg)))

(defun hmv:try (fn args / r)
  (setq r (vl-catch-all-apply fn args))
  (if (vl-catch-all-error-p r)
    (progn (hmv:log (strcat "  aviso: " (vl-princ-to-string fn) " -> " (vl-catch-all-error-message r))) nil)
    r))

(defun hmv:estilo-tabla (doc / dic ts)
  (setq dic (vla-Item (vla-get-Dictionaries doc) "ACAD_TABLESTYLE"))
  (setq ts (vl-catch-all-apply 'vla-Item (list dic *hmv-estilo-tabla*)))
  (if (vl-catch-all-error-p ts)
    (setq ts (vla-AddObject dic *hmv-estilo-tabla* "AcDbTableStyle")))
  (hmv:try 'vla-put-TitleSuppressed (list ts :vlax-true))
  (hmv:try 'vla-put-HeaderSuppressed (list ts :vlax-true))
  (hmv:try 'vla-SetTextStyle (list ts 7 *hmv-estilo-texto*))
  (hmv:try 'vla-SetTextHeight (list ts 7 2.5))
  (hmv:try 'vla-SetAlignment (list ts 7 5))
  (hmv:try 'vla-put-HorzCellMargin (list ts 0.4))
  (hmv:try 'vla-put-VertCellMargin (list ts 0.3))
  ts)

(defun hmv:borrar-respaldo (/ ss i)
  (if (setq ss (ssget "_X" (list (list -3 (list *hmv-appid*)))))
    (progn
      (setq i 0)
      (repeat (sslength ss) (entdel (ssname ss i)) (setq i (1+ i)))
      (hmv:log (strcat "respaldo de tablas borrado: " (itoa (sslength ss)) " entidades"))))
  (princ))

(defun hmv:crear-tabla (doc bloque spec id-t1 / id org anchos altos comb sinb celdas tbl nf nc i txt
                        r c tipo cont h al lado vis)
  (setq id (nth 0 spec) org (nth 1 spec) anchos (nth 2 spec) altos (nth 3 spec)
        comb (nth 4 spec) sinb (nth 5 spec) celdas (nth 6 spec)
        nf (length altos) nc (length anchos))
  (setq tbl (vla-AddTable bloque (vlax-3d-point (car org) (cadr org) 0.0) nf nc (car altos) (car anchos)))
  (hmv:try 'vla-put-RegenerateTableSuppressed (list tbl :vlax-true))
  (hmv:try 'vla-put-StyleName (list tbl *hmv-estilo-tabla*))
  (hmv:try 'vla-put-Layer (list tbl *hmv-capa*))
  (hmv:try 'vla-put-VertCellMargin (list tbl 0.3))
  (hmv:try 'vla-put-HorzCellMargin (list tbl 0.4))
  (setq i 0) (foreach w anchos (hmv:try 'vla-SetColumnWidth (list tbl i w)) (setq i (1+ i)))
  (setq i 0) (foreach h altos (hmv:try 'vla-SetRowHeight (list tbl i h)) (setq i (1+ i)))
  (foreach m comb (hmv:try 'vla-MergeCells (list tbl (nth 0 m) (nth 1 m) (nth 2 m) (nth 3 m))))
  (foreach cel celdas
    (setq r (nth 0 cel) c (nth 1 cel) tipo (nth 2 cel) cont (nth 3 cel) h (nth 4 cel) al (nth 5 cel))
    (cond
      ((= tipo "T1")
       (setq txt (strcat "%<\\AcExpr (Table(%<\\_ObjId " id-t1 ">%)." *hmv-t1-total* ")"
                         (if (/= cont "") (strcat " \\f \"" cont "\"") "") ">%")))
      (t (setq txt cont)))
    (hmv:try 'vla-SetCellTextStyle (list tbl r c *hmv-estilo-texto*))
    (hmv:try 'vla-SetCellTextHeight (list tbl r c h))
    (hmv:try 'vla-SetCellAlignment (list tbl r c al))
    (hmv:try 'vla-SetText (list tbl r c txt)))
  (foreach s sinb
    (setq lado (nth 2 s)
          vis (cond ((= lado "izq") 8) ((= lado "abajo") 4) ((= lado "der") 32) (t 1)))
    (hmv:try 'vla-SetCellGridVisibility (list tbl (nth 0 s) (nth 1 s) vis :vlax-false)))
  (hmv:try 'vla-put-RegenerateTableSuppressed (list tbl :vlax-false))
  (hmv:try 'vla-RecomputeTableBlock (list tbl :vlax-true))
  (hmv:log (strcat "tabla " id " creada (" (itoa nf) "x" (itoa nc) ")"))
  tbl)

(defun c:HMV_FINALIZAR (/ doc lay bloque t1 id-t1 plot ss)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (hmv:log "---- HMV_FINALIZAR ----")
  (setvar "CMDECHO" 0)
  (if (member *hmv-layout* (layoutlist)) (setvar "CTAB" *hmv-layout*))
  (setq lay (vla-get-ActiveLayout doc)
        bloque (vla-get-Block lay))
  ;; 1-2. tablas reales con fórmulas
  (hmv:borrar-respaldo)
  (hmv:estilo-tabla doc)
  (foreach spec *hmv-tablas*
    (if (= (car spec) "T1")
      (setq t1 (hmv:crear-tabla doc bloque spec "0"))))
  (setq id-t1 (if t1 (vla-GetObjectIdString (vla-get-Utility doc) t1 :vlax-false) "0"))
  (foreach spec *hmv-tablas*
    (if (/= (car spec) "T1") (hmv:crear-tabla doc bloque spec id-t1)))
  (if (setq ss (ssget "_X" '((0 . "ACAD_TABLE"))))
    (vl-cmdf "_.UPDATEFIELD" ss ""))
  (vla-Regen doc acAllViewports)
  ;; 3. estilo de ploteo
  (hmv:try 'vla-put-PlotWithPlotStyles (list lay :vlax-true))
  (if (hmv:try 'vla-put-StyleSheet (list lay *hmv-ctb*))
    (hmv:log (strcat "CTB asignado: " *hmv-ctb*))
    (hmv:log (strcat "CTB asignado (verifique que " *hmv-ctb* " esté en la carpeta Plot Styles)")))
  ;; 4. guardar DWG
  (if *hmv-dwg*
    (progn
      (if (findfile *hmv-dwg*) (vl-file-delete *hmv-dwg*))
      (if (hmv:try 'vla-SaveAs (list doc *hmv-dwg* 64))   ; 64 = AutoCAD 2018 DWG
        (hmv:log (strcat "DWG guardado: " *hmv-dwg*)))))
  ;; 5. PDF
  (if *hmv-pdf*
    (progn
      (setvar "BACKGROUNDPLOT" 0)
      (hmv:try 'vla-put-ConfigName (list lay "DWG To PDF.pc3"))
      (hmv:try 'vla-RefreshPlotDeviceInfo (list lay))
      (hmv:try 'vla-put-CanonicalMediaName (list lay *hmv-medio*))
      (hmv:try 'vla-put-PlotType (list lay acLayout))
      (hmv:try 'vla-put-UseStandardScale (list lay :vlax-true))
      (hmv:try 'vla-put-StandardScale (list lay acScaleToFit))
      (hmv:try 'vla-put-CenterPlot (list lay :vlax-true))
      (hmv:try 'vla-put-StyleSheet (list lay *hmv-ctb*))
      (setq plot (vla-get-Plot doc))
      (if (findfile *hmv-pdf*) (vl-file-delete *hmv-pdf*))
      (if (hmv:try 'vla-PlotToFile (list plot *hmv-pdf*))
        (hmv:log (strcat "PDF ploteado: " *hmv-pdf*)))
      (if *hmv-dwg* (hmv:try 'vla-Save (list doc)))))
  (hmv:log "---- fin ----")
  (princ))

(princ "\nHMV: escriba HMV_FINALIZAR para crear tablas, asignar CTB, guardar DWG y plotear PDF.")
(princ)
'''


def generar_lisp(tablas, ruta_lsp, *, layout="lámina 1", ctb="GN-PLOT-HMV.ctb", estilo_texto="TRANSELEC",
                 estilo_tabla="HMV-TABLA", capa="GN-ANNO-LEGN", ruta_dwg=None, ruta_pdf=None, hoja="A0",
                 appid="HMV_TABLA", relativas=False):
    """relativas=True: rutas de DWG/PDF/log relativas a la carpeta del dibujo (archivo portable)."""
    t1 = next((t for t in tablas if t["id"] == "T1"), None)
    total = t1.get("celda_total", "K11") if t1 else "K11"
    cab = [
        ";;; Post-proceso HMV - plano de fundación (generado automáticamente)",
        f"(setq *hmv-layout* {_s(layout)})",
        f"(setq *hmv-ctb* {_s(os.path.basename(ctb))})",
        f"(setq *hmv-estilo-texto* {_s(estilo_texto)})",
        f"(setq *hmv-estilo-tabla* {_s(estilo_tabla)})",
        f"(setq *hmv-capa* {_s(capa)})",
        f"(setq *hmv-appid* {_s(appid)})",
        f"(setq *hmv-t1-total* {_s(total)})",
        f"(setq *hmv-medio* {_s(MEDIOS.get(hoja.upper(), MEDIOS['A0']))})",
        f"(setq *hmv-dwg* {(_s(ruta_dwg.replace(os.sep, '/')) if ruta_dwg else 'nil')})",
        f"(setq *hmv-pdf* {(_s(ruta_pdf.replace(os.sep, '/')) if ruta_pdf else 'nil')})",
        f"(setq *hmv-log* {_s((os.path.splitext(ruta_lsp)[0] if not relativas else os.path.splitext(os.path.basename(ruta_lsp))[0]).replace(os.sep, '/') + '_log.txt')})",
        ';; rutas relativas -> carpeta del dibujo abierto',
        '(defun hmv:abs (r) (if (and r (not (wcmatch r "?:*,/*,\\\\*"))) (strcat (getvar "DWGPREFIX") r) r))',
        '(setq *hmv-dwg* (hmv:abs *hmv-dwg*) *hmv-pdf* (hmv:abs *hmv-pdf*) *hmv-log* (hmv:abs *hmv-log*))',
        _lisp_tablas(tablas, estilo_texto),
    ]
    with open(ruta_lsp, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(cab) + "\n" + LISP_CUERPO)
    return ruta_lsp


def generar_scr(ruta_lsp, ruta_scr, salir=False):
    ruta_scr = os.path.abspath(ruta_scr)
    lineas = ["_.FILEDIA 0", f'(load "{ruta_lsp.replace(os.sep, "/")}")', "HMV_FINALIZAR", "_.FILEDIA 1"]
    if salir:
        lineas.append("_.QUIT _Y")
    # los .scr se leen con la página de códigos de Windows (rutas con tildes)
    with open(ruta_scr, "w", encoding="cp1252", errors="replace") as f:
        f.write("\n".join(lineas) + "\n")
    return ruta_scr


def buscar_autocad():
    """ruta de acad.exe (Windows) o None."""
    cands = []
    try:
        import winreg
        for raiz in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
            try:
                k = winreg.OpenKey(raiz, r"SOFTWARE\Autodesk\AutoCAD")
            except OSError:
                continue
            i = 0
            while True:
                try:
                    ver = winreg.EnumKey(k, i)
                except OSError:
                    break
                i += 1
                try:
                    kv = winreg.OpenKey(k, ver)
                    j = 0
                    while True:
                        try:
                            prod = winreg.EnumKey(kv, j)
                        except OSError:
                            break
                        j += 1
                        try:
                            kp = winreg.OpenKey(kv, prod)
                            loc, _ = winreg.QueryValueEx(kp, "AcadLocation")
                            cands.append(os.path.join(loc, "acad.exe"))
                        except OSError:
                            pass
                except OSError:
                    pass
    except ImportError:
        pass
    cands += sorted(glob.glob(r"C:\Program Files\Autodesk\AutoCAD 20*\acad.exe"), reverse=True)
    for c in cands:
        if os.path.exists(c):
            return c
    return None


def carpetas_plot_styles():
    base = os.environ.get("APPDATA", "")
    return sorted(glob.glob(os.path.join(base, "Autodesk", "AutoCAD 20*", "R*", "*", "Plotters", "Plot Styles")))


def instalar_ctb():
    """copia los CTB de la carpeta ctb/ a las carpetas Plot Styles de AutoCAD encontradas."""
    hechos = []
    for d in carpetas_plot_styles():
        for f in glob.glob(os.path.join(CTB_DIR, "*.ctb")):
            try:
                shutil.copy2(f, d)
                hechos.append(os.path.join(d, os.path.basename(f)))
            except OSError:
                pass
    return hechos


def ejecutar_autocad(ruta_dibujo, ruta_scr, acad=None):
    acad = acad or buscar_autocad()
    if not acad:
        raise RuntimeError("No se encontró AutoCAD (acad.exe). Abra el DXF en AutoCAD, cargue el .lsp con "
                           "APPLOAD y ejecute HMV_FINALIZAR.")
    return subprocess.Popen([acad, ruta_dibujo, "/b", ruta_scr])


# --------------------------------------------------------------------------
# Open CAD Studio: busca los CTB por nombre en su carpeta de estilos de ploteo
#   %APPDATA%\OpenCADStudio\plotstyles   (o la carpeta elegida en Opciones,
#   guardada como "plot_styles_folder" en %APPDATA%\OpenCADStudio\settings.json)
# --------------------------------------------------------------------------
def carpeta_ctb_opencad():
    base = os.environ.get("APPDATA")
    if not base:
        if sys.platform == "darwin":
            base = os.path.expanduser("~/Library/Application Support")
        else:
            base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    raiz = os.path.join(base, "OpenCADStudio")
    try:
        import json
        with open(os.path.join(raiz, "settings.json"), encoding="utf-8") as f:
            elegida = (json.load(f) or {}).get("plot_styles_folder")
        if elegida:
            return elegida
    except (OSError, ValueError, AttributeError):
        pass
    return os.path.join(raiz, "plotstyles")


def instalar_ctb_opencad():
    """copia ctb/*.ctb a la carpeta de estilos de ploteo de Open CAD Studio. Devuelve la carpeta."""
    destino = carpeta_ctb_opencad()
    os.makedirs(destino, exist_ok=True)
    hechos = []
    for f in sorted(os.listdir(CTB_DIR)):
        if f.lower().endswith(".ctb"):
            shutil.copy2(os.path.join(CTB_DIR, f), os.path.join(destino, f))
            hechos.append(f)
    return destino, hechos
